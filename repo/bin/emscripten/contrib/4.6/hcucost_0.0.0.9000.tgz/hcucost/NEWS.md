# hcucost 0.0.0.9000 (expected values of lifecourses, 2026-11-08)

* **`hcu_expected_impactncd()`** (user request): the expected use and cost of every person-year of an
  IMPACTncd lifecourse, without simulation.
  * Input and columns as `hcu_simulate_impactncd()`; the counts and costs are means, plus
    `se_healthcare_use_costs`.
  * Valid for every year because the latent processes are stationary: every year has the first
    year's distribution of latent scores. The function checks this and stops otherwise. All the
    fitted and synthetic models are stationary to 2e-16.
  * 128 quasi-random points per person-year by default; a person-year dying in the year gets 3 times
    as many, over the share-of-year quadrature.
  * Random shifts keyed on (seed, pid, year): common random numbers across scenarios, independent of
    threads and row order.
  * `copula = FALSE` gives the means of the simulation without the copula.
* Checked on the fitted CY model (process script `ev_12_lifecourse_check.R`; 44,600 person-years):
  * agreement with 40 simulation seeds, for the cost overall, by year, in the year of death and the
    year before (|z| <= 1.2), and for the counts (|z| <= 1.4);
  * survivors' counts equal the model means exactly;
  * changing one person leaves every other row identical;
  * about 43 µs per person-year on one thread (simulation 2.5 µs), and in the same time a standard
    error of the mean cost per person-year about 7 times smaller.
* Core: `cpp_expected()` takes per-row years for the shift keys (`hcu_predict()` keeps year 0, so its
  results are unchanged), `copula`, and per-row standard errors instead of per-shift totals.
* Tests (`test_expected.R`, 20 more; `test_fitted.R`):
  * columns, and survivors' counts exact; counts in the year of death against a finer quadrature;
  * agreement with the simulation, with and without the copula;
  * independence of threads and row order; common random numbers;
  * refusal of a non-stationary model and of a model without persistence.

# hcucost 0.0.0.9000 (masking validation with expected values, 2026-11-08)

* `vignette("methods")`: the masking validation's figures are now those of a rerun with expected
  values (user request; same records, fill-in and seeds; 512 points per completed record).
  * The scenarios relative to M0 are 0.1-0.25 points higher than in the simulated runs, whose M0
    (20 simulated years per record) was about one standard deviation high by chance.
  * Over eight seeds, the simulated M0 agreed with the expected one: neither method is biased.
  * M0 against observed: 1.030 (CY) and 1.013 (FY).
  * The decedents' shortfall with no disease known: about 1.5% (CY) and 3% (FY), previously 2% and
    4%.
  * The process scripts and full results are in the pipeline README.

# hcucost 0.0.0.9000 (expected values are the default, 2026-11-08)

* **`hcu_predict()` computes means without simulation by default** (`method = "expected"`; user
  request).
  * `type = "draws"` still simulates.
  * `method = "simulate"` gives the previous behaviour; use it to reproduce results computed
    before.
  * A warning when `n_sim` is given with the expected method, where it is not used.
* The in-house scripts that relied on simulation now pass `method = "simulate"`: the masking
  validation, whose results the methods vignette quotes, the bundle build's check, and a fill-in
  debugging script.
* Tests, examples, both vignettes and README follow the new default.

# hcucost 0.0.0.9000 (means without simulation, 2026-11-08)

* **`hcu_predict(method = "expected")`** computes the means without simulation (user request,
  after the investigation in the process scripts `ev_01`-`ev_08`).
  * Exact parts:
    * the expected counts are the model means (the hurdle keeps the mean);
    * the expected cost given the counts (independent severity scores; multipliers of mean 1,
      the inpatient mixtures' computed in closed form).
  * No closed form for the expected cost: the cost per unit depends on all five counts, which are
    linked by the copula. The C++ core (`inst/include/hcucost/expected.hpp`) averages over the
    copula by randomised quasi-Monte Carlo:
    * Halton points with random shifts keyed on (seed, record), so results are reproducible and do
      not depend on threads;
    * the standard error comes from the shifts;
    * in the year of death, Gauss-Legendre quadrature over the share of the year lived (3 nodes per
      band; the first band transformed).
  * New arguments `n_points` (16,384) and `n_shifts` (8). (`method = "simulate"` was the default at
    first; `"expected"` became the default the same day, above.)
  * On the fitted models:
    * the error is 0.2-0.5% per death group with the default points, at about 7 ms on one thread
      (0.05-0.15% with 65,536 points);
    * the simulation needs 40-130 times as many simulated years for the same error;
    * the results agree with the simulation within error in every death group, including fill-in.
* The latent processes are stationary, so the same expected values hold for every person-year of a
  lifecourse (documented in `vignette("methods")`; no lifecourse function yet).
* Tests: `test_expected.R` (quadrature, Halton points, multiplier means, exact counts, agreement with
  the simulation in each death group, threads, seeds, error, fill-in, arguments); `test_fitted.R`
  (the fitted models' multipliers, a profile against the simulation).
* The web explorer uses the new method (see `web/README.md`).

# hcucost 0.0.0.9000 (web explorer, proof of concept; no server paths, 2026-11-08)

* **Web explorer** (`web/`, not part of the R package; user request: a GUI without a server). A static
  page runs R in the visitor's browser with webR (WebAssembly) and calls `hcu_predict()` on the shipped
  models, through `web/hcucost_web.R`.
  * `web/build_wasm.sh` builds hcucost for webR (v0.6.0).
  * `web/test/run_check.sh` checks that webR gives native R's results: 8 requests, largest relative
    difference 4e-15.
  * `web/test/run_page_check.sh` checks the page in headless Chromium.
  * A first visit downloads 21 MB. A profile with the default precision takes about 4 s.
  * Details, measurements and limitations are in `web/README.md`.
* For webR:
  * `src/Makevars` skips its strip step under Emscripten.
  * `hcu_registry()` reads the registry with `utils::read.csv()` instead of `data.table::fread()`,
    which memory-maps files and fails in webR. The result is the same table; tests check this.
* **No server paths in the shared files.**
  * The in-house tests find the pipeline only through `HCUCOST_PIPELINE_DIR`, and
    `tools/make_reference.R` takes the pipeline's folder as its argument or from that variable.
  * The bundle manifests give their source files relative to the pipeline folder; the model files are
    unchanged.

# hcucost 0.0.0.9000 (in-house guide withdrawn, 2026-11-08)

* The in-house guide (formerly `vignette("in-house")`: where the fitted models are, building,
  refitting and maintaining the CPRD bundles) is no longer part of the package or its repository.
  The team keeps it locally (user decision: not to be shared). The package has two vignettes,
  `vignette("hcucost")` and `vignette("methods")`.

# hcucost 0.0.0.9000 (shipped bundles cleared for release, 2026-11-08)

* **The 12 shipped bundles are cleared for release** (Christodoulos Kypridemos, PI, 2026-11-08:
  "happy to clear the whole package for release on github"; the small fill-in calibration cells
  were reported beforehand). The registry (`inst/registry/cleared_bundles.csv`) lists the md5 of
  each of their 26 files (12 parameter files, 12 death models, 2 co-occurrence models), so
  `hcu_fitted_models()` and results computed with them report `"cleared"`.
* `tools/register_bundles.R` (package source, not installed) registers newly cleared bundles: it
  checks each file against its manifest and adds its md5 once (idempotent). Refitted bundles have new
  md5s and stay uncleared until registered.
* Documentation of clearance updated throughout (README, DESCRIPTION, help pages, vignettes).

# hcucost 0.0.0.9000 (fitted models shipped, disclosure audit, smaller library, 2026-11-08)

* **The fitted CPRD models ship with the package** (`inst/bundles/`, 12 bundles, 0.7 MB; user
  decision: they may be included if they hold no individual-level information). `hcu_fitted_models("CY")`
  (or `"FY"`) reads the full model and the reduced models A, AS, ASR, AR, AN as a named list. They
  are uncleared until the data provider's output checks.
* **Disclosure audit** (user: R model objects may contain individual-level information).
  `hcu_audit_bundle()` checks every element and attribute of a bundle: allowed types, classes and
  attributes only (no fitted model objects, functions, formulas, environments, external pointers
  other than data.table's), no element named like row-level model output (`residuals`, `y`,
  `model`, `data`, `weights`, `na.action`, ...), no vector longer than 5,000 values or table longer
  than 100 rows, no identifier-like strings. `hcu_bundle_write()` refuses a bundle that fails
  (`audit = TRUE`), and `hcu_model()` warns when reading one. Every shipped bundle passes.
* **No variance-covariance matrices in bundles** (user decision): `hcu_strip_params()` and the death
  model's stripping drop them. Prediction does not use them, and they were about 98% of a bundle's
  numbers (the full model's bundles: 7.7 MB -> 0.2 MB). The synthetic parameters no longer have them.
* **Smaller compiled library** (user request): `src/Makevars` strips debug information from the
  shared library after linking (`strip --strip-debug`; `strip -S` on macOS). R's default flags on
  Unix compile with `-g`: the library was 3.7 MB, of which 3.2 MB debug sections; now 0.4 MB, and
  the installed package 1.3 MB instead of 4.4 MB. Code unchanged; the symbol table is kept.
  `HCUCOST_KEEP_DEBUG=1` at installation keeps the debug information (gdb, valgrind).
* Tests: the audit (a fitted `glm`, formulas, functions, long vectors, large tables, identifiers,
  row-level names and attributes are refused; synthetic models pass; a bundle written without the
  audit warns when read), stripping of variance-covariance matrices, and the shipped bundles
  (present for both periods, uncleared, audited, usable by `hcu_predict()` and
  `hcu_simulate_impactncd()`).

# hcucost 0.0.0.9000 (vignettes, 2026-11-08)

* Three vignettes (user request):
  * `vignette("hcucost")`, getting started: bundles and their status, predictor sets, simulating
    lifecourses (distributions, persistence, random numbers, threads and common random numbers
    across scenarios), `hcu_predict()` with any known predictors (model choice per record, fill-in,
    death groups, draws). Runs on the synthetic models.
  * `vignette("methods")`: data, the model of use and cost, reduced models, death models, the
    co-occurrence models and the calibrated Gibbs fill-in, random numbers, and the validation on
    held-out CPRD patients (aggregate results, as agreed with the user), with limitations.
  * an in-house guide to the CPRD bundles (withdrawn from the package on 2026-11-08; see above).
* Documentation brought up to date: the package help page and DESCRIPTION (phase 3b),
  `hcu_simulate_impactncd()` points to `hcu_predict()` for unknown predictors, and
  `hcu_calibrate_fillin()` documents `eps`.

# hcucost 0.0.0.9000 (calibrated fill-in, format 3: year of diagnosis, 2026-11-07)

* **Diagnosis-year table** `eps[disease, death group]` in the fill-in calibration (format 3; user
  request after the calibrated masking validation). Calibrated fill-ins still drew conditions too
  rarely in their year of diagnosis: decedents' cancers 0.92 x observed, other conditions 0.85 x
  (0.92 x in survivors). The co-occurrence models' duration bands carry no death information by
  design and, one step with the true other predictors, predicted decedents' newly diagnosed cancers
  at 0.73 x. New diagnoses drive admissions: about 2% of hospital costs when diseases are unknown.
  * The tilt is exact for the joint: band b of disease j has weight w_b (`exp(eps)` for the year of
    diagnosis, else 1), its band probabilities become `pb_b w_b / T` and its presence odds are
    multiplied by `T = sum_b pb_b w_b`; a swap move's acceptance ratio gains `T_j / T_i`.
  * Calibrated in the same loop as theta and delta, to the share of present diseases in their year
    of diagnosis by disease and death group (unknown group weighted).
  * Format-2 calibrations (no `eps`) remain valid.
* Tests: the tilted joint, the diagnosis-year shares and the swap moves with a known count are
  reproduced exactly on a toy model (R and core); core = R with random `eps`; calibration recovers
  decedent-specific diagnosis-year shares. 614 tests.

# hcucost 0.0.0.9000 (phase 3b+: calibrated fill-in, 2026-11-07)

* **Calibration of the fill-in** (`hcu_calibrate_fillin()`, `R/calibrate.R`; user decision after the
  masking validation on the CPRD data). The sampler's target is tilted by
  `exp(theta[age band, sex, death group, number of conditions])` and per-disease offsets
  `exp(delta[disease, age band, sex, death group])` (calibration format 2).
  * The count tilt is the same distribution as drawing the number of conditions from its
    distribution and then the diseases given the count, and it also works when some diseases are
    known.
  * theta and delta are fitted in-house by iterative proportional fitting on records with every
    disease known (pipeline stage 22b), so that the filled count distribution and prevalences (by
    age band, sex and death group, including an unknown death group) match the data.
  * The offsets are by death group because, with offsets pooled over the groups (format 1, first
    CPRD run), cancers were drawn too rarely in decedents (any cancer 0.373 vs 0.396 observed) and
    too often in survivors (0.059 vs 0.054), leaving hospital admissions about 2% low.
  * delta is centred within each age band x sex x death group cell: the prevalences sum to the mean number of
    conditions, which theta already matches. Uncentred, both corrected the overall level in the same
    round and the calibration oscillated (synthetic pipeline data). Each round's change is capped
    (`max_step`).
  * The tables travel inside the co-occurrence model (`$calibration`) in bundles; the in-house
    history and margins are stripped. The core and the R reference apply them identically.
* Tests: the tilted target is reproduced exactly on a toy model (R and core); core = R reference
  with a random calibration; calibration recovers the margins of data drawn under a known tilt and
  stays stable; bundles keep the tables.

# hcucost 0.0.0.9000 (phase 3b, 2026-11-06/07)

Predictions for records with any known predictors.

* `hcu_predict()`:
  * **Choice of model:** each record uses the smallest refit that matches exactly the predictor
    groups known for it (AS, AN, ...). Otherwise it uses the full model, with the unknown
    predictors filled in by Gibbs sampling from the co-occurrence model.
  * **Known information used in the fill-in:** a known number of conditions (swap moves keep it), a
    known disease with unknown duration (`-1`), and a known death group, through the full model's
    death model as a likelihood.
  * **Unknown death group:** predictions average over the model's death model.
  * **Output:** `type = "mean"` gives Monte Carlo means with a standard error; `type = "draws"`
    gives joint draws. Simulation uses the C++ core.
* Fill-in R reference (`R/fillin.R`). It uses a fixed number of uniforms per record and sweep, in a
  fixed order, so that a C++ port can be checked against it. Tests:
  * known values are kept;
  * a known count is respected;
  * on a toy model whose full conditionals come from a known joint distribution, the draws
    reproduce that joint, with and without a known count;
  * with a known death group, decedents' unknown diseases are filled with more disease.
* Bundles may carry `death_model.rds` (pipeline stage 15c) and, for the full model,
  `cooccurrence.rds` (stage 22). Both are stripped to prediction fields and md5-checked.
  * A bundle is cleared only if every file is in the registry.
  * `hcu_bundle_write()` takes the predictor set from the parameters; a mismatch is an error.
* `R/reference.R` also copies the pipeline's death-model and co-occurrence prediction functions:
  38 functions, checked identical in-house.
* Synthetic death and co-occurrence models: `hcu_synthetic_model()` carries them.
* The fill-in also runs in the C++ core (`fill_in_core()`, `inst/include/hcucost/fillin.hpp`).
  * It gives exactly the R reference's draws given the same uniforms, about 50x faster.
  * `hcu_predict()` uses it, with random numbers keyed on (seed, record, sweep).
* Structural zeros of the co-occurrence models (`zero_sex`: e.g. no prostate cancer drawn for
  women).
* The port to C++ found two bugs in the R reference, both now fixed: a disease known to be present
  with unknown duration was not counted towards a known number of conditions, and an unknown S/R
  variable's initial level was taken by position among all levels instead of among the fitted ones.
* P(death in the year) is computed as `-expm1(-rate)` instead of `1 - exp(-rate)`, in the C++
  core and in the pipeline's `death_model_predict()` (regenerated reference). The old form is 0 for
  rates below about 1e-16, which dropped a known death group's weights in the fill-in for extreme
  synthetic records; realistic rates are unaffected. A death group with probability exactly 0
  (rate underflow) still falls back to the plain conditional.
* 538 tests; `R CMD check` Status OK.

# hcucost 0.0.0.9000 (phase 3a, in progress, 2026-11-06)

Reduced predictor sets, refitted in the CPRD costing pipeline for users who lack some predictors
(`COSTING_PREDICTORS`; pipeline README section 2d).

* `R/reference.R` regenerated from the edited pipeline: 31 functions, adding `spec_predictors()` and
  `has_group()`. The full model's results are unchanged: checked in the pipeline on every output
  of stages 15-19 on synthetic data, and in-house here on the real CY and FY parameters.
* The compiled design catalogue follows a reduced specification (`spec$predictors`): only the set's
  predictor groups' columns.
* `hcu_synthetic_params(predictors =)` and `hcu_synthetic_model(predictors =)`: synthetic reduced
  models with the structure of the pipeline's reduced refits. A set with N but without D has its
  own bands for 0 and 1 condition, as in the pipeline. The C++ core reproduces the R
  reference on them (sets A, AS, AR, AN).
* 408 tests.

# hcucost 0.0.0.9000 (phase 2, 2026-11-06)

Phase 2 of the package design: the C++ core.

* **C++ core** (`inst/include/hcucost/`, header-only, no R API inside, so other packages' C++ can
  use it via `LinkingTo`):
  * no design matrix. `R/compile.R` turns each fitted linear predictor into small lookup tables
    once per model, for every factor, death band, disease band and condition count. The age and
    BMI splines become cubic polynomials between the knots, which is exact. Every design column is
    checked against the reference design, and a design the compiler does not know stops with an
    error;
  * one pass per person over their consecutive years (latent VAR(1) paths as in the reference);
  * counter-based random numbers: Philox4x32-10 keyed on (seed, person, year, stream). Results do
    not depend on threads, chunking, input order or the other persons. Scenarios with the same
    seed share each person's latent paths (common random numbers);
  * distribution functions: ports of R's `pnorm` and `qnorm` and R's `qnbinom` search, all
    bit-identical to R in the tests; Boost's gamma quantile, within about 1e-14 of R's `qgamma`;
  * optional OpenMP threads.
* `hcu_simulate_impactncd()` gains `engine = c("cpp", "r")` (C++ by default) and `threads`; the
  result's attribute also records the engine and the seed.
* `hcu_model` objects carry the compiled tables (`$compiled`).
* **Exactness:** fed the R reference's own random draws, the core gives identical counts and
  costs equal to about 1e-14 relative. This holds on the synthetic model and, in-house, on the real
  CY and FY models. It is checked in three draw modes: copula with severity scores, copula with
  independent severity uniforms, and independent counts.
* **Speed** (synthetic lifecourses, real CY parameters; in-house script
  `claude_process/04_benchmark_core.R`, not in the repository):
  * 0.9 million person-years: whole call 1.8 s on 1 thread and 0.42 s on 8 threads, against 17.8 s
    for the R implementation (about 10× and 42× faster);
  * core alone: about 550,000 person-years/s per thread, 3.9 million on 8 threads;
  * R heap 0.47 GiB, against 5.7 GiB;
  * 9 million person-years: 18.4 s on 1 thread and 4.2 s on 8 threads, with a process peak of
    4.9 GiB.
* Lifecourse validation: vectorised (about 9× faster). A factor `smok_status_curr_xps` must have
  the levels 1-4 in order, because its integer codes are used.
* `tools/make_reference.R` (moved from `claude_process/`) regenerates `R/reference.R`.
* Unit tests moved from testthat to **tinytest**: `inst/tinytest/test_*.R`, helpers in
  `inst/tinytest/helpers_*.R`, runner `tests/tinytest.R`. They are also installed with the package,
  so `tinytest::test_package("hcucost")` runs them on any installation. In-house files exit early
  where the CPRD costing pipeline is not available. 325 tests.

# hcucost 0.0.0.9000 (phase 1, 2026-11-06)

Phase 1 of the package design (`Costing_pipeline/package_design/cost_model_package_design.md`,
CPRD2025 project).

* Package skeleton.
* R reference implementation, `R/reference.R`: a verbatim copy, generated by
  `tools/make_reference.R`, of the 29 pipeline functions that `impactncd_healthcare_use()`
  needs (pipeline files with md5 28729ffd... and 1a19ff00..., the same as the calendar-year IMPACTncd
  export bundle of 2026-11-06).
* Parameter bundles:
  * `hcu_bundle_write()` and `hcu_model()` write and read `manifest.json` + `params.rds`, with an md5
    integrity check.
  * `hcu_strip_params()` keeps only the prediction fields; `hcu_validate_params()` checks the
    structure.
  * Clearance status comes from the registry (`hcu_registry()`), never from the bundle itself.
* `hcu_simulate_impactncd()`: joint simulation for an IMPACTncd-style lifecourse, with input checks
  and an optional seed that leaves the caller's RNG state unchanged.
* `hcu_synthetic_params()`, `hcu_synthetic_model()`, `hcu_synthetic_lifecourse()`: invented values
  with the real structure, for examples and tests.
* testthat tests, including in-house checks against the pipeline:
  * the copied functions are identical to the pipeline's;
  * results with the real CY and FY parameters are identical;
  * the synthetic structure is the same as the real one.
