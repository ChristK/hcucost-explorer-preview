# hcucost parameter bundles (CPRD; cleared for release)

Built 2026-11-08 by `Costing_pipeline/build_hcucost_bundles.R` with hcucost 0.0.0.9000. One folder per period (CY: calendar years, for IMPACTncd; FY: financial years) and predictor set; `bundles.csv` lists them with their md5 checksums.

* **Status: cleared for release.** Every file is in hcucost's registry of cleared bundles
  (`hcucost::hcu_registry()`; the shipped bundles were cleared on 2026-11-08 by Christodoulos Kypridemos, PI).
* **No individual-level information:** every bundle passes `hcucost::hcu_audit_bundle()` (plain values only; no
  fitted model objects, formulas, functions, environments, per-record vectors or identifier-like strings), and
  the bundles carry no variance-covariance matrices. Aggregates from small groups still need the output checks.
* **Models:** all-patient refits (`results/model_full/`). `ASRDN` is the full model, with its death model and the
  co-occurrence (fill-in) model with its calibration; `A`, `AS`, `ASR`, `AR`, `AN` are the reduced refits,
  each with its death model.
* **Use:** `m <- hcucost::hcu_model("bundle_CY_ASRDN")`; see `vignette("hcucost")` and `vignette("methods")`.
* **Rebuild** after any refit: `COSTING_BUNDLE_OVERWRITE=1 Rscript Costing_pipeline/build_hcucost_bundles.R`.
