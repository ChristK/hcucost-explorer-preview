// hcucost/fillin.hpp - filling in unknown predictors by Gibbs sampling, in the core (phase 3b).
//
// C++ port of the R reference fill_in_r() (R/fillin.R): the same updates, in the same order, using
// the same uniforms (per record and sweep a fixed number, fill_in_uniforms_per_sweep()), so that given
// the same uniforms both give the same draws. The co-occurrence models (presence and band of each
// disease, BMI, smoking, deprivation, ethnicity, region) and the full model's death model are LinTerm
// tables over the cost model's row features (compile_fillin(), R/compile.R), evaluated with
// eval_term() on the features of the current record state.
// Header-only, no R API: safe inside OpenMP regions.
#ifndef HCUCOST_FILLIN_HPP
#define HCUCOST_FILLIN_HPP

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <vector>

#include "model.hpp"
#include "philox.hpp"

namespace hcucost {

constexpr std::uint32_t S_FILL = 10;  // Philox stream of the fill-in uniforms

// A multinomial model: one linear predictor per level; unfitted levels have probability 0; a
// constant model has fixed probabilities.
struct MultiTerm {
  std::vector<LinTerm> terms;
  std::vector<int> fitted;
  std::vector<double> constant;  // empty unless constant
  int init = 0;                  // initial level (largest fitted intercept)
};

struct DiseaseFill {
  LinTerm presence;
  MultiTerm band;
  std::vector<int> band_dur;  // representative duration of each band
  int zero_sex[2] = {0, 0};   // structural zeros: no case in men / women (probability 0)
};

// P(disease j present | state features) from its presence model (R: cooc_predict(), zero_sex included).
inline double p_present(const DiseaseFill& dj, const Model& M, const RowFeat& f) {
  if (dj.zero_sex[f.sex]) return 0.0;
  return logis_cdf(eval_term(dj.presence, M, f));
}

// Calibration of the fill-in (2026-11-07; hcu_calibrate_fillin()): the sampler's target is tilted by
//   exp(theta[band, sex, death group, min(K, k_max)]) x prod_j exp(delta[j, band, sex, death group] * present_j),
// K the number of conditions. The theta tilt is "draw the count from its distribution, then the
// diseases given the count" (exp(theta(K)) = P(K) / Z_K); delta matches each disease's prevalence.
// Age band = number of cuts <= age; death group 0 survives, 1 dies next year, 2 dies in the year,
// 3 unknown. Layout: theta[k + (k_max + 1) * (g + 4 * (sex + 2 * band))],
// delta[g + 4 * (sex + 2 * (band + n_band * j))].
// Optional (format 3): eps[g + 4 * j], a tilt exp(eps) of the year-of-diagnosis band (representative
// duration 1) of disease j: band b has weight w_b (exp(eps) for the diagnosis year, else 1), the band
// probabilities become pb_b w_b / T and the presence odds are multiplied by T = sum_b pb_b w_b (the
// exact tilt of the joint); in a swap move the ratio gains T_j / T_i.
struct FillCalibration {
  bool present = false, has_eps = false;
  std::vector<double> age_cut, theta, delta, eps;
  int k_max = 0;
  int band(double age) const {
    int b = 0;
    for (double c : age_cut) if (age >= c) ++b;
    return b;
  }
  int n_band() const { return static_cast<int>(age_cut.size()) + 1; }
  double th(int band, int sex, int g, int k) const {
    if (k > k_max) k = k_max;
    return theta[k + (k_max + 1) * (g + 4 * (sex + 2 * band))];
  }
  double de(int j, int band, int sex, int g) const { return delta[g + 4 * (sex + 2 * (band + n_band() * j))]; }
  double ep(int j, int g) const { return eps[g + 4 * j]; }
};

// Diagnosis-year tilt of band probabilities pb of disease dj (in place); returns T = sum_b pb_b w_b
// (R: fill_in_r(), the same operations in the same order).
inline double band_tilt(const DiseaseFill& dj, double eps_jg, std::vector<double>& pb) {
  const double w1 = std::exp(eps_jg);
  const int nb = static_cast<int>(pb.size());
  double T = 0.0;
  for (int b = 0; b < nb; ++b) T += pb[b] * (dj.band_dur[b] == 1 ? w1 : 1.0);
  for (int b = 0; b < nb; ++b) pb[b] = pb[b] * (dj.band_dur[b] == 1 ? w1 : 1.0) / T;
  return T;
}

struct FillModel {
  bool present = false, death = false;
  std::vector<DiseaseFill> dis;
  LinTerm bmi;
  double bmi_sigma[2] = {0, 0};
  MultiTerm smok, dimd, eth, sha;
  LinTerm died, dies_next;
  FillCalibration cal;
};

// State of one record: 0-based level codes, BMI, durations (0 absent).
struct FillState {
  double age;
  int sex, dimd, eth, sha, smok;
  double bmi;
  int prvl[MAX_DISEASES];
};

// Row features of a state for the co-occurrence and death models (no death, full year).
inline void state_features(const Model& M, const FillState& s, int year_unused, RowFeat& f) {
  (void)year_unused;
  f.sex = s.sex;
  f.dimd = s.dimd;
  f.eth = s.eth;
  f.sha = s.sha;
  f.smok = s.smok;
  M.age.locate(s.age, f.ai, f.au);
  M.bmi.locate(s.bmi, f.bi, f.bu);
  f.nd = 0;
  f.n_other = 0;
  f.any_ca = 0;
  for (int d = 0; d < M.D; ++d) {
    const int p = s.prvl[d];
    if (p > 0) {
      f.dz[f.nd] = d;
      f.db[f.nd] = prvl_band(p, M.spell[d] != 0);
      ++f.nd;
      if (M.cancer[d]) f.any_ca = 1; else ++f.n_other;
    }
  }
  f.ncond = f.nd;
  f.agenc_band = M.agenc_band.empty() ? 0 : M.agenc_band[f.ncond];
  f.death_age_band = band_left_closed(M.death_age_cut, s.age);
  f.died = 0;
  f.dies_next = 0;
  f.grp = 0;
  f.logprop = 0.0;
  f.prop_band = band_right_closed(M.prop_cut, 1.0);
}

// Probabilities of a multinomial model on features f (every level; R: cooc_predict()).
inline void multi_probs(const MultiTerm& m, const Model& M, const RowFeat& f, std::vector<double>& p) {
  const std::size_t L = m.terms.size();
  p.assign(L, 0.0);
  if (!m.constant.empty()) {
    for (std::size_t l = 0; l < L; ++l) p[l] = m.constant[l];
    return;
  }
  double mx = -HCU_INF;
  std::vector<double> e(L, -HCU_INF);
  for (std::size_t l = 0; l < L; ++l) {
    if (!m.fitted[l]) continue;
    e[l] = eval_term(m.terms[l], M, f);
    if (e[l] > mx) mx = e[l];
  }
  double sum = 0.0;
  for (std::size_t l = 0; l < L; ++l) {
    if (!m.fitted[l]) continue;
    p[l] = std::exp(e[l] - mx);
    sum += p[l];
  }
  for (std::size_t l = 0; l < L; ++l) p[l] /= sum;
}

// Index drawn from probabilities p with uniform u (R: rowSums(u > cumsum(p)) + 1, capped).
inline int draw_index(const std::vector<double>& p, double u) {
  int k = 0;
  double c = 0.0;
  for (std::size_t l = 0; l < p.size(); ++l) {
    c += p[l];
    if (u > c) ++k;
  }
  const int L = static_cast<int>(p.size());
  return k < L ? k : L - 1;
}

// P(death group g | state) from the full model's death model (R: death_model_predict()).
inline double p_group(const FillModel& F, const Model& M, const FillState& s, int g) {
  RowFeat f;
  state_features(M, s, 0, f);
  // -expm1(-rate) rather than 1 - exp(-rate): exact for small rates (1 - exp(-1e-17) is 0 in double)
  const double p_died = -std::expm1(-std::exp(eval_term(F.died, M, f)));
  double p_next = std::exp(eval_term(F.dies_next, M, f));
  if (p_next > 1) p_next = 1;
  if (g == 2) return p_died;
  if (g == 1) return (1 - p_died) * p_next;
  return (1 - p_died) * (1 - p_next);
}

// Known information of a record (codes 0-based; -1 unknown; prvl -1 present with unknown duration,
// INT_MIN unknown). K: known number of conditions (-1 unknown); g: death group (-1 unknown).
struct FillRecord {
  double age;
  int sex, dimd, eth, sha, smok;
  double bmi;  // NaN unknown
  int prvl[MAX_DISEASES];
  int K, g;
};

inline int fill_uniforms_per_sweep(int D, int n_swaps) { return 5 + 2 * D + 4 * n_swaps; }

// Gibbs sampling for one record. U(sweep, col) gives the uniforms; out receives n_draws states.
template <typename UFun>
inline void fill_record(const FillModel& F, const Model& M, const FillRecord& rec, int n_draws, int burn_in, int thin,
                        UFun U, FillState* out) {
  const int D = M.D;
  const int n_swaps = std::max(1, D / 2);
  const bool constrained = rec.K >= 0;
  const bool use_death = F.death && rec.g >= 0;
  const FillCalibration& C = F.cal;
  const int cband = C.present ? C.band(rec.age) : 0;
  const int cg = rec.g >= 0 ? rec.g : 3;  // calibration death group (3: unknown)
  FillState s;
  s.age = rec.age;
  s.sex = rec.sex;
  const bool unk[4] = {rec.dimd < 0, rec.eth < 0, rec.sha < 0, rec.smok < 0};
  const MultiTerm* mt[4] = {&F.dimd, &F.eth, &F.sha, &F.smok};
  int* slot[4] = {&s.dimd, &s.eth, &s.sha, &s.smok};
  const int known_v[4] = {rec.dimd, rec.eth, rec.sha, rec.smok};
  for (int v = 0; v < 4; ++v) *slot[v] = unk[v] ? mt[v]->init : known_v[v];
  const bool unk_bmi = std::isnan(rec.bmi);
  s.bmi = unk_bmi ? 26.0 : rec.bmi;
  bool unk_pres[MAX_DISEASES], unk_band[MAX_DISEASES];
  int known_present = 0;
  for (int j = 0; j < D; ++j) {
    unk_pres[j] = rec.prvl[j] == NA_COUNT;
    unk_band[j] = unk_pres[j] || rec.prvl[j] == -1;
    if (unk_pres[j]) s.prvl[j] = 0;
    else if (rec.prvl[j] == -1) s.prvl[j] = F.dis[j].band_dur[0];
    else s.prvl[j] = rec.prvl[j];
    if (!unk_pres[j] && rec.prvl[j] != 0) ++known_present;
  }
  RowFeat f;
  if (constrained) {  // the K - known_present unknown diseases with the highest presence probability
    const int need = rec.K - known_present;
    if (need > 0) {
      state_features(M, s, 0, f);
      std::vector<std::pair<double, int>> cand;
      for (int j = 0; j < D; ++j)
        if (unk_pres[j]) cand.push_back({p_present(F.dis[j], M, f), j});
      std::stable_sort(cand.begin(), cand.end(), [](const std::pair<double, int>& a, const std::pair<double, int>& b) {
        return a.first > b.first;
      });
      for (int q = 0; q < need && q < static_cast<int>(cand.size()); ++q) s.prvl[cand[q].second] = F.dis[cand[q].second].band_dur[0];
    }
  }
  std::vector<double> pm, pb, wb;
  const int n_sweeps = burn_in + n_draws * thin;
  int kept = 0;
  for (int sweep = 1; sweep <= n_sweeps; ++sweep) {
    int col = 0;
    // S and R variables
    for (int v = 0; v < 4; ++v) {
      const double u = U(sweep, col);
      ++col;
      if (!unk[v]) continue;
      state_features(M, s, 0, f);
      multi_probs(*mt[v], M, f, pm);
      *slot[v] = draw_index(pm, u);
    }
    {
      const double u = U(sweep, col);
      ++col;
      if (unk_bmi) {
        state_features(M, s, 0, f);
        const double mu = eval_term(F.bmi, M, f);
        double b = std::exp(mu + F.bmi_sigma[s.sex] * norm_quantile(u));
        s.bmi = b < 12 ? 12 : (b > 90 ? 90 : b);
      }
    }
    // diseases
    for (int j = 0; j < D; ++j) {
      const double u_pres = U(sweep, col), u_band = U(sweep, col + 1);
      col += 2;
      const DiseaseFill& dj = F.dis[j];
      const int nb = static_cast<int>(dj.band_dur.size());
      const bool free = unk_pres[j] && !constrained;
      const bool band_only = (unk_band[j] && !unk_pres[j]) || (unk_pres[j] && constrained && s.prvl[j] > 0);
      if (!free && !band_only) continue;
      state_features(M, s, 0, f);
      multi_probs(dj.band, M, f, pb);
      const double Tb = (C.present && C.has_eps) ? band_tilt(dj, C.ep(j, cg), pb) : 1.0;  // diagnosis-year tilt
      if (free) {
        double p1 = p_present(dj, M, f);
        if (C.present && p1 > 0 && p1 < 1) {  // calibration tilt on the log-odds scale (R: fill_in_r())
          int km = 0;  // conditions present other than j
          for (int d = 0; d < D; ++d) if (d != j && s.prvl[d] > 0) ++km;
          double t = C.de(j, cband, s.sex, cg) + C.th(cband, s.sex, cg, km + 1) - C.th(cband, s.sex, cg, km);
          if (C.has_eps) t = t + std::log(Tb);
          p1 = 1 / (1 + std::exp(-(std::log(p1 / (1. - p1)) + t)));
        }
        if (use_death) {
          const int keep = s.prvl[j];
          s.prvl[j] = 0;
          const double w0 = p_group(F, M, s, rec.g);
          wb.assign(nb, 0.0);
          double num1 = 0.0, sw = 0.0;
          for (int b = 0; b < nb; ++b) {
            s.prvl[j] = dj.band_dur[b];
            wb[b] = p_group(F, M, s, rec.g);
            num1 += pb[b] * wb[b];
          }
          s.prvl[j] = keep;
          num1 *= p1;
          const double den = num1 + (1 - p1) * w0;
          if (std::isfinite(den) && den > 0) p1 = num1 / den;
          for (int b = 0; b < nb; ++b) sw += pb[b] * wb[b];
          if (sw > 0) for (int b = 0; b < nb; ++b) pb[b] = pb[b] * wb[b] / sw;
        }
        const bool on = u_pres < p1;
        s.prvl[j] = on ? dj.band_dur[draw_index(pb, u_band)] : 0;
      } else {
        if (use_death) {
          const int keep = s.prvl[j];
          double sw = 0.0;
          wb.assign(nb, 0.0);
          for (int b = 0; b < nb; ++b) {
            s.prvl[j] = dj.band_dur[b];
            wb[b] = p_group(F, M, s, rec.g);
            sw += pb[b] * wb[b];
          }
          s.prvl[j] = keep;
          if (sw > 0) for (int b = 0; b < nb; ++b) pb[b] = pb[b] * wb[b] / sw;
        }
        s.prvl[j] = dj.band_dur[draw_index(pb, u_band)];
      }
    }
    // swap moves (known number of conditions)
    for (int sw = 0; sw < n_swaps; ++sw) {
      const double u_i = U(sweep, col), u_j = U(sweep, col + 1), u_a = U(sweep, col + 2), u_b = U(sweep, col + 3);
      col += 4;
      if (!constrained) continue;
      int on[MAX_DISEASES], off[MAX_DISEASES], n_on = 0, n_off = 0;
      for (int j = 0; j < D; ++j) {
        if (!unk_pres[j]) continue;
        if (s.prvl[j] > 0) on[n_on++] = j; else off[n_off++] = j;
      }
      if (!n_on || !n_off) continue;
      const int ki = std::min(n_on, static_cast<int>(std::floor(u_i * n_on)) + 1);
      const int kj = std::min(n_off, static_cast<int>(std::floor(u_j * n_off)) + 1);
      const int i = on[ki - 1], jj = off[kj - 1];
      state_features(M, s, 0, f);
      const double pi1 = p_present(F.dis[i], M, f);
      FillState s0 = s;
      s0.prvl[i] = 0;
      RowFeat f0;
      state_features(M, s0, 0, f0);
      const double pj1 = p_present(F.dis[jj], M, f0);
      multi_probs(F.dis[jj].band, M, f0, pb);
      double Ti = 1.0, Tj = 1.0;
      if (C.present && C.has_eps) {  // diagnosis-year tilt: j's band from its tilted distribution
        multi_probs(F.dis[i].band, M, f, wb);
        Ti = band_tilt(F.dis[i], C.ep(i, cg), wb);
        Tj = band_tilt(F.dis[jj], C.ep(jj, cg), pb);
      }
      const int dur_j = F.dis[jj].band_dur[draw_index(pb, u_b)];
      double ratio = (pj1 / (1 - pj1)) / (pi1 / (1 - pi1));
      if (C.present) ratio *= std::exp(C.de(jj, cband, s.sex, cg) - C.de(i, cband, s.sex, cg));  // (theta: K unchanged)
      if (C.present && C.has_eps) ratio *= Tj / Ti;
      if (use_death) {
        FillState s1 = s0;
        s1.prvl[jj] = dur_j;
        double rg = p_group(F, M, s1, rec.g) / p_group(F, M, s, rec.g);
        if (!std::isfinite(rg)) rg = 1;
        ratio *= rg;
      }
      if (u_a < ratio) {
        s.prvl[i] = 0;
        s.prvl[jj] = dur_j;
      }
    }
    if (sweep > burn_in && (sweep - burn_in) % thin == 0 && kept < n_draws) out[kept++] = s;
  }
}

}  // namespace hcucost

#endif  // HCUCOST_FILLIN_HPP
