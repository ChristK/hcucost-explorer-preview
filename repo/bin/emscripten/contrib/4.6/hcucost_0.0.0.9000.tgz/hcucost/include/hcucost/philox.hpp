// hcucost/philox.hpp - counter-based random numbers (Philox4x32-10) keyed on
// (seed, person, year, stream).
//
// Philox4x32-10 is the counter-based generator of Salmon, Moraes, Dror and Shaw (2011), "Parallel
// random numbers: as easy as 1, 2, 3", SC'11 (Random123 library). A block of four 32-bit outputs
// is a pure function of a 128-bit counter and a 64-bit key, so a draw never depends on what was
// drawn before. hcucost uses this to make every simulated quantity a function of
// (seed, person id, year, stream) only:
//   * results do not depend on the number of threads, on how the lifecourse is split into
//     chunks, or on which other persons are in the data;
//   * two scenarios with the same seed reuse the same latent paths for the same person and year
//     (common random numbers), so differences between scenarios are not blurred by Monte Carlo
//     noise.
// Layout: key = (seed low 32 bits, seed high 32 bits); counter = (pid low 32 bits, pid high 32
// bits, year, stream * 2^24 + block). Each block gives two uniforms with 53 random bits.
// Header-only, no R API: safe inside OpenMP regions.
#ifndef HCUCOST_PHILOX_HPP
#define HCUCOST_PHILOX_HPP

#include <cstdint>

namespace hcucost {

// One Philox4x32 block: 10 rounds of the Philox S-box with the Weyl key schedule (Random123
// constants PHILOX_M4x32_0/1 and PHILOX_W32_0/1). Verified against the Random123 known-answer
// vectors (inst/tinytest/test_core_rng.R).
inline void philox4x32_10(const std::uint32_t ctr[4], const std::uint32_t key[2], std::uint32_t out[4]) {
  std::uint32_t c0 = ctr[0], c1 = ctr[1], c2 = ctr[2], c3 = ctr[3];
  std::uint32_t k0 = key[0], k1 = key[1];
  for (int r = 0; r < 10; ++r) {
    if (r > 0) {  // key bump before rounds 2-10
      k0 += 0x9E3779B9u;
      k1 += 0xBB67AE85u;
    }
    const std::uint64_t p0 = static_cast<std::uint64_t>(0xD2511F53u) * c0;
    const std::uint64_t p1 = static_cast<std::uint64_t>(0xCD9E8D57u) * c2;
    const std::uint32_t hi0 = static_cast<std::uint32_t>(p0 >> 32), lo0 = static_cast<std::uint32_t>(p0);
    const std::uint32_t hi1 = static_cast<std::uint32_t>(p1 >> 32), lo1 = static_cast<std::uint32_t>(p1);
    c0 = hi1 ^ c1 ^ k0;
    c1 = lo1;
    c2 = hi0 ^ c3 ^ k1;
    c3 = lo0;
  }
  out[0] = c0;
  out[1] = c1;
  out[2] = c2;
  out[3] = c3;
}

// Uniform on the open interval (0, 1) from two 32-bit words (53 random bits, centred on the
// grid so that 0 and 1 cannot occur).
inline double u53(std::uint32_t hi, std::uint32_t lo) {
  const std::uint64_t w = (static_cast<std::uint64_t>(hi) << 32) | lo;
  return (static_cast<double>(w >> 11) + 0.5) * 0x1p-53;
}

// Streams: what a block of random numbers is used for. Each (pid, year, stream) has its own
// counters, so adding a stream never changes the draws of another.
enum Stream : std::uint32_t {
  S_COUNT_PERM = 1,   // permanent latent component of the counts (year field fixed at 0)
  S_COUNT_INIT = 2,   // first-year (stationary) transitory component of the counts
  S_COUNT_INNOV = 3,  // yearly innovations of the counts' VAR(1)
  S_SEV_PERM = 4,     // the same three for the severity (cost per unit) latent scores
  S_SEV_INIT = 5,
  S_SEV_INNOV = 6,
  S_PROP = 7,         // share of the year lived in the year of death
  S_SEV_UNIF = 8,     // independent severity uniforms (no severity persistence)
  S_COUNT_INDEP = 9,  // independent count scores (copula = FALSE)
  S_QMC_SHIFT = 10    // random shifts of the quasi-Monte Carlo points of the expected values (expected.hpp)
};

// n uniforms on (0, 1) for (seed, pid, year, stream); blocks 0, 1, ... give two each.
inline void philox_uniforms(std::uint64_t seed, std::uint64_t pid, std::uint32_t year, std::uint32_t stream,
                            int n, double* out) {
  const std::uint32_t key[2] = {static_cast<std::uint32_t>(seed), static_cast<std::uint32_t>(seed >> 32)};
  for (int b = 0; 2 * b < n; ++b) {
    const std::uint32_t ctr[4] = {static_cast<std::uint32_t>(pid), static_cast<std::uint32_t>(pid >> 32), year,
                                  (stream << 24) | static_cast<std::uint32_t>(b)};
    std::uint32_t o[4];
    philox4x32_10(ctr, key, o);
    out[2 * b] = u53(o[0], o[1]);
    if (2 * b + 1 < n) out[2 * b + 1] = u53(o[2], o[3]);
  }
}

}  // namespace hcucost

#endif  // HCUCOST_PHILOX_HPP
