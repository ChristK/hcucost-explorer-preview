// hcucost/simulate.hpp - drivers of the hcucost core: linear predictors, simulation from given
// latent scores, and simulation with the core's own counter-based random numbers.
//
// * linear_predictors(): count means and severity linear predictors of every row (exactness
//   checks against the R reference count_mean() and linear_predictor()).
// * simulate_given(): counts and costs from latent scores supplied by the caller (z for the
//   counts, v for the severity or independent uniforms usev, and the share of the year lived).
//   With the scores the R reference draws, the result equals impactncd_healthcare_use().
// * simulate_rng(): the production path. One pass per person over their consecutive years:
//   latent paths z_t = perm + w_t with VAR(1) persistence (R reference sim_latent_paths()), drawn
//   from Philox keyed on (seed, pid, year, stream), so results do not depend on threads or
//   chunking and scenarios share random numbers (philox.hpp).
// Outputs are K column-major columns of n rows, in the input row order. OpenMP over rows or
// persons when compiled with OpenMP; no R API inside the parallel regions.
#ifndef HCUCOST_SIMULATE_HPP
#define HCUCOST_SIMULATE_HPP

#include <cstddef>
#include <cstdint>
#include <functional>

#include "model.hpp"
#include "philox.hpp"

#ifdef _OPENMP
#include <omp.h>
#endif

namespace hcucost {

// Count means mu and severity linear predictors eta0 (n x K each) for given shares of the year
// lived (prop; 1 for survivors).
inline void linear_predictors(const Model& M, const Inputs& in, const double* prop, int threads, double* mu,
                              double* eta0) {
  const long n = static_cast<long>(in.n);
  const int K = M.K;
#pragma omp parallel for num_threads(threads) schedule(static)
  for (long r = 0; r < n; ++r) {
    RowFeat f;
    row_features(M, in, static_cast<std::size_t>(r), prop[r], f);
    for (int k = 0; k < K; ++k) {
      mu[r + n * k] = count_mean(M, k, f);
      eta0[r + n * k] = severity_eta0(M, k, f);
    }
  }
}

// Simulate one row from its features and latent scores; writes counts/costs at row r.
inline void simulate_row(const Model& M, const RowFeat& f, const double* z, const double* v, const double* usev,
                         std::size_t r, std::size_t n, int* counts, double* costs) {
  const int K = M.K;
  int y[MAX_K];
  double eta0[MAX_K], l1py[MAX_K];
  for (int k = 0; k < K; ++k) {
    y[k] = draw_count(M.count[k], f.grp, count_mean(M, k, f), z[k]);
    eta0[k] = severity_eta0(M, k, f);
    l1py[k] = y[k] == NA_COUNT ? HCU_NAN : std::log1p(static_cast<double>(y[k]));
  }
  for (int k = 0; k < K; ++k) {
    counts[r + n * k] = y[k];
    costs[r + n * k] =
        draw_cost(M, k, f.grp, y, l1py, eta0[k], v != nullptr, v ? v[k] : 0.0, usev ? usev[k] : 0.5);
  }
}

// Simulation from given latent scores. z: n x K (count scores); v: n x K severity scores or
// nullptr; usev: n x K independent severity uniforms (used where v is nullptr); prop: n.
inline void simulate_given(const Model& M, const Inputs& in, const double* prop, const double* z, const double* v,
                           const double* usev, int threads, int* counts, double* costs) {
  const long n = static_cast<long>(in.n);
  const int K = M.K;
#pragma omp parallel for num_threads(threads) schedule(static)
  for (long r = 0; r < n; ++r) {
    RowFeat f;
    row_features(M, in, static_cast<std::size_t>(r), prop[r], f);
    double zr[MAX_K], vr[MAX_K], ur[MAX_K];
    for (int k = 0; k < K; ++k) {
      zr[k] = z[r + n * k];
      if (v) vr[k] = v[r + n * k];
      if (usev) ur[k] = usev[r + n * k];
    }
    simulate_row(M, f, zr, v ? vr : nullptr, usev ? ur : nullptr, static_cast<std::size_t>(r),
                 static_cast<std::size_t>(n), counts, costs);
  }
}

// out = e %*% U for a row vector e and an upper-triangular K x K U (column-major).
inline void mvn_row(const std::vector<double>& U, const double* e, int K, double* out) {
  for (int j = 0; j < K; ++j) {
    double s = 0.0;
    for (int i = 0; i <= j; ++i) s += e[i] * U[i + static_cast<std::size_t>(j) * K];
    out[j] = s;
  }
}

// K standard normals for (seed, pid, year, stream).
inline void philox_normals(std::uint64_t seed, std::uint64_t pid, std::uint32_t year, std::uint32_t stream, int K,
                           double* out) {
  philox_uniforms(seed, pid, year, stream, K, out);
  for (int k = 0; k < K; ++k) out[k] = norm_quantile(out[k]);
}

// One step of a latent block: w <- (first ? N(0, W) : A w + N(0, E)); z = perm + w.
inline void latent_step(const Persistence& P, bool first, std::uint64_t seed, std::uint64_t pid, std::uint32_t year,
                        std::uint32_t s_init, std::uint32_t s_innov, int K, const double* perm, double* w, double* z) {
  double e[MAX_K], x[MAX_K];
  if (first) {
    philox_normals(seed, pid, year, s_init, K, e);
    mvn_row(P.UW, e, K, w);
  } else {
    double aw[MAX_K];
    for (int j = 0; j < K; ++j) {
      double s = 0.0;
      for (int i = 0; i < K; ++i) s += P.A[j + static_cast<std::size_t>(i) * K] * w[i];
      aw[j] = s;
    }
    philox_normals(seed, pid, year, s_innov, K, e);
    mvn_row(P.UE, e, K, x);
    for (int j = 0; j < K; ++j) w[j] = aw[j] + x[j];
  }
  for (int j = 0; j < K; ++j) z[j] = perm[j] + w[j];
}

// Production simulation. Persons are the runs order[pstart[p]], ..., order[pstart[p + 1] - 1]
// (0-based row indices sorted by year within person); pid[p] is person p's id (whole number),
// year[r] the year of row r. prop is drawn in years of death. `check` is called between blocks
// of persons on the calling thread (e.g. to check for a user interrupt; it may throw).
inline void simulate_rng(const Model& M, const Inputs& in, const int* order, const int* pstart, long np,
                         const double* pid, const int* year, std::uint64_t seed, bool copula, int threads,
                         int* counts, double* costs, const std::function<void()>& check) {
  const int K = M.K;
  const std::size_t n = in.n;
  const bool use_v = copula && M.pv.present;
  const long block = 20000;
  for (long p0 = 0; p0 < np; p0 += block) {
    const long p1 = p0 + block < np ? p0 + block : np;
#pragma omp parallel for num_threads(threads) schedule(dynamic, 64)
    for (long p = p0; p < p1; ++p) {
      const std::uint64_t id = static_cast<std::uint64_t>(static_cast<std::int64_t>(pid[p]));
      double permz[MAX_K], wz[MAX_K], z[MAX_K], permv[MAX_K], wv[MAX_K], v[MAX_K], usev[MAX_K], e[MAX_K];
      if (copula) {
        philox_normals(seed, id, 0u, S_COUNT_PERM, K, e);
        mvn_row(M.pz.UP, e, K, permz);
        if (use_v) {
          philox_normals(seed, id, 0u, S_SEV_PERM, K, e);
          mvn_row(M.pv.UP, e, K, permv);
        }
      }
      for (int t = pstart[p]; t < pstart[p + 1]; ++t) {
        const std::size_t r = static_cast<std::size_t>(order[t]);
        const std::uint32_t yr = static_cast<std::uint32_t>(year[r]);
        const bool first = t == pstart[p];
        if (copula) {
          latent_step(M.pz, first, seed, id, yr, S_COUNT_INIT, S_COUNT_INNOV, K, permz, wz, z);
          if (use_v) latent_step(M.pv, first, seed, id, yr, S_SEV_INIT, S_SEV_INNOV, K, permv, wv, v);
        } else {
          philox_normals(seed, id, yr, S_COUNT_INDEP, K, z);
        }
        if (!use_v) philox_uniforms(seed, id, yr, S_SEV_UNIF, K, usev);
        double prop = 1.0;
        if (in.died[r] != 0) philox_uniforms(seed, id, yr, S_PROP, 1, &prop);
        RowFeat f;
        row_features(M, in, r, prop, f);
        simulate_row(M, f, z, use_v ? v : nullptr, use_v ? nullptr : usev, r, n, counts, costs);
      }
    }
    if (check) check();
  }
}

}  // namespace hcucost

#endif  // HCUCOST_SIMULATE_HPP
