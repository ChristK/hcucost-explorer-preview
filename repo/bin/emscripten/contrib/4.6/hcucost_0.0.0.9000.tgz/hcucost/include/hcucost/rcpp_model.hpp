// hcucost/rcpp_model.hpp - build the C++ model and inputs from R objects (Rcpp).
//
// The R function compile_params() (R/compile.R) turns a parameter list into a "compiled" list of
// plain vectors; model_from_list() converts that list into hcucost::Model. inputs_from_list()
// wraps the per-row input vectors (no copies for vectors of the right type). Other packages can
// include this header (LinkingTo: hcucost) to call the core from their own C++ code.
// Uses the R API: call on the main thread only (never inside an OpenMP region).
#ifndef HCUCOST_RCPP_MODEL_HPP
#define HCUCOST_RCPP_MODEL_HPP

#include <Rcpp.h>

#include <string>
#include <vector>

#include "model.hpp"

namespace hcucost {

inline std::vector<double> r_num(const Rcpp::List& L, const char* nm) {
  if (!L.containsElementNamed(nm)) Rcpp::stop(std::string("compiled model: missing element ") + nm);
  Rcpp::NumericVector x = L[nm];
  return std::vector<double>(x.begin(), x.end());
}

inline std::vector<int> r_int(const Rcpp::List& L, const char* nm) {
  if (!L.containsElementNamed(nm)) Rcpp::stop(std::string("compiled model: missing element ") + nm);
  Rcpp::IntegerVector x = L[nm];
  return std::vector<int>(x.begin(), x.end());
}

inline double r_dbl(const Rcpp::List& L, const char* nm) {
  std::vector<double> x = r_num(L, nm);
  if (x.size() != 1) Rcpp::stop(std::string("compiled model: ") + nm + " must be a single number");
  return x[0];
}

inline LinTerm term_from_list(const Rcpp::List& L) {
  LinTerm T;
  T.c0 = r_dbl(L, "c0");
  T.died = r_dbl(L, "died");
  T.died_logprop = r_dbl(L, "died_logprop");
  T.dies_next = r_dbl(L, "dies_next");
  T.age_sex = r_num(L, "age_sex");
  T.age_nc = r_num(L, "age_nc");
  T.bmi = r_num(L, "bmi");
  T.dimd = r_num(L, "dimd");
  T.eth = r_num(L, "eth");
  T.sha = r_num(L, "sha");
  T.smok = r_num(L, "smok");
  T.ncond = r_num(L, "ncond");
  T.died_age = r_num(L, "died_age");
  T.dn_age = r_num(L, "dn_age");
  T.died_ncond = r_num(L, "died_ncond");
  T.dn_ncond = r_num(L, "dn_ncond");
  T.died_prop = r_num(L, "died_prop");
  T.dis = r_num(L, "dis");
  T.any = r_num(L, "any");
  T.died_any = r_num(L, "died_any");
  T.dn_any = r_num(L, "dn_any");
  T.ca_other = r_num(L, "ca_other");
  return T;
}

// Fill a [N_GROUPS][N_BANDS] table from an R matrix (rows = groups, columns = bands).
template <typename T>
inline void group_band_table(const Rcpp::List& L, const char* nm, T out[N_GROUPS][N_BANDS]) {
  std::vector<double> x = r_num(L, nm);
  if (x.size() != static_cast<std::size_t>(N_GROUPS * N_BANDS)) Rcpp::stop(std::string("compiled model: bad ") + nm);
  for (int g = 0; g < N_GROUPS; ++g)
    for (int b = 0; b < N_BANDS; ++b) out[g][b] = static_cast<T>(x[g + N_GROUPS * b]);
}

// Every table of a term is empty or has exactly the size the core indexes (memory safety).
inline void check_term(const LinTerm& T, const Model& M, const char* what) {
  const std::size_t nA = static_cast<std::size_t>(M.age.n_int()), nB = static_cast<std::size_t>(M.bmi.n_int());
  int nab = 0;
  for (int b : M.agenc_band) nab = b + 1 > nab ? b + 1 : nab;
  const std::size_t D = static_cast<std::size_t>(M.D);
  const std::size_t n_age_band = M.death_age_cut.size() > 1 ? M.death_age_cut.size() - 1 : 1;
  const std::size_t n_prop_band = M.prop_cut.size() > 1 ? M.prop_cut.size() - 1 : 1;
  auto ok = [](const std::vector<double>& x, std::size_t want) { return x.empty() || x.size() == want; };
  const bool good = ok(T.age_sex, 2 * nA * 4) && ok(T.age_nc, static_cast<std::size_t>(nab) * nA * 4) &&
                    ok(T.bmi, nB * 4) && ok(T.dimd, static_cast<std::size_t>(M.n_dimd)) &&
                    ok(T.eth, static_cast<std::size_t>(M.n_eth)) && ok(T.sha, static_cast<std::size_t>(M.n_sha)) &&
                    ok(T.smok, static_cast<std::size_t>(M.n_smok)) && ok(T.ncond, D + 1) &&
                    ok(T.died_age, n_age_band) && ok(T.dn_age, n_age_band) && ok(T.died_ncond, D + 1) &&
                    ok(T.dn_ncond, D + 1) && ok(T.died_prop, n_prop_band) && ok(T.dis, D * N_BANDS) &&
                    ok(T.any, D) && ok(T.died_any, D) && ok(T.dn_any, D) && ok(T.ca_other, D + 1);
  if (!good) Rcpp::stop(std::string("compiled model: a table of ") + what + " has the wrong size");
}

inline Persistence persistence_from_list(const Rcpp::List& L, int K) {
  Persistence P;
  P.present = Rcpp::as<bool>(L["present"]);
  if (!P.present) return P;
  P.UP = r_num(L, "UP");
  P.UW = r_num(L, "UW");
  P.UE = r_num(L, "UE");
  P.A = r_num(L, "A");
  const std::size_t KK = static_cast<std::size_t>(K) * K;
  if (P.UP.size() != KK || P.UW.size() != KK || P.UE.size() != KK || P.A.size() != KK)
    Rcpp::stop("compiled model: persistence matrices must be K x K");
  return P;
}

inline Model model_from_list(const Rcpp::List& L) {
  if (!L.containsElementNamed("format") || Rcpp::as<int>(L["format"]) != 1)
    Rcpp::stop("compiled model: unknown format (recompile the model with this version of hcucost)");
  Model M;
  M.K = Rcpp::as<int>(L["K"]);
  M.D = Rcpp::as<int>(L["D"]);
  if (M.K < 1 || M.K > MAX_K) Rcpp::stop("compiled model: unsupported number of components");
  if (M.D < 0 || M.D > MAX_DISEASES) Rcpp::stop("compiled model: unsupported number of diseases");
  M.spell = r_int(L, "spell");
  M.cancer = r_int(L, "cancer");
  M.age.breaks = r_num(L, "age_breaks");
  M.bmi.breaks = r_num(L, "bmi_breaks");
  M.death_age_cut = r_num(L, "death_age_cut");
  M.prop_cut = r_num(L, "prop_cut");
  M.agenc_band = r_int(L, "agenc_band");
  M.n_dimd = Rcpp::as<int>(L["n_dimd"]);
  M.n_eth = Rcpp::as<int>(L["n_eth"]);
  M.n_sha = Rcpp::as<int>(L["n_sha"]);
  M.n_smok = Rcpp::as<int>(L["n_smok"]);
  if (M.age.breaks.size() < 2 || M.bmi.breaks.size() < 2) Rcpp::stop("compiled model: bad spline grids");
  if (M.spell.size() != static_cast<std::size_t>(M.D) || M.cancer.size() != static_cast<std::size_t>(M.D))
    Rcpp::stop("compiled model: spell/cancer must have one value per disease");
  if (!M.agenc_band.empty() && M.agenc_band.size() != static_cast<std::size_t>(M.D) + 1)
    Rcpp::stop("compiled model: agenc_band must have D + 1 values");
  for (int b : M.agenc_band)
    if (b < 0) Rcpp::stop("compiled model: bad agenc_band");
  Rcpp::List cl = L["count"], sl = L["sev"];
  if (cl.size() != M.K || sl.size() != M.K) Rcpp::stop("compiled model: count/severity parts must have K elements");
  for (int k = 0; k < M.K; ++k) {
    Rcpp::List c = cl[k];
    CountPart C;
    C.oth = term_from_list(c["oth"]);
    C.dis = term_from_list(c["dis"]);
    C.gamma = r_dbl(c, "gamma");
    std::vector<int> recal = r_int(c, "recal"), hurdle = r_int(c, "hurdle");
    std::vector<double> ra = r_num(c, "ralpha"), rb = r_num(c, "rbeta"), ha = r_num(c, "ha"), hb = r_num(c, "hb");
    Rcpp::List cal = c["cal"], th = c["theta"], br = c["breaks"], hth = c["htheta"], hbr = c["hbreaks"];
    for (int g = 0; g < N_GROUPS; ++g) {
      C.recal[g] = recal[g] != 0;
      C.ralpha[g] = ra[g];
      C.rbeta[g] = rb[g];
      C.cal[g] = term_from_list(cal[g]);
      C.theta[g] = Rcpp::as<std::vector<double>>(th[g]);
      C.breaks[g] = Rcpp::as<std::vector<double>>(br[g]);
      C.hurdle[g] = hurdle[g] != 0;
      C.ha[g] = ha[g];
      C.hb[g] = hb[g];
      C.htheta[g] = Rcpp::as<std::vector<double>>(hth[g]);
      C.hbreaks[g] = Rcpp::as<std::vector<double>>(hbr[g]);
      check_term(C.cal[g], M, "a count calibration");
      if (C.theta[g].size() != C.breaks[g].size() + 1) Rcpp::stop("compiled model: theta bands and breaks disagree");
      if (C.hurdle[g] && C.htheta[g].size() != C.hbreaks[g].size() + 1)
        Rcpp::stop("compiled model: hurdle theta bands and breaks disagree");
    }
    check_term(C.oth, M, "a count part");
    check_term(C.dis, M, "a count part");
    M.count.push_back(C);
    Rcpp::List s = sl[k];
    SevPart S;
    S.oth = term_from_list(s["oth"]);
    S.dis = term_from_list(s["dis"]);
    S.gamma = r_dbl(s, "gamma");
    group_band_table(s, "own", S.own);
    group_band_table(s, "phi", S.phi);
    group_band_table(s, "mixcell", S.mixcell);
    S.l1p = r_num(s, "l1p");
    if (S.l1p.size() != static_cast<std::size_t>(M.K)) Rcpp::stop("compiled model: l1p must have K elements");
    S.lognormal = Rcpp::as<int>(s["lognormal"]);
    Rcpp::List mx = s["mix_x"], my = s["mix_y"];
    for (R_xlen_t i = 0; i < mx.size(); ++i) {
      S.mix_x.push_back(Rcpp::as<std::vector<double>>(mx[i]));
      S.mix_y.push_back(Rcpp::as<std::vector<double>>(my[i]));
    }
    for (int g = 0; g < N_GROUPS; ++g)
      for (int b = 0; b < N_BANDS; ++b)
        if (S.mixcell[g][b] >= static_cast<int>(S.mix_x.size())) Rcpp::stop("compiled model: bad mixture cell");
    for (std::size_t i = 0; i < S.mix_x.size(); ++i)
      if (S.mix_x[i].empty() || S.mix_x[i].size() != S.mix_y[i].size()) Rcpp::stop("compiled model: bad mixture grid");
    check_term(S.oth, M, "a severity part");
    check_term(S.dis, M, "a severity part");
    M.sev.push_back(S);
  }
  M.pz = persistence_from_list(L["pz"], M.K);
  M.pv = persistence_from_list(L["pv"], M.K);
  prepare_model(M);
  return M;
}

// Per-row inputs kept alive for the duration of a call (pointers into R vectors).
struct InputsHolder {
  Rcpp::NumericVector age, bmi;
  Rcpp::IntegerVector sex, dimd, eth, sha, smok, died, dies_next;
  std::vector<Rcpp::IntegerVector> prvl;
  Inputs in;
};

inline void inputs_from_list(const Rcpp::List& L, const Model& M, InputsHolder& h) {
  h.age = L["age"];
  h.bmi = L["bmi"];
  h.sex = L["sex"];
  h.dimd = L["dimd"];
  h.eth = L["eth"];
  h.sha = L["sha"];
  h.smok = L["smok"];
  h.died = L["died"];
  h.dies_next = L["dies_next"];
  Rcpp::List pv = L["prvl"];
  if (pv.size() != M.D) Rcpp::stop("inputs: prvl must hold one vector per disease");
  const R_xlen_t n = h.age.size();
  if (h.bmi.size() != n || h.sex.size() != n || h.dimd.size() != n || h.eth.size() != n || h.sha.size() != n ||
      h.smok.size() != n || h.died.size() != n || h.dies_next.size() != n)
    Rcpp::stop("inputs: all vectors must have the same length");
  h.in.n = static_cast<std::size_t>(n);
  h.in.age = h.age.begin();
  h.in.bmi = h.bmi.begin();
  h.in.sex = h.sex.begin();
  h.in.dimd = h.dimd.begin();
  h.in.eth = h.eth.begin();
  h.in.sha = h.sha.begin();
  h.in.smok = h.smok.begin();
  h.in.died = h.died.begin();
  h.in.dies_next = h.dies_next.begin();
  h.prvl.clear();
  for (int d = 0; d < M.D; ++d) {
    h.prvl.push_back(Rcpp::IntegerVector(pv[d]));
    if (h.prvl.back().size() != n) Rcpp::stop("inputs: prvl vectors must have the same length as age");
  }
  h.in.prvl.clear();
  for (int d = 0; d < M.D; ++d) h.in.prvl.push_back(h.prvl[d].begin());
  // codes must be in range (the core indexes tables with them)
  auto check_codes = [n](const Rcpp::IntegerVector& x, int hi, const char* nm) {
    for (R_xlen_t i = 0; i < n; ++i)
      if (x[i] < 1 || x[i] > hi) Rcpp::stop(std::string("inputs: ") + nm + " codes out of range");
  };
  check_codes(h.sex, 2, "sex");
  check_codes(h.dimd, M.n_dimd, "dimd");
  check_codes(h.eth, M.n_eth, "eth");
  check_codes(h.sha, M.n_sha, "sha");
  check_codes(h.smok, M.n_smok, "smok");
  for (R_xlen_t i = 0; i < n; ++i)
    if (std::isnan(h.age[i]) || std::isnan(h.bmi[i])) Rcpp::stop("inputs: missing age or BMI");
}

}  // namespace hcucost

#endif  // HCUCOST_RCPP_MODEL_HPP
