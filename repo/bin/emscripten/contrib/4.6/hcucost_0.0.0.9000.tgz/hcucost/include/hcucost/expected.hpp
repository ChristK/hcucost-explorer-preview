// hcucost/expected.hpp - expected counts and costs of single person-years without simulation
// (2026-11-08; investigation in the package's process scripts ev_01-ev_06).
//
// For a row with given predictors and death group g (in the year of death also the share of the
// year lived p, uniform on (0, 1) in the simulation), the simulation of simulate_row() has:
//   * E[n_k] = mu_k exactly: the negative binomial margin has mean mu, and the hurdle margin keeps
//     it (its zero-truncated part is scaled by hurdle_mustar());
//   * E[cost_k | counts n] = n_k exp(eta0_k + own[g][band(n_k)] + sum_{o != k} l1p_k[o] log1p(n_o))
//     * Mult_k[g][band(n_k)] exactly: the severity scores are independent of the count scores, and the
//     cost multiplier has mean Mult (1 for gamma and lognormal cells with unit-variance severity
//     scores; for the two-lognormal mixture cells, the mean of exp(approx(v)) over its interpolation
//     grid, in closed form piece by piece);
//   * E[cost_k] is that conditional mean averaged over the Gaussian copula of the counts: latent
//     scores z ~ N(0, P + W) (the stationary single-year distribution of simulate_rng(); identity when
//     the model has no persistence), counts n_k = F_k^-1(Phi(z_k)) from a table of the margin's
//     distribution function. The average is taken by randomised quasi-Monte Carlo: a Halton point set
//     (from R) with Cranley-Patterson random shifts drawn from Philox keyed on (seed, key, shift), so
//     results are reproducible and do not depend on threads; the spread of the per-shift estimates
//     gives the error. There is no closed form: the cost per unit depends on every other count
//     (l1p), and the counts are dependent.
//   * In the year of death the share of the year lived is integrated with quadrature nodes and
//     weights from R (Gauss-Legendre within the model's share-of-year bands); every node uses its own
//     margins and the first rows of the point set.
// Simulation details ignored as negligible: the clamps of the uniforms at 1e-12 and 1 - 1e-12 in the
// severity draws (relative effect below 1e-7) and R's left-continuity fuzz of the quantiles (measure
// zero). The count margins are capped at the quantile of 1 - 1e-12, exactly as the simulation.
// Header-only, no R API.
#ifndef HCUCOST_EXPECTED_HPP
#define HCUCOST_EXPECTED_HPP

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <vector>

#include "model.hpp"
#include "nmath.hpp"
#include "philox.hpp"
#include "simulate.hpp"

namespace hcucost {

// Distribution function table of a negative binomial (shape size, mean mu) for y = 0, 1, ..., up to
// the quantile at `top`; the last entry is set to 1 (the simulation never draws above that quantile).
// The pmf recurrence runs in logs, so long tails do not underflow.
inline void nb_cdf_table(double size, double mu, double top, std::vector<double>& F) {
  F.clear();
  if (!(mu > 0) || !(size > 0)) {  // the simulation's quantile is 0 (nbinom_quantile_mu())
    F.push_back(1.0);
    return;
  }
  double lf = size * (size < mu ? std::log(size / (size + mu)) : std::log1p(-mu / (size + mu)));
  const double ratio = mu / (size + mu);
  const double lr = std::log(ratio);
  double cum = 0.0;
  if (lf > -700) {  // the usual case: the multiplicative recurrence (as nbinom_quantile_mu()), no logs
    double f = std::exp(lf);
    for (double y = 0.0;; y += 1.0) {
      cum += f;
      const double r = (y + size) / (y + 1.0) * ratio;
      const bool tail_done = r < 1.0 && f * r / (1.0 - r) < 1e-14;
      if (cum >= top || tail_done || y > 1e7) {
        F.push_back(1.0);
        return;
      }
      F.push_back(cum);
      f *= r;
    }
  }
  for (double y = 0.0;; y += 1.0) {  // P(Y = 0) underflows: the recurrence in logs
    const double f = std::exp(lf);
    cum += f;
    // ratio of the next pmf term to this one; past the mode it is below 1, and the tail is at most
    // f r / (1 - r)
    const double r = (y + size) / (y + 1.0) * (mu / (size + mu));
    const bool tail_done = r < 1.0 && f * r / (1.0 - r) < 1e-14;
    if (cum >= top || tail_done || y > 1e7) {
      F.push_back(1.0);
      return;
    }
    F.push_back(cum);
    lf += std::log((y + size) / (y + 1.0)) + lr;
  }
}

// Distribution function table of count k's margin in group g at mean mu (draw_count()).
inline void margin_cdf_table(const CountPart& C, int g, double mu, std::vector<double>& F, std::vector<double>& work) {
  const double top = 1 - 1e-12;
  if (!(mu > 0)) {
    F.assign(1, 1.0);
    return;
  }
  if (C.hurdle[g]) {
    const double p = hurdle_p(mu, C.ha[g], C.hb[g]);
    const double th = band_value(C.htheta[g], C.hbreaks[g], mu);
    const double ms = hurdle_mustar(mu, p, th);
    const double f0 = nbinom_p0_mu(th, ms);
    const double q0 = 1 - p;
    nb_cdf_table(th, ms, top, work);  // positive part: quantiles of pp <= 1 - 1e-12
    F.assign(work.size() > 1 ? work.size() : 2, 1.0);
    F[0] = q0;
    for (std::size_t y = 1; y + 1 < work.size(); ++y) F[y] = q0 + p * (work[y] - f0) / (1 - f0);
    F.back() = 1.0;
  } else {
    nb_cdf_table(band_value(C.theta[g], C.breaks[g], mu), mu, top, F);
  }
}

// Smallest y with F[y] >= u (F ends with 1).
inline int table_quantile(const std::vector<double>& F, double u) {
  return static_cast<int>(std::lower_bound(F.begin(), F.end(), u) - F.begin());
}

// Mean of the cost multiplier of every component x death group x own-count band, for severity
// scores with variance s2[k] (diag(P + W) of the severity block; 1 without persistence, where the
// simulation uses qnorm of a uniform).
struct ExpectTables {
  std::vector<double> mult;   // [k][g][band]
  std::vector<double> UZ;     // upper Cholesky factor of the count scores' covariance (K x K, column-major)
};

// E[exp(approx(v))] for v ~ N(0, s2), approx linear in v between the grid points and constant
// outside: on each piece exp(a + b v), whose normal integral is closed-form.
inline double mixture_mean(const std::vector<double>& x, const std::vector<double>& y, double s2) {
  const std::size_t n = x.size();
  const double s = std::sqrt(s2);
  double m = std::exp(y[0]) * norm_cdf(x[0] / s) + std::exp(y[n - 1]) * (1 - norm_cdf(x[n - 1] / s));
  for (std::size_t i = 0; i + 1 < n; ++i) {
    if (!(x[i + 1] > x[i])) continue;
    const double b = (y[i + 1] - y[i]) / (x[i + 1] - x[i]);
    const double a = y[i] - b * x[i];
    const double c = b * s;  // in z = v / s: exp(a + c z)
    m += std::exp(a + c * c / 2) * (norm_cdf(x[i + 1] / s - c) - norm_cdf(x[i] / s - c));
  }
  return m;
}

// Mean of a gamma (shape 1/phi, mean 1) or lognormal multiplier when the severity score's variance
// s2 is not 1 (Simpson's rule in z on [-9, 9]); 1 when it is.
inline double unit_mean(const SevPart& S, int g, int b, double s2) {
  if (std::fabs(s2 - 1) < 1e-9) return 1.0;
  if (S.lognormal) return std::exp(S.lsd[g][b] * S.lsd[g][b] * s2 / 2 - S.lhalf[g][b]);
  const int n = 3600;
  const double lo = -9, h = 18.0 / n, s = std::sqrt(s2);
  double acc = 0;
  for (int i = 0; i <= n; ++i) {
    const double z = lo + i * h;
    double u = norm_cdf(s * z);
    u = u < 1e-12 ? 1e-12 : (u > 1 - 1e-12 ? 1 - 1e-12 : u);
    const double w = (i == 0 || i == n) ? 1 : (i % 2 ? 4 : 2);
    acc += w * std::exp(-z * z / 2) * gamma_quantile(u, S.shape[g][b], S.phi[g][b]);
  }
  return acc * h / 3 / 2.5066282746310002;  // sqrt(2 pi) (M_PI is not standard C++)
}

inline std::vector<double> chol_upper_of_sum(const Persistence& P, int K) {
  // U with U'U = P + W (Cholesky of the sum of the two blocks' covariances)
  std::vector<double> S(static_cast<std::size_t>(K) * K, 0.0), U(static_cast<std::size_t>(K) * K, 0.0);
  for (int a = 0; a < K; ++a)
    for (int b = 0; b < K; ++b) {
      double s = 0;
      for (int i = 0; i < K; ++i) {
        s += P.UP[i + static_cast<std::size_t>(a) * K] * P.UP[i + static_cast<std::size_t>(b) * K];
        s += P.UW[i + static_cast<std::size_t>(a) * K] * P.UW[i + static_cast<std::size_t>(b) * K];
      }
      S[a + static_cast<std::size_t>(b) * K] = s;
    }
  for (int j = 0; j < K; ++j) {
    for (int i = 0; i <= j; ++i) {
      double s = S[i + static_cast<std::size_t>(j) * K];
      for (int l = 0; l < i; ++l) s -= U[l + static_cast<std::size_t>(i) * K] * U[l + static_cast<std::size_t>(j) * K];
      if (i == j) U[i + static_cast<std::size_t>(j) * K] = std::sqrt(s);
      else U[i + static_cast<std::size_t>(j) * K] = s / U[i + static_cast<std::size_t>(i) * K];
    }
  }
  return U;
}

// copula = false: independent count scores and standard normal severity scores (simulate_rng() with
// copula = false); otherwise the models' persistence blocks, where present.
inline ExpectTables prepare_expect(const Model& M, bool copula = true) {
  const int K = M.K;
  ExpectTables T;
  T.mult.assign(static_cast<std::size_t>(K) * N_GROUPS * N_BANDS, 1.0);
  for (int k = 0; k < K; ++k) {
    double s2 = 1.0;
    if (copula && M.pv.present) {
      s2 = 0;
      for (int i = 0; i < K; ++i) {
        const double up = M.pv.UP[i + static_cast<std::size_t>(k) * K], uw = M.pv.UW[i + static_cast<std::size_t>(k) * K];
        s2 += up * up + uw * uw;
      }
    }
    const SevPart& S = M.sev[k];
    for (int g = 0; g < N_GROUPS; ++g)
      for (int b = 0; b < N_BANDS; ++b) {
        const int cell = S.mixcell[g][b];
        T.mult[(static_cast<std::size_t>(k) * N_GROUPS + g) * N_BANDS + b] =
            cell >= 0 ? mixture_mean(S.mix_x[cell], S.mix_y[cell], s2) : unit_mean(S, g, b, s2);
      }
  }
  if (copula && M.pz.present) {
    T.UZ = chol_upper_of_sum(M.pz, K);
  } else {
    T.UZ.assign(static_cast<std::size_t>(K) * K, 0.0);
    for (int k = 0; k < K; ++k) T.UZ[k + static_cast<std::size_t>(k) * K] = 1.0;
  }
  return T;
}

// Workspace of one thread.
struct ExpectWork {
  std::vector<std::vector<double>> F;  // [k] margin tables
  std::vector<double> nbwork;
  explicit ExpectWork(int K) : F(static_cast<std::size_t>(K)) {}
};

// Adds w * (per-shift mean cost of each component) at one share of the year (features f) to
// acc[s * K + k], using the first m points of the Halton set H (m_all x K, column-major) with the
// shifts sh (n_shifts x K); returns the K count means mu in mu_out.
inline void expect_node(const Model& M, const ExpectTables& T, const RowFeat& f, const double* H, int m_all, int m,
                        const double* sh, int n_shifts, double w, ExpectWork& W, double* acc, double* mu_out) {
  const int K = M.K, g = f.grp;
  double eta0[MAX_K];
  for (int k = 0; k < K; ++k) {
    const double mu = count_mean(M, k, f);
    mu_out[k] = mu;
    eta0[k] = severity_eta0(M, k, f);
    margin_cdf_table(M.count[k], g, mu, W.F[k], W.nbwork);
  }
  for (int s = 0; s < n_shifts; ++s) {
    double sum[MAX_K] = {};
    for (int i = 0; i < m; ++i) {
      double e[MAX_K], z[MAX_K], l1py[MAX_K];
      int y[MAX_K];
      for (int k = 0; k < K; ++k) {
        double u = H[i + static_cast<std::size_t>(k) * m_all] + sh[s * K + k];
        u -= std::floor(u);
        if (u <= 0) u = 1e-16;
        e[k] = norm_quantile(u);
      }
      mvn_row(T.UZ, e, K, z);
      for (int k = 0; k < K; ++k) {
        y[k] = table_quantile(W.F[k], norm_cdf(z[k]));
        l1py[k] = std::log1p(static_cast<double>(y[k]));
      }
      for (int k = 0; k < K; ++k) {
        const int n = y[k];
        if (n <= 0) continue;
        const SevPart& S = M.sev[k];
        const int b = count_band(n);
        double eta = eta0[k] + S.own[g][b];
        for (int o = 0; o < K; ++o)
          if (o != k) eta += S.l1p[o] * l1py[o];
        sum[k] += n * std::exp(eta) * T.mult[(static_cast<std::size_t>(k) * N_GROUPS + g) * N_BANDS + b];
      }
    }
    for (int k = 0; k < K; ++k) acc[s * K + k] += w * sum[k] / m;
  }
}

// Expected counts and costs of every row, its death group from died / dies_next. Rows dying in the
// year integrate the share of the year lived over the nodes px with weights pw (summing to 1); other
// rows have prop = 1. H: Halton points (m_all x K, column-major, in (0, 1)); m01 of them per shift for
// groups 0 and 1, m2 per shift at each node of the year of death. key[r] and year[r] (year may be null:
// 0) key row r's shifts: hcu_predict() keys on the completed record (its death groups share them),
// hcu_expected_impactncd() on (pid, year), so scenarios share each person-year's shifts (common random
// numbers, as the simulation); n_shifts <= 256. Outputs (column-major): counts n x K (the means mu),
// costs n x K (average over the shifts), and either shift_total n x n_shifts (total cost of each shift's
// estimate; shifts_out) or se n (standard error of the row's total cost from the spread of the shifts).
inline void expected_rows(const Model& M, const Inputs& in, const double* key, const int* year, const double* H,
                          int m_all, int m01, int m2, const double* px, const double* pw, int n_nodes,
                          std::uint64_t seed, int n_shifts, bool copula, int threads, double* counts, double* costs,
                          bool shifts_out, double* shift_total, double* se) {
  const ExpectTables T = prepare_expect(M, copula);
  const long n = static_cast<long>(in.n);
  const int K = M.K;
#pragma omp parallel num_threads(threads)
  {
    ExpectWork W(K);
    std::vector<double> sh(static_cast<std::size_t>(n_shifts) * K), acc(static_cast<std::size_t>(n_shifts) * K);
#pragma omp for schedule(dynamic, 16)
    for (long r = 0; r < n; ++r) {
      const std::uint64_t id = static_cast<std::uint64_t>(static_cast<std::int64_t>(key[r]));
      const std::uint32_t yr = year ? static_cast<std::uint32_t>(year[r]) : 0u;
      for (int s = 0; s < n_shifts; ++s)
        philox_uniforms(seed, id, yr * 256u + static_cast<std::uint32_t>(s), S_QMC_SHIFT, K,
                        &sh[static_cast<std::size_t>(s) * K]);
      std::fill(acc.begin(), acc.end(), 0.0);
      double mu[MAX_K], musum[MAX_K] = {};
      RowFeat f;
      if (in.died[r] != 0) {
        for (int j = 0; j < n_nodes; ++j) {
          row_features(M, in, static_cast<std::size_t>(r), px[j], f);
          expect_node(M, T, f, H, m_all, m2, sh.data(), n_shifts, pw[j], W, acc.data(), mu);
          for (int k = 0; k < K; ++k) musum[k] += pw[j] * mu[k];
        }
      } else {
        row_features(M, in, static_cast<std::size_t>(r), 1.0, f);
        expect_node(M, T, f, H, m_all, m01, sh.data(), n_shifts, 1.0, W, acc.data(), mu);
        for (int k = 0; k < K; ++k) musum[k] = mu[k];
      }
      for (int k = 0; k < K; ++k) {
        double c = 0;
        for (int s = 0; s < n_shifts; ++s) c += acc[static_cast<std::size_t>(s) * K + k];
        counts[r + n * k] = musum[k];
        costs[r + n * k] = c / n_shifts;
      }
      double tsum = 0, tsq = 0;
      for (int s = 0; s < n_shifts; ++s) {
        double t = 0;
        for (int k = 0; k < K; ++k) t += acc[static_cast<std::size_t>(s) * K + k];
        if (shifts_out) shift_total[r + n * s] = t;
        tsum += t;
        tsq += t * t;
      }
      if (!shifts_out) {
        const double mean = tsum / n_shifts;
        const double var = (tsq - n_shifts * mean * mean) / (n_shifts - 1);
        se[r] = std::sqrt((var > 0 ? var : 0) / n_shifts);
      }
    }
  }
}

}  // namespace hcucost

#endif  // HCUCOST_EXPECTED_HPP
