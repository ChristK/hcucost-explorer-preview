// hcucost/nmath.hpp - distribution functions of the hcucost core, thread-safe (no R API).
//
// The R reference implementation (R/reference.R) uses R's pnorm, qnorm, qnbinom, dnbinom, qgamma,
// plogis and approx. The core reproduces them (the C++ names differ from R's on purpose: R's
// Rmath.h, included by Rcpp.h, #defines pnorm, qnorm, qgamma, ... as macros):
//   * norm_cdf: port of R's pnorm_both() (W. J. Cody's rational Chebyshev approximation, R 4.6.1
//     src/nmath/pnorm.c), lower tail; bit-identical to R's pnorm();
//   * norm_quantile: port of R's qnorm() (Wichura's AS 241 with R's extension for
//     |log p| > 27^2, R 4.6.1 src/nmath/qnorm.c), lower tail; bit-identical to R's qnorm();
//   * nbinom_quantile_mu: the definition R's qnbinom() search implements (R 4.6.1
//     src/nmath/qDiscrete_search.h): the smallest y >= 0 with P(Y <= y) >= p * (1 - 8 * DBL_EPSILON).
//     The distribution function is accumulated from the probability mass function by its
//     recurrence (small means), or from Boost's incomplete beta function at the Cornish-Fisher
//     start (large means);
//   * nbinom_p0_mu: R's dnbinom_mu() formula for x = 0;
//   * gamma_quantile: Boost.Math gamma_p_inv (R's qgamma() uses AS 91 with Newton steps; both agree
//     to about 1e-14 relative, checked in inst/tinytest/test_core_exact.R);
//   * logis_cdf (R's plogis()), rpow (R's `^`), approx_linear (R's approx(), method "linear",
//     rule = 2).
// R is free software under the GPL (>= 2); hcucost is GPL (>= 3).
#ifndef HCUCOST_NMATH_HPP
#define HCUCOST_NMATH_HPP

#include <cfloat>
#include <cmath>
#include <cstddef>
#include <limits>

#include <boost/math/distributions/negative_binomial.hpp>
#include <boost/math/policies/policy.hpp>
#include <boost/math/special_functions/beta.hpp>
#include <boost/math/special_functions/gamma.hpp>

namespace hcucost {

// Boost policy: errors give NaN/Inf instead of exceptions (exceptions must not escape OpenMP
// threads), and double precision throughout (no promotion to long double).
typedef boost::math::policies::policy<
    boost::math::policies::domain_error<boost::math::policies::ignore_error>,
    boost::math::policies::pole_error<boost::math::policies::ignore_error>,
    boost::math::policies::overflow_error<boost::math::policies::ignore_error>,
    boost::math::policies::underflow_error<boost::math::policies::ignore_error>,
    boost::math::policies::evaluation_error<boost::math::policies::ignore_error>,
    boost::math::policies::rounding_error<boost::math::policies::ignore_error>,
    boost::math::policies::promote_float<false>, boost::math::policies::promote_double<false>>
    BoostPolicy;

constexpr double HCU_INF = std::numeric_limits<double>::infinity();
constexpr double HCU_NAN = std::numeric_limits<double>::quiet_NaN();

// R's x^y (arithmetic.c: R_POW, R_pow): exact square for y == 2, 1 for x == 1 or y == 0.
inline double rpow(double x, double y) {
  if (y == 2.0) return x * x;
  if (x == 1.0 || y == 0.0) return 1.0;
  if (x == 0.0) return y > 0.0 ? 0.0 : (y < 0.0 ? HCU_INF : y);
  return std::pow(x, y);
}

// Standard normal distribution function, lower tail (R's pnorm(x)). ldexp(x, k) of R's code is
// written as multiplication by 2^k: exact, so the results are unchanged.
inline double norm_cdf(double x) {
  static const double a[5] = {2.2352520354606839287, 161.02823106855587881, 1067.6894854603709582,
                              18154.981253343561249, 0.065682337918207449113};
  static const double b[4] = {47.20258190468824187, 976.09855173777669322, 10260.932208618978205,
                              45507.789335026729956};
  static const double c[9] = {0.39894151208813466764, 8.8831497943883759412, 93.506656132177855979,
                              597.27027639480026226,  2494.5375852903726711, 6848.1904505362823326,
                              11602.651437647350124,  9842.7148383839780218, 1.0765576773720192317e-8};
  static const double d[8] = {22.266688044328115691, 235.38790178262499861, 1519.377599407554805,
                              6485.558298266760755,  18615.571640885098091, 34900.952721145977266,
                              38912.003286093271411, 19685.429676859990727};
  static const double p[6] = {0.21589853405795699,     0.1274011611602473639, 0.022235277870649807,
                              0.001421619193227893466, 2.9112874951168792e-5, 0.02307344176494017303};
  static const double q[5] = {1.28426009614491121, 0.468238212480865118, 0.0659881378689285515,
                              0.00378239633202758244, 7.29751555083966205e-5};
  const double M_SQRT_32_ = 5.656854249492380195206754896838;
  const double M_1_SQRT_2PI_ = 0.398942280401432677939946059934;
  if (std::isnan(x)) return x;
  if (x == -HCU_INF) return 0.0;
  if (x == HCU_INF) return 1.0;
  const double eps = DBL_EPSILON * 0.5;
  const double y = std::fabs(x);
  double xnum, xden, temp, xsq, del, cum, ccum;
  if (y <= 0.67448975) {
    if (y > eps) {
      xsq = x * x;
      xnum = a[4] * xsq;
      xden = xsq;
      for (int i = 0; i < 3; ++i) {
        xnum = (xnum + a[i]) * xsq;
        xden = (xden + b[i]) * xsq;
      }
    } else {
      xnum = xden = 0.0;
    }
    temp = x * (xnum + a[3]) / (xden + b[3]);
    return 0.5 + temp;
  } else if (y <= M_SQRT_32_) {
    xnum = c[8] * y;
    xden = y;
    for (int i = 0; i < 7; ++i) {
      xnum = (xnum + c[i]) * y;
      xden = (xden + d[i]) * y;
    }
    temp = (xnum + c[7]) / (xden + d[7]);
    xsq = std::trunc(y * 16) * 0.0625;
    del = (y - xsq) * (y + xsq);
    cum = std::exp(-xsq * (xsq * 0.5)) * std::exp(-(del * 0.5)) * temp;
    ccum = 1.0 - cum;
    return x > 0.0 ? ccum : cum;
  } else if (-38.4674 < x && x < 8.2924) {
    xsq = 1.0 / (x * x);
    xnum = p[5] * xsq;
    xden = xsq;
    for (int i = 0; i < 4; ++i) {
      xnum = (xnum + p[i]) * xsq;
      xden = (xden + q[i]) * xsq;
    }
    temp = xsq * (xnum + p[4]) / (xden + q[4]);
    temp = (M_1_SQRT_2PI_ - temp) / y;
    xsq = std::trunc(x * 16) * 0.0625;
    del = (x - xsq) * (x + xsq);
    cum = std::exp(-xsq * (xsq * 0.5)) * std::exp(-(del * 0.5)) * temp;
    ccum = 1.0 - cum;
    return x > 0.0 ? ccum : cum;
  }
  return x > 0.0 ? 1.0 : 0.0;
}

// Standard normal quantile function, lower tail (R's qnorm(p)).
inline double norm_quantile(double p) {
  if (std::isnan(p)) return p;
  if (p <= 0.0) return p == 0.0 ? -HCU_INF : HCU_NAN;
  if (p >= 1.0) return p == 1.0 ? HCU_INF : HCU_NAN;
  const double q = p - 0.5;
  double r, val;
  if (std::fabs(q) <= .425) {
    r = .180625 - q * q;
    val = q *
          (((((((r * 2509.0809287301226727 + 33430.575583588128105) * r + 67265.770927008700853) * r +
               45921.953931549871457) * r + 13731.693765509461125) * r + 1971.5909503065514427) * r +
            133.14166789178437745) * r + 3.387132872796366608) /
          (((((((r * 5226.495278852854561 + 28729.085735721942674) * r + 39307.89580009271061) * r +
               21213.794301586595867) * r + 5394.1960214247511077) * r + 687.1870074920579083) * r +
            42.313330701600911252) * r + 1.);
    return val;
  }
  const double lp = std::log(q > 0 ? (0.5 - p + 0.5) : p);
  r = std::sqrt(-lp);
  if (r <= 5.) {
    r += -1.6;
    val = (((((((r * 7.7454501427834140764e-4 + .0227238449892691845833) * r + .24178072517745061177) * r +
               1.27045825245236838258) * r + 3.64784832476320460504) * r + 5.7694972214606914055) * r +
            4.6303378461565452959) * r + 1.42343711074968357734) /
          (((((((r * 1.05075007164441684324e-9 + 5.475938084995344946e-4) * r + .0151986665636164571966) * r +
               .14810397642748007459) * r + .68976733498510000455) * r + 1.6763848301838038494) * r +
            2.05319162663775882187) * r + 1.);
  } else if (r <= 27) {
    r += -5.;
    val = (((((((r * 2.01033439929228813265e-7 + 2.71155556874348757815e-5) * r + .0012426609473880784386) * r +
               .026532189526576123093) * r + .29656057182850489123) * r + 1.7848265399172913358) * r +
            5.4637849111641143699) * r + 6.6579046435011037772) /
          (((((((r * 2.04426310338993978564e-15 + 1.4215117583164458887e-7) * r + 1.8463183175100546818e-5) * r +
               7.868691311456132591e-4) * r + .0148753612908506148525) * r + .13692988092273580531) * r +
            .59983220655588793769) * r + 1.);
  } else {  // p within exp(-729) of 0 or 1: asymptotic expansion (R >= 4.3)
    const double M_2PI_ = 6.283185307179586476925286766559;
    if (r >= 6.4e8) {
      val = r * 1.414213562373095048801688724210;
    } else {
      const double s2 = -std::ldexp(lp, 1);
      double x2 = s2 - std::log(M_2PI_ * s2);
      if (r < 36000.) {
        x2 = s2 - std::log(M_2PI_ * x2) - 2. / (2. + x2);
        if (r < 840.) {
          x2 = s2 - std::log(M_2PI_ * x2) + 2 * std::log1p(-(1 - 1 / (4 + x2)) / (2. + x2));
          if (r < 109.) {
            x2 = s2 - std::log(M_2PI_ * x2) + 2 * std::log1p(-(1 - (1 - 5 / (6 + x2)) / (4. + x2)) / (2. + x2));
            if (r < 55.) {
              x2 = s2 - std::log(M_2PI_ * x2) +
                   2 * std::log1p(-(1 - (1 - (5 - 9 / (8. + x2)) / (6. + x2)) / (4. + x2)) / (2. + x2));
            }
          }
        }
      }
      val = std::sqrt(x2);
    }
  }
  return q < 0.0 ? -val : val;
}

// Logistic distribution function (R's plogis(x)).
inline double logis_cdf(double x) {
  if (std::isnan(x)) return x;
  return 1 / (1 + std::exp(-x));
}

// P(Y = 0) of the negative binomial with shape `size` and mean `mu` (R's dnbinom(0, size, mu = mu)).
inline double nbinom_p0_mu(double size, double mu) {
  if (std::isnan(size) || std::isnan(mu)) return size + mu;
  if (size == 0) return 1.0;
  return std::exp(size * (size < mu ? std::log(size / (size + mu)) : std::log1p(-mu / (size + mu))));
}

// Negative binomial quantile (R's qnbinom(p, size = size, mu = mu), lower tail):
// smallest y >= 0 with F(y) >= p * (1 - 8 * DBL_EPSILON).
inline double nbinom_quantile_mu(double p, double size, double mu) {
  if (std::isnan(p) || std::isnan(size) || std::isnan(mu)) return p + size + mu;
  if (mu < 0 || size < 0) return HCU_NAN;
  if (mu == 0 || size == 0) return 0.0;
  if (p < 0 || p > 1) return HCU_NAN;
  if (p == 0) return 0.0;
  if (p == 1) return HCU_INF;
  const double pt = p * (1 - 8 * DBL_EPSILON);  // R's left-continuity fuzz
  const double ratio = mu / (size + mu);        // 1 - prob
  const double lf0 = size * (size < mu ? std::log(size / (size + mu)) : std::log1p(-mu / (size + mu)));
  if (mu < 100 && lf0 > -700) {
    // pmf recurrence from 0: f(y + 1) = f(y) (y + size) / (y + 1) (1 - prob)
    double f = std::exp(lf0), F = f, y = 0;
    while (F < pt) {
      f *= (y + size) / (y + 1) * ratio;
      y += 1;
      F += f;
      if (y > 1e7) return HCU_NAN;  // cannot happen for valid input; guards against a non-terminating loop
    }
    return y;
  }
  // Large means: Cornish-Fisher start (as R), F and f there from Boost, then walk.
  const double prob = size / (size + mu);
  const double Q = 1 + mu / size, P = mu / size;
  const double sigma = std::sqrt(size * P * Q), gam = (Q + P) / sigma;
  const double z = norm_quantile(p);
  double y = std::nearbyint(mu + sigma * (z + gam * (z * z - 1) / 6));
  if (!(y >= 0)) y = 0;
  boost::math::negative_binomial_distribution<double, BoostPolicy> nb(size, prob);
  double F = boost::math::ibeta(size, y + 1, prob, BoostPolicy());
  double f = boost::math::pdf(nb, y);
  if (std::isnan(F) || std::isnan(f)) return HCU_NAN;
  if (F >= pt) {  // walk left while F(y - 1) >= pt
    while (y > 0) {
      const double Fm = F - f;
      if (Fm < pt) break;
      f *= y / ((y - 1 + size) * ratio);  // f(y - 1)
      F = Fm;
      y -= 1;
    }
    return y;
  }
  for (long it = 0; F < pt; ++it) {  // walk right
    f *= (y + size) / (y + 1) * ratio;
    y += 1;
    F += f;
    if (it > 100000000L) return HCU_NAN;
  }
  return y;
}

// Gamma quantile (R's qgamma(p, shape, scale = scale)).
inline double gamma_quantile(double p, double shape, double scale) {
  if (std::isnan(p) || std::isnan(shape) || std::isnan(scale)) return p + shape + scale;
  if (p <= 0) return 0.0;
  if (p >= 1) return HCU_INF;
  return boost::math::gamma_p_inv(shape, p, BoostPolicy()) * scale;
}

// Linear interpolation with constant extrapolation (R's approx(x, y, v, rule = 2), the
// approx1() routine of R's src/library/stats/src/approx.c); x strictly increasing, n >= 1.
inline double approx_linear(double v, const double* x, const double* y, std::size_t n) {
  if (n == 0 || std::isnan(v)) return HCU_NAN;
  std::size_t i = 0, j = n - 1;
  if (v < x[i]) return y[0];
  if (v > x[j]) return y[n - 1];
  while (i < j - 1) {
    const std::size_t ij = (i + j) / 2;
    if (v < x[ij]) j = ij; else i = ij;
  }
  if (v == x[j]) return y[j];
  if (v == x[i]) return y[i];
  return y[i] + (y[j] - y[i]) * ((v - x[i]) / (x[j] - x[i]));
}

// Mean of the untruncated NB behind the positive part of a hurdle count (R reference
// hurdle_mustar(): 60 bisection steps on log mu_star of p mu* / (1 - f0(mu*)) = mu).
inline double hurdle_mustar(double mu, double p, double theta) {
  const double m_pos = mu / p;
  if (!(m_pos > 1)) return HCU_NAN;
  double lo = std::log(1e-10), hi = std::log(m_pos);
  for (int i = 0; i < 60; ++i) {
    const double mid = (lo + hi) / 2;
    const double ms = std::exp(mid);
    const double g = ms / (1 - rpow(theta / (theta + ms), theta));
    if (g < m_pos) lo = mid; else hi = mid;
  }
  return std::exp((lo + hi) / 2);
}

// P(count > 0) of a hurdle margin (R reference hurdle_p()).
inline double hurdle_p(double mu, double a, double b) {
  const double p = logis_cdf(a + b * std::log(mu));
  const double cap = mu / (1 + 1e-6);
  return (std::isnan(p) || std::isnan(cap)) ? HCU_NAN : (p < cap ? p : cap);
}

}  // namespace hcucost

#endif  // HCUCOST_NMATH_HPP
