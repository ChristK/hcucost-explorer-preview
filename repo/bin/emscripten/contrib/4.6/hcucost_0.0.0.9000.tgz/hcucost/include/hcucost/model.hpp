// hcucost/model.hpp - the joint utilisation and cost model as lookup tables (no design matrix).
//
// The fitted model's linear predictors are sums over 289 design columns (R reference
// cost_design() and linear_predictor()). Every column is a function of a few row features (age,
// sex, deprivation, ..., the disease duration bands, the death indicators), so each linear
// predictor is stored as a LinTerm: one small table per feature, built in R by compile_params()
// (R/compile.R) from the parameter list:
//   * smooth terms (natural splines of age and BMI, their interactions with sex and with the band
//     of the number of conditions) as piecewise cubic polynomials between the knots: on each
//     interval the spline contribution is exactly a cubic, so evaluating it costs one Horner step;
//   * factor terms as one value per level, disease terms as [disease][duration band];
//   * terms that depend on the number of conditions as one value per possible count 0..D.
// A row's features are computed once (RowFeat) and every linear predictor is a few dozen table
// lookups. The R-side compiler checks the tables against the R reference on test points.
//
// Simulation of one person-year from latent scores reproduces the R reference functions
// margin_for(), nb_from_latent(), severity_eta(), phi_for(), mix_index() and draw_total_cost().
// Header-only, no R API: safe inside OpenMP regions.
#ifndef HCUCOST_MODEL_HPP
#define HCUCOST_MODEL_HPP

#include <algorithm>
#include <climits>
#include <cmath>
#include <cstddef>
#include <vector>

#include "nmath.hpp"

namespace hcucost {

constexpr int MAX_DISEASES = 64;  // the fitted models have 26
constexpr int MAX_K = 16;         // components (the fitted models have 5)
constexpr int N_BANDS = 6;        // own-count bands 1, 2, 3-4, 5-9, 10-19, 20+
constexpr int N_GROUPS = 3;       // death groups: 0 survivor, 1 dies next year, 2 dies this year
constexpr int NA_COUNT = INT_MIN; // R's NA_integer_

// Band of a positive count (R reference count_band()): 0 = "1", 1 = "2", 2 = "3-4", 3 = "5-9",
// 4 = "10-19", 5 = "20+".
inline int count_band(int n) {
  return n <= 1 ? 0 : n <= 2 ? 1 : n <= 4 ? 2 : n <= 9 ? 3 : n <= 19 ? 4 : 5;
}

// Duration band of a disease (R reference prvl_band()). "duration" coding: 0, 1, 2, 3-5, 6-10, 11+
// -> 0..5; "spell" coding: 0, 1, 2+ -> 0..2.
inline int prvl_band(int prvl, bool spell) {
  if (spell) return prvl <= 0 ? 0 : (prvl == 1 ? 1 : 2);
  return prvl <= 0 ? 0 : prvl == 1 ? 1 : prvl == 2 ? 2 : prvl <= 5 ? 3 : prvl <= 10 ? 4 : 5;
}

// Piecewise-polynomial grid of a clamped continuous predictor (age or BMI): break points
// b[0] < ... < b[m]; values are clamped to [b[0], b[m]] as the R reference does before its spline
// basis. Interval i holds x in [b[i], b[i+1]) (the last also b[m]); u = (x - b[i]) / (b[i+1] - b[i]).
struct PPGrid {
  std::vector<double> breaks;
  int n_int() const { return static_cast<int>(breaks.size()) - 1; }
  void locate(double x, int& i, double& u) const {
    const double lo = breaks.front(), hi = breaks.back();
    x = x < lo ? lo : (x > hi ? hi : x);
    int k = static_cast<int>(std::upper_bound(breaks.begin(), breaks.end(), x) - breaks.begin()) - 1;
    const int m = n_int();
    if (k >= m) k = m - 1;
    if (k < 0) k = 0;
    i = k;
    u = (x - breaks[k]) / (breaks[k + 1] - breaks[k]);
  }
};

inline double horner3(const double* c, double u) { return c[0] + u * (c[1] + u * (c[2] + u * c[3])); }

// One linear predictor (or an additive piece of one) as feature tables. An empty table
// contributes nothing.
struct LinTerm {
  double c0 = 0.0;                        // constant (intercept)
  double died = 0.0, died_logprop = 0.0, dies_next = 0.0;
  std::vector<double> age_sex;            // [sex 0/1][age interval][4]: age spline, sex, age x sex
  std::vector<double> age_nc;             // [age-ncond band][age interval][4]: age spline x ncond band
  std::vector<double> bmi;                // [bmi interval][4]
  std::vector<double> dimd, eth, sha, smok;  // per level (reference level 0)
  std::vector<double> ncond;              // [ncond 0..D]: condition-count band
  std::vector<double> died_age, dn_age;   // [death age band]: died / dies next x age band
  std::vector<double> died_ncond, dn_ncond;  // [ncond 0..D]
  std::vector<double> died_prop;          // [share-of-year band]
  std::vector<double> dis;                // [disease][duration band 0..5]
  std::vector<double> any, died_any, dn_any;  // [disease]: any duration; x died; x dies next
  std::vector<double> ca_other;           // [number of other conditions 0..D], rows with a cancer
  bool has_disease() const { return !dis.empty() || !any.empty() || !died_any.empty() || !dn_any.empty(); }
};

// Count part of component k (R reference params$count[[k]]).
struct CountPart {
  LinTerm oth, dis;          // linear predictor = oth + max(ncond, 1)^-gamma * dis
  double gamma = 0.0;
  std::vector<double> mm;    // [ncond 0..D]: max(ncond, 1)^-gamma (filled by prepare_model())
  bool recal[N_GROUPS] = {false, false, false};  // death-group recalibration slope
  double ralpha[N_GROUPS] = {0, 0, 0}, rbeta[N_GROUPS] = {1, 1, 1};
  LinTerm cal[N_GROUPS];     // count calibration + death-recalibration terms, by death group
  std::vector<double> theta[N_GROUPS], breaks[N_GROUPS];  // NB shape by band of the mean
  bool hurdle[N_GROUPS] = {false, false, false};
  double ha[N_GROUPS] = {0, 0, 0}, hb[N_GROUPS] = {0, 0, 0};
  std::vector<double> htheta[N_GROUPS], hbreaks[N_GROUPS];
};

// Severity (cost per unit) part of component k (R reference params$severity[[k]]).
struct SevPart {
  LinTerm oth, dis;          // eta0 = oth (intercept and any-disease offsets included) + scale * dis
  double gamma = 0.0;
  std::vector<double> mm;    // [ncond 0..D]: max(ncond, 1)^-gamma (filled by prepare_model())
  double own[N_GROUPS][N_BANDS] = {};   // own-count band effects (with death x band terms)
  std::vector<double> l1p;              // [K]: coefficient of log1p(count of each other component)
  double phi[N_GROUPS][N_BANDS] = {};   // CV^2 by death group x own-count band
  int lognormal = 0;                    // family: 0 gamma, 1 lognormal
  // derived from phi by prepare_model() (the same doubles the R reference computes per draw):
  double shape[N_GROUPS][N_BANDS] = {};   // gamma: 1 / phi
  double lsd[N_GROUPS][N_BANDS] = {};     // lognormal: sqrt(log1p(phi))
  double lhalf[N_GROUPS][N_BANDS] = {};   // lognormal: log1p(phi) / 2
  int mixcell[N_GROUPS][N_BANDS];       // mixture cell (-1 none)
  std::vector<std::vector<double>> mix_x, mix_y;  // per cell: grid of normal scores -> log ratio
  SevPart() { std::fill(&mixcell[0][0], &mixcell[0][0] + N_GROUPS * N_BANDS, -1); }
};

// Latent Gaussian process of one block (counts or severity): z_t = perm + w_t,
// perm ~ N(0, P), w_1 ~ N(0, W), w_t = A w_{t-1} + e_t, e_t ~ N(0, E). Matrices K x K
// column-major; UP, UW, UE are the upper Cholesky factors (R's chol(): S = U'U).
struct Persistence {
  bool present = false;
  std::vector<double> UP, UW, UE, A;
};

struct Model {
  int K = 0, D = 0;
  int n_dimd = 0, n_eth = 0, n_sha = 0, n_smok = 0;  // numbers of levels (input codes 1..n)
  std::vector<int> spell, cancer;      // [disease]
  PPGrid age, bmi;
  std::vector<double> death_age_cut;   // cut(age, ., right = FALSE)
  std::vector<double> prop_cut;        // cut(prop, ., include.lowest = TRUE)
  std::vector<int> agenc_band;         // [ncond 0..D] -> age x ncond band
  std::vector<CountPart> count;
  std::vector<SevPart> sev;
  Persistence pz, pv;
};

// Row inputs: one array per variable, codes 1-based as in R (sex 1 men / 2 women; levels in
// the order of the model specification; smoking 1 never, 2 ex, 3 current).
struct Inputs {
  std::size_t n = 0;
  const double* age = nullptr;
  const int* sex = nullptr;
  const int* dimd = nullptr;
  const int* eth = nullptr;
  const int* sha = nullptr;
  const int* smok = nullptr;
  const double* bmi = nullptr;
  std::vector<const int*> prvl;        // [disease] -> durations
  const int* died = nullptr;
  const int* dies_next = nullptr;
};

// Band index for cut(x, b) with right = FALSE (b[i] <= x < b[i+1]); b holds all break points.
inline int band_left_closed(const std::vector<double>& b, double x) {
  if (b.size() < 3) return 0;
  return static_cast<int>(std::upper_bound(b.begin() + 1, b.end() - 1, x) - (b.begin() + 1));
}
// Band index for cut(x, b, include.lowest = TRUE) (right-closed: b[i] < x <= b[i+1]).
inline int band_right_closed(const std::vector<double>& b, double x) {
  if (b.size() < 3) return 0;
  return static_cast<int>(std::lower_bound(b.begin() + 1, b.end() - 1, x) - (b.begin() + 1));
}

// Features of one row, computed once and shared by all linear predictors.
struct RowFeat {
  int sex, dimd, eth, sha, smok;
  int ai, bi;          // age and BMI intervals
  double au, bu;       // local coordinates in them
  int ncond, n_other, any_ca;
  int agenc_band, death_age_band;
  int died, dies_next, grp;
  double logprop;
  int prop_band;
  int nd;              // number of diseases present
  int dz[MAX_DISEASES], db[MAX_DISEASES];  // present diseases and their duration bands
};

inline void row_features(const Model& M, const Inputs& in, std::size_t r, double prop, RowFeat& f) {
  f.sex = in.sex[r] - 1;
  f.dimd = in.dimd[r] - 1;
  f.eth = in.eth[r] - 1;
  f.sha = in.sha[r] - 1;
  f.smok = in.smok[r] - 1;
  M.age.locate(in.age[r], f.ai, f.au);
  M.bmi.locate(in.bmi[r], f.bi, f.bu);
  f.nd = 0;
  f.n_other = 0;
  f.any_ca = 0;
  for (int d = 0; d < M.D; ++d) {
    const int p = in.prvl[d][r];
    if (p > 0) {
      f.dz[f.nd] = d;
      f.db[f.nd] = prvl_band(p, M.spell[d] != 0);
      ++f.nd;
      if (M.cancer[d]) f.any_ca = 1; else ++f.n_other;
    }
  }
  f.ncond = f.nd;
  f.agenc_band = M.agenc_band.empty() ? 0 : M.agenc_band[f.ncond];
  f.death_age_band = band_left_closed(M.death_age_cut, in.age[r]);
  f.died = in.died[r] != 0;
  f.dies_next = in.dies_next[r] != 0;
  f.grp = f.died ? 2 : (f.dies_next ? 1 : 0);
  f.logprop = std::log(prop);
  f.prop_band = band_right_closed(M.prop_cut, prop);
}

inline double eval_term(const LinTerm& T, const Model& M, const RowFeat& f) {
  const int nA = M.age.n_int();
  double s = T.c0;
  if (!T.age_sex.empty()) s += horner3(&T.age_sex[(static_cast<std::size_t>(f.sex) * nA + f.ai) * 4], f.au);
  if (!T.age_nc.empty()) s += horner3(&T.age_nc[(static_cast<std::size_t>(f.agenc_band) * nA + f.ai) * 4], f.au);
  if (!T.bmi.empty()) s += horner3(&T.bmi[static_cast<std::size_t>(f.bi) * 4], f.bu);
  if (!T.dimd.empty()) s += T.dimd[f.dimd];
  if (!T.eth.empty()) s += T.eth[f.eth];
  if (!T.sha.empty()) s += T.sha[f.sha];
  if (!T.smok.empty()) s += T.smok[f.smok];
  if (!T.ncond.empty()) s += T.ncond[f.ncond];
  if (f.died) {
    s += T.died + T.died_logprop * f.logprop;
    if (!T.died_age.empty()) s += T.died_age[f.death_age_band];
    if (!T.died_ncond.empty()) s += T.died_ncond[f.ncond];
    if (!T.died_prop.empty()) s += T.died_prop[f.prop_band];
  }
  if (f.dies_next) {
    s += T.dies_next;
    if (!T.dn_age.empty()) s += T.dn_age[f.death_age_band];
    if (!T.dn_ncond.empty()) s += T.dn_ncond[f.ncond];
  }
  if (T.has_disease()) {
    for (int j = 0; j < f.nd; ++j) {
      const int d = f.dz[j];
      if (!T.dis.empty()) s += T.dis[static_cast<std::size_t>(d) * N_BANDS + f.db[j]];
      if (!T.any.empty()) s += T.any[d];
      if (f.died && !T.died_any.empty()) s += T.died_any[d];
      if (f.dies_next && !T.dn_any.empty()) s += T.dn_any[d];
    }
  }
  if (f.any_ca && !T.ca_other.empty()) s += T.ca_other[f.n_other];
  return s;
}

// Multimorbidity scaling of the disease effects (R reference mm_scale()).
inline double mm_scale(int ncond, double gamma) { return rpow(ncond > 1 ? ncond : 1, -gamma); }

// Mean count of component k (R reference count_mean()): exp(recalibrated eta + calibration + log prop).
inline double count_mean(const Model& M, int k, const RowFeat& f) {
  const CountPart& C = M.count[k];
  const double base = eval_term(C.oth, M, f) + C.mm[f.ncond] * eval_term(C.dis, M, f);
  const int g = f.grp;
  const double eta = C.recal[g] ? C.ralpha[g] + C.rbeta[g] * base : base;
  return std::exp(eta + eval_term(C.cal[g], M, f) + f.logprop);
}

// Severity linear predictor without the count terms (R reference linear_predictor() of the
// severity part).
inline double severity_eta0(const Model& M, int k, const RowFeat& f) {
  const SevPart& S = M.sev[k];
  return eval_term(S.oth, M, f) + S.mm[f.ncond] * eval_term(S.dis, M, f);
}

// Value at x of a band table: theta[number of breaks <= x] (R: theta[findInterval(x, breaks) + 1]).
inline double band_value(const std::vector<double>& values, const std::vector<double>& breaks, double x) {
  if (values.empty()) return HCU_NAN;
  if (breaks.empty()) return values[0];
  if (std::isnan(x)) return HCU_NAN;
  const std::size_t i = static_cast<std::size_t>(std::upper_bound(breaks.begin(), breaks.end(), x) - breaks.begin());
  return values[i];
}

// Count of component k from its mean and latent score (R reference margin_for() and
// nb_from_latent()): NB margin, or the hurdle margin in a death group that has one.
inline int draw_count(const CountPart& C, int g, double mu, double z) {
  double u = norm_cdf(z);
  if (u > 1 - 1e-12) u = 1 - 1e-12;
  double y;
  if (C.hurdle[g]) {
    const double p = hurdle_p(mu, C.ha[g], C.hb[g]);
    const double th = band_value(C.htheta[g], C.hbreaks[g], mu);
    const double ms = hurdle_mustar(mu, p, th);
    const double f0 = nbinom_p0_mu(th, ms);
    const double q0 = 1 - p;
    if (u <= q0) {
      y = 0;
    } else {
      double v = (u - q0) / p;
      if (v < 0) v = 0;
      double pp = f0 + v * (1 - f0);
      if (pp > 1 - 1e-12) pp = 1 - 1e-12;
      y = nbinom_quantile_mu(pp, th, ms);
      if (y < 1) y = 1;
    }
  } else {
    y = nbinom_quantile_mu(u, band_value(C.theta[g], C.breaks[g], mu), mu);
  }
  if (std::isnan(y) || y > static_cast<double>(INT_MAX)) return NA_COUNT;
  return static_cast<int>(y);
}

// Cost of component k given all counts y (R reference simulate_counts_costs() for one row).
// l1py[o] = log1p(y[o]) (computed once per row). Latent severity score v (persistence) if v_ok,
// else the independent uniform usev.
inline double draw_cost(const Model& M, int k, int g, const int* y, const double* l1py, double eta0, bool v_ok,
                        double v, double usev) {
  const int n = y[k];
  if (n == NA_COUNT || n <= 0) return 0.0;
  const SevPart& S = M.sev[k];
  const int band = count_band(n);
  double eta = eta0 + S.own[g][band];
  for (int o = 0; o < M.K; ++o) {
    if (o == k || S.l1p[o] == 0.0) continue;
    if (y[o] == NA_COUNT) return HCU_NAN;
    eta += S.l1p[o] * l1py[o];
  }
  const double mu = std::exp(eta);
  const int cell = S.mixcell[g][band];
  double s;
  if (cell >= 0) {  // mean-1 two-lognormal mixture (R: lnmix_quantile_z(), scores v or qnorm(u))
    const double zz = v_ok ? v : norm_quantile(usev);
    const std::vector<double>& gx = S.mix_x[cell];
    const std::vector<double>& gy = S.mix_y[cell];
    s = mu * std::exp(approx_linear(zz, gx.data(), gy.data(), gx.size()));
  } else {
    double u = v_ok ? norm_cdf(v) : usev;
    u = u < 1e-12 ? 1e-12 : (u > 1 - 1e-12 ? 1 - 1e-12 : u);  // R: sev_quantile()
    if (S.lognormal) {
      s = mu * std::exp(S.lsd[g][band] * norm_quantile(u) - S.lhalf[g][band]);
    } else {
      s = gamma_quantile(u, S.shape[g][band], mu * S.phi[g][band]);
    }
  }
  return n * s;
}

// Fill the tables derived from the parameters (call once after building a Model).
inline void prepare_model(Model& M) {
  for (CountPart& C : M.count) {
    C.mm.resize(static_cast<std::size_t>(M.D) + 1);
    for (int n = 0; n <= M.D; ++n) C.mm[n] = mm_scale(n, C.gamma);
  }
  for (SevPart& S : M.sev) {
    S.mm.resize(static_cast<std::size_t>(M.D) + 1);
    for (int n = 0; n <= M.D; ++n) S.mm[n] = mm_scale(n, S.gamma);
    for (int g = 0; g < N_GROUPS; ++g) {
      for (int b = 0; b < N_BANDS; ++b) {
        const double phi = S.phi[g][b], s2 = std::log1p(phi);
        S.shape[g][b] = 1 / phi;
        S.lsd[g][b] = std::sqrt(s2);
        S.lhalf[g][b] = s2 / 2;
      }
    }
  }
}

}  // namespace hcucost

#endif  // HCUCOST_MODEL_HPP
