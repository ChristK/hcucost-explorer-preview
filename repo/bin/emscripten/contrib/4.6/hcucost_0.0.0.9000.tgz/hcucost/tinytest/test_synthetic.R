# Synthetic parameters, model and lifecourse: structure and internal consistency.

# ---- synthetic parameters are valid and reproducible ----
p <- hcu_synthetic_params(seed = 3L)
expect_true(hcu_validate_params(p))
expect_identical(p, hcu_synthetic_params(seed = 3L))
expect_false(identical(p$count$pc$beta, hcu_synthetic_params(seed = 4L)$count$pc$beta))
expect_identical(hcu_synthetic_params(period = "FY")$spec$period, "FY")

# ---- synthetic coefficients cover exactly the design columns ----
p <- hcu_synthetic_params()
cols <- hcucost:::design_columns(p)
for (k in names(p$counts)) {
  expect_identical(names(p$count[[k]]$beta), cols, info = k)
  expect_identical(names(p$severity[[k]]$beta), cols, info = k)
  expect_true(all(p$count[[k]]$dis %in% cols), info = k)
  # no variance-covariance matrices (bundles do not carry them since 2026-11-08)
  expect_null(p$count[[k]]$vcov, info = k)
  expect_null(p$severity[[k]]$vcov, info = k)
}
expect_identical(length(p$count$pc$count_cal$any_cols), 26L)
expect_true(all(unlist(p$count$pc$count_cal$any_cols) %in% p$count$pc$dis))

# ---- synthetic dependence matrices are valid covariance structures ----
pers <- p$dependence$persistence
expect_equal(unname(diag(pers$P + pers$W)), rep(1, 5)) # latent scores are standard normal
for (mat in c("P", "W", "E")) expect_silent(chol(pers[[mat]])) # positive definite
expect_equal(pers$W, pers$A %*% pers$W %*% t(pers$A) + pers$E) # stationarity: W = A W A' + E
sp <- p$dependence$severity_persistence
expect_equal(unname(diag(sp$P + sp$W)), rep(1, 5))

# ---- synthetic severity mixture cells have mean 1 ----
mix <- p$severity$apc$mix
expect_equal(mix$pi * exp(mix$m1 + mix$s1^2 / 2) + (1 - mix$pi) * exp(mix$m2 + mix$s2^2 / 2), rep(1, nrow(mix)))

# ---- the synthetic model prints its status ----
m <- hcu_synthetic_model()
expect_inherits(m, "hcu_model")
expect_identical(m$status, "synthetic")
expect_stdout(print(m), "NOT for analysis")

# ---- the synthetic lifecourse has the IMPACTncd layout and ends at death ----
lc <- hcu_synthetic_lifecourse(m, n_persons = 300, n_years = 6, seed = 2)
expect_true(all(paste0(m$params$disease_map$sim_name, "_prvl") %in% names(lc)))
expect_false(anyDuplicated(lc, by = c("pid", "year")) > 0)
last <- lc[, list(dead_last = all_cause_mrtl[.N], n_dead = sum(all_cause_mrtl)), by = pid]
expect_true(all(last$n_dead <= 1L))
expect_true(all(last[n_dead == 1L, dead_last] == 1L))
expect_identical(lc, hcu_synthetic_lifecourse(m, n_persons = 300, n_years = 6, seed = 2))
