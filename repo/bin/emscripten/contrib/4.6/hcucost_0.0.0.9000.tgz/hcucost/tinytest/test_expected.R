# hcu_predict(method = "expected") (2026-11-08): expected values without simulation. The helpers
# (quadrature, Halton points), the cost-multiplier means, exact expected counts, agreement with the
# simulation in every death group, reproducibility across threads and seeds, the error estimate,
# fill-in, and argument checks. Synthetic models (the fitted models: test_fitted.R).

full <- hcu_synthetic_model()
as_m <- hcu_synthetic_model(predictors = "AS")
dz <- full$params$spec$diseases$sim_name
spec <- full$params$spec

# ---- helpers ----
g3 <- hcucost:::gauss_legendre(3L, 0, 2)
expect_equal(sum(g3$w), 2, tolerance = 1e-12)
expect_equal(sum(g3$w * g3$x^5), 2^6 / 6, tolerance = 1e-12)          # exact up to degree 2n - 1 = 5
pn <- hcucost:::prop_nodes(c(0, 0.125, 0.25, 0.5, 0.75, Inf), 3L)
expect_identical(length(pn$x), 15L)
expect_true(all(pn$x > 0 & pn$x < 1))
expect_equal(sum(pn$w), 1, tolerance = 1e-12)                          # uniform share of the year
# p^a, singular derivative at 0: the substitution in the first band keeps 3 nodes per band accurate
expect_equal(sum(pn$w * sqrt(pn$x)), 2 / 3, tolerance = 1e-6)
expect_equal(sum(pn$w * pn$x^0.3), 1 / 1.3, tolerance = 5e-5)
p0 <- hcucost:::prop_nodes(numeric(0), 4L)                                # no cut points: one band, (0, 1)
expect_true(all(p0$x > 0 & p0$x < 1))
expect_equal(sum(p0$w), 1, tolerance = 1e-12)
h <- hcucost:::halton_points(4L, 2L)
expect_equal(h[, 1], c(1 / 2, 1 / 4, 3 / 4, 1 / 8), tolerance = 0)
expect_equal(h[, 2], c(1 / 3, 2 / 3, 1 / 9, 4 / 9), tolerance = 1e-15)

# ---- cost multipliers have mean 1 (gamma and lognormal by construction; mixtures mean-1 grids) ----
mult <- hcucost:::cpp_expect_mult(full$compiled)
expect_identical(dim(mult), c(6L, 3L, full$compiled$K))
expect_true(all(abs(mult - 1) < 1e-5), info = paste(range(mult), collapse = " "))

# ---- expected counts are the model means exactly (R reference count_mean()) ----
x1 <- data.table::data.table(age = 70, sex = "women", dimd = "5", ethnicity = "white", sha = "London", died = 0L,
                             dies_next = 0L)
pe <- hcu_predict(as_m, x1, method = "expected", seed = 2)
m <- data.table::copy(x1)[, `:=`(year = spec$ref_year, prop = 1, bmi = 25, smok = "never")]
for (z in dz) data.table::set(m, j = paste0(z, "_prvl"), value = 0L)
X <- as.matrix(hcucost:::cost_design(m, as_m$params$spec))
mu <- vapply(names(as_m$params$counts), function(k) hcucost:::count_mean(X, 0L, as_m$params$count[[k]], 1, 0L), 0)
expect_equal(unname(unlist(pe[, unname(as_m$params$counts), with = FALSE])), unname(mu), tolerance = 1e-10)
expect_identical(attr(pe, "hcucost")$method, "expected")
expect_identical(pe$n_completed, 1L)

# ---- year of death: counts integrate the share of the year lived (3 nodes per band vs 16) ----
inp <- list(age = 80, sex = 2L, dimd = 5L, eth = 1L, sha = 1L, smok = 2L, bmi = 27,
            prvl = lapply(dz, function(z) if (z %in% c("htn", "copd")) 6L else 0L), died = 1L, dies_next = 0L)
e3 <- hcucost:::expected_core(full, inp, 1, 1024L, 2L, n_prop = 3L, seed = 1, threads = 1L)
e16 <- hcucost:::expected_core(full, inp, 1, 1024L, 2L, n_prop = 16L, seed = 1, threads = 1L)
expect_true(all(abs(e3$counts / e16$counts - 1) < 1e-4), info = paste(signif(e3$counts / e16$counts - 1, 2), collapse = " "))

# ---- agreement with the simulation, every death group (fixed seeds: deterministic) ----
full_row <- data.table::data.table(age = 75, sex = "women", dimd = "5", ethnicity = "indian", sha = "London", bmi = 31,
                                   smok = "ex")
for (z in dz) data.table::set(full_row, j = paste0(z, "_prvl"), value = if (z %in% c("htn", "t2dm")) 6L else 0L)
groups <- list(unknown = NULL, survives = c(0L, 0L), dies_next = c(0L, 1L), died = c(1L, 0L))
for (gname in names(groups)) {
  nd <- data.table::copy(full_row)
  if (!is.null(groups[[gname]])) nd[, `:=`(died = groups[[gname]][1], dies_next = groups[[gname]][2])]
  e <- hcu_predict(full, nd, method = "expected", seed = 3)
  s <- hcu_predict(full, nd, method = "simulate", n_sim = 40000L, seed = 3)
  z <- (e$healthcare_use_costs - s$healthcare_use_costs) / sqrt(e$se_healthcare_use_costs^2 + s$se_healthcare_use_costs^2)
  expect_true(abs(z) < 4, info = paste(gname, round(e$healthcare_use_costs, 1), round(s$healthcare_use_costs, 1), round(z, 2)))
  expect_true(e$se_healthcare_use_costs / e$healthcare_use_costs < 0.02, info = gname)
  cnt <- unname(full$params$counts)
  expect_true(all(abs(unlist(e[, ..cnt]) / unlist(s[, ..cnt]) - 1) < 0.05), info = gname)
}

# ---- reproducible, independent of threads; the seed changes the shifts; more points, smaller error ----
two <- rbind(full_row, full_row)
a1 <- hcu_predict(full, two, method = "expected", seed = 5, threads = 1L)
a2 <- hcu_predict(full, two, method = "expected", seed = 5, threads = 2L)
expect_equal(as.list(a1), as.list(a2), tolerance = 0)
expect_equal(a1$pc_contacts[1], a1$pc_contacts[2], tolerance = 1e-12)          # counts: exact, no shifts
expect_false(identical(a1$healthcare_use_costs[1], a1$healthcare_use_costs[2])) # rows: own shifts
a3 <- hcu_predict(full, two, method = "expected", seed = 6)
expect_false(identical(a1$healthcare_use_costs, a3$healthcare_use_costs))
expect_equal(a1$healthcare_use_costs, a3$healthcare_use_costs, tolerance = 0.03)
lo <- hcu_predict(full, full_row, method = "expected", n_points = 1024L, seed = 7)
hi <- hcu_predict(full, full_row, method = "expected", n_points = 65536L, seed = 7)
expect_true(hi$se_healthcare_use_costs < lo$se_healthcare_use_costs)

# ---- fill-in: averaged over the completed records ----
nf <- data.table::data.table(age = 80, sex = "women", t2dm_prvl = 5L, ncond = 3L)
fe <- hcu_predict(full, nf, method = "expected", n_draws = 30L, n_points = 1024L, seed = 8)
expect_true(fe$filled)
expect_identical(fe$n_completed, 30L)
fs <- hcu_predict(full, nf, method = "simulate", n_draws = 30L, n_sim = 2000L, seed = 8)   # the same completed records
expect_true(abs(fe$healthcare_use_costs - fs$healthcare_use_costs) <
              4 * sqrt(fe$se_healthcare_use_costs^2 + fs$se_healthcare_use_costs^2))

# ---- argument checks ----
expect_error(hcu_predict(full, full_row, type = "draws", method = "expected"), "gives means")
expect_error(hcu_predict(full, full_row, method = "expected", n_shifts = 1L), "n_shifts")
expect_error(hcu_predict(full, full_row, method = "expected", n_points = 2L, n_shifts = 4L), "n_points")

# ==== hcu_expected_impactncd(): expected values of lifecourses (2026-11-08) ====
lc <- hcu_synthetic_lifecourse(full, n_persons = 600, n_years = 5, seed = 11)
ev <- hcu_expected_impactncd(full, lc, seed = 1)
sim_cols <- names(hcu_simulate_impactncd(full, lc[1:3], seed = 1))
expect_identical(names(ev), c(sim_cols, "se_healthcare_use_costs"))
expect_identical(nrow(ev), nrow(lc))
expect_true(is.double(ev$pc_contacts))
expect_true(all(ev$se_healthcare_use_costs >= 0) && all(is.finite(ev$healthcare_use_costs)))
expect_identical(attr(ev, "hcucost")$engine, "expected")
expect_equal(ev$healthcare_use_costs, rowSums(ev[, paste0(names(full$params$counts), "_costs"), with = FALSE]),
             tolerance = 1e-12)

# survivors' expected counts are the model means exactly; in the year of death, the quadrature
ci <- hcucost:::core_inputs(hcucost:::validate_lifecourse(lc, full$params), full$params)
lp <- hcucost:::cpp_linear_predictors(full$compiled, ci$inputs, rep(1, nrow(lc)), 1L)
cnt <- unname(full$params$counts)
surv <- ci$inputs$died == 0L & ci$inputs$dies_next == 0L
expect_equal(unname(as.matrix(ev[surv, ..cnt])), unname(lp$mu[surv, , drop = FALSE]), tolerance = 1e-12)
dr <- which(ci$inputs$died == 1L)
expect_true(length(dr) > 0L)
q16 <- hcucost:::prop_nodes(full$compiled$prop_cut, 16L)
one <- function(r) lapply(ci$inputs, function(v) if (is.list(v)) lapply(v, `[`, r) else v[r])
mu16 <- t(vapply(dr[1:3], function(r) {
  inp <- one(r)
  inp <- lapply(inp, function(v) if (is.list(v)) lapply(v, rep, length(q16$x)) else rep(v, length(q16$x)))
  colSums(hcucost:::cpp_linear_predictors(full$compiled, inp, q16$x, 1L)$mu * q16$w)
}, numeric(full$compiled$K)))
expect_true(all(abs(as.matrix(ev[dr[1:3], ..cnt]) / mu16 - 1) < 1e-4))

# agreement with the simulation: mean cost per person-year, against 30 seeds (fixed: deterministic)
sims <- vapply(1:30, function(s) mean(hcu_simulate_impactncd(full, lc, seed = s)$healthcare_use_costs), 0)
se_e <- sqrt(sum(ev$se_healthcare_use_costs^2)) / nrow(ev)
z <- (mean(ev$healthcare_use_costs) - mean(sims)) / sqrt(se_e^2 + var(sims) / length(sims))
expect_true(abs(z) < 4, info = paste(round(mean(ev$healthcare_use_costs), 2), round(mean(sims), 2), round(z, 2)))
expect_true(se_e < sd(sims) / 5)                         # far more precise than one simulation run
# independent counts (copula = FALSE) against the simulation without the copula
ev0 <- hcu_expected_impactncd(full, lc, copula = FALSE, seed = 1)
sims0 <- vapply(1:30, function(s) mean(hcu_simulate_impactncd(full, lc, copula = FALSE, seed = s)$healthcare_use_costs), 0)
z0 <- (mean(ev0$healthcare_use_costs) - mean(sims0)) /
  sqrt(sum(ev0$se_healthcare_use_costs^2) / nrow(ev0)^2 + var(sims0) / length(sims0))
expect_true(abs(z0) < 4, info = round(z0, 2))
expect_equal(as.matrix(ev0[surv, ..cnt]), as.matrix(ev[surv, ..cnt]), tolerance = 1e-12) # counts: the same means

# reproducible; independent of threads and row order; common random numbers across scenarios
ev_t <- hcu_expected_impactncd(full, lc, seed = 1, threads = 2L)
expect_equal(as.list(ev), as.list(ev_t), tolerance = 0)
o <- sample(nrow(lc))
ev_o <- hcu_expected_impactncd(full, lc[o], seed = 1)
expect_equal(as.list(ev_o), as.list(ev[o]), tolerance = 0)
lc2 <- data.table::copy(lc)
p1 <- lc2$pid[1]
lc2[pid == p1, smok_status_curr_xps := 4L]
ev2 <- hcu_expected_impactncd(full, lc2, seed = 1)
expect_equal(as.list(ev2[lc$pid != p1]), as.list(ev[lc$pid != p1]), tolerance = 0)
expect_false(identical(ev$healthcare_use_costs, hcu_expected_impactncd(full, lc, seed = 2)$healthcare_use_costs))

# a non-stationary latent process is refused; without persistence, copula = FALSE is needed
ns_m <- full
ns_m$compiled$pz$UW <- ns_m$compiled$pz$UW * 1.1
expect_error(hcu_expected_impactncd(ns_m, lc), "stationary")
np_m <- full
np_m$compiled$pz$present <- FALSE
expect_error(hcu_expected_impactncd(np_m, lc), "no persistence")
expect_error(hcu_expected_impactncd(full, lc, n_shifts = 1L), "n_shifts")
