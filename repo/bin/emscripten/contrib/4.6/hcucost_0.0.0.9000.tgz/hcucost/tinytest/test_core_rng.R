# Random numbers of the C++ core: the Philox4x32-10 generator against its published
# known-answer vectors, and the properties the keying on (seed, person, year) promises:
# reproducibility, independence of threads, chunking, input order and the other persons
# (common random numbers), and the same distribution as the R reference engine.

m <- hcu_synthetic_model()

hex32 <- function(x) sprintf("%04x%04x", as.integer(x %/% 65536), as.integer(x %% 65536))

# ---- Philox4x32-10 reproduces the Random123 known-answer vectors ----
# Random123 tests/kat_vectors: "philox4x32 10" lines (counter, key -> output)
kat <- list(
  list(ctr = c(0, 0, 0, 0), key = c(0, 0), out = c("6627e8d5", "e169c58d", "bc57ac4c", "9b00dbd8")),
  list(ctr = rep(0xffffffff, 4), key = rep(0xffffffff, 2), out = c("408f276d", "41c83b0e", "a20bc7c6", "6d5451fd")),
  list(ctr = c(0x243f6a88, 0x85a308d3, 0x13198a2e, 0x03707344), key = c(0xa4093822, 0x299f31d0),
       out = c("d16cfe09", "94fdcceb", "5001e420", "24126ea1")))
for (k in kat) expect_identical(hex32(hcucost:::cpp_philox(k$ctr, k$key)), k$out)

# ---- uniforms are in (0, 1), uniform, and differ between keys ----
u <- hcucost:::cpp_uniforms(1, 123, 19L, 3L, 2e5)
expect_true(all(u > 0 & u < 1))
expect_true(stats::ks.test(u, "punif")$p.value > 1e-4)
expect_true(abs(stats::cor(u[-1], u[-length(u)])) < 0.01)
expect_identical(u, hcucost:::cpp_uniforms(1, 123, 19L, 3L, 2e5))
expect_false(any(u[1:10] == hcucost:::cpp_uniforms(2, 123, 19L, 3L, 10)))  # seed
expect_false(any(u[1:10] == hcucost:::cpp_uniforms(1, 124, 19L, 3L, 10)))  # person
expect_false(any(u[1:10] == hcucost:::cpp_uniforms(1, 123, 20L, 3L, 10)))  # year
expect_false(any(u[1:10] == hcucost:::cpp_uniforms(1, 123, 19L, 2L, 10)))  # stream

lc <- hcu_synthetic_lifecourse(m, n_persons = 600, n_years = 8, seed = 5)

# ---- results depend only on the seed and the person's own rows ----
a <- hcu_simulate_impactncd(m, lc, seed = 7)
expect_identical(attr(a, "hcucost")$seed, 7)
# threads
if (hcucost:::cpp_has_openmp()) expect_identical(hcu_simulate_impactncd(m, lc, seed = 7, threads = 4), a)
# chunks: persons simulated in two separate calls
ids <- unique(lc$pid)
part1 <- lc$pid %in% ids[seq(1, length(ids), 2)]
b1 <- hcu_simulate_impactncd(m, lc[part1], seed = 7)
b2 <- hcu_simulate_impactncd(m, lc[!part1], seed = 7)
data.table::setattr(b1, "hcucost", NULL)
data.table::setattr(b2, "hcucost", NULL)
a0 <- data.table::copy(a)
data.table::setattr(a0, "hcucost", NULL)
expect_identical(b1, a0[part1])
expect_identical(b2, a0[!part1])
# scenario: changing other persons' risk factors leaves this person's results unchanged
# (common random numbers); the changed persons' results change
sc <- data.table::copy(lc)
chg <- sc$pid %in% ids[1:50]
sc[chg, bmi_curr_xps := bmi_curr_xps + 8]
s <- hcu_simulate_impactncd(m, sc, seed = 7)
data.table::setattr(s, "hcucost", NULL)
expect_identical(s[!chg], a0[!chg])
expect_false(identical(s[chg], a0[chg]))

# ---- the seed is drawn from R's generator when not given ----
set.seed(3)
a <- hcu_simulate_impactncd(m, lc[1:50], seed = NULL)
set.seed(3)
b <- hcu_simulate_impactncd(m, lc[1:50], seed = NULL)
expect_identical(a, b)
expect_error(hcu_simulate_impactncd(m, lc, seed = -1), "seed must be")
expect_error(hcu_simulate_impactncd(m, lc, seed = 1.5), "seed must be")
expect_error(hcu_simulate_impactncd(m, lc, seed = 1, threads = 0), "threads must be")

# ---- non-numeric person ids work ----
lc2 <- data.table::copy(lc[1:200])[, pid := paste0("p", pid)]
sim <- hcu_simulate_impactncd(m, lc2, seed = 1)
expect_identical(nrow(sim), 200L)
expect_error(hcu_simulate_impactncd(m, data.table::copy(lc[1:20])[, pid := pid + 0.5], seed = 1), "whole numbers")

# ---- the C++ and R engines simulate the same distribution ----
big <- hcu_synthetic_lifecourse(m, n_persons = 12000, n_years = 5, seed = 13)
sc <- hcu_simulate_impactncd(m, big, seed = 21)
sr <- hcu_simulate_impactncd(m, big, seed = 22, engine = "r")
cnt <- unname(m$params$counts)
cst <- paste0(names(m$params$counts), "_costs")
# means of counts and costs: within 4.5 standard errors of the difference
for (v in c(cnt, cst, "healthcare_use_costs")) {
  d <- mean(sc[[v]]) - mean(sr[[v]])
  se <- sqrt(stats::var(sc[[v]]) / nrow(sc) + stats::var(sr[[v]]) / nrow(sr))
  expect_true(abs(d) < 4.5 * se, info = paste("mean of", v))
}
# dependence between components and over years (rank correlations of the counts)
cc <- stats::cor(sc[, cnt, with = FALSE], method = "spearman")
cr <- stats::cor(sr[, cnt, with = FALSE], method = "spearman")
expect_true(max(abs(cc - cr)) < 0.04)
o <- order(big$pid, big$year)
lag1 <- function(sim, v) {
  x <- sim[[v]][o]
  p <- big$pid[o]
  same <- p[-1] == p[-length(p)]
  stats::cor(x[-length(x)][same], x[-1][same], method = "spearman")
}
for (v in cnt) expect_true(abs(lag1(sc, v) - lag1(sr, v)) < 0.04, info = paste("lag-1 correlation of", v))
