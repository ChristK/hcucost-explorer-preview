# Helpers for the tests of the C++ core against the R reference implementation. Test files source
# this file with source("helpers_core.R", local = TRUE), so that the expect_* calls in
# expect_core_matches_reference() are recorded by tinytest (calls written as tinytest::expect_*
# would not be).

#' Random draws of the R reference impactncd_healthcare_use(), reproduced (test helper)
#'
#' Replays the reference's use of R's random number generator for the same seed: the share of
#' the year lived (runif for every row, used in years of death), the latent count scores and
#' severity scores (sim_latent_paths(), or rnorm without the copula) and, where the model has no
#' severity scores, the independent severity uniforms (runif per component over the rows with a
#' positive count, in the reference's row order). Returned in the INPUT row order of `lc`, so
#' they can be passed to cpp_simulate_given() with core_inputs(lc).
#' @param lc validated lifecourse
#' @param params model parameters
#' @param copula as impactncd_healthcare_use()
#' @param seed seed used for the reference call
#' @param counts n x K counts of the reference result (input order), needed for the severity
#'   uniforms when the model has no severity scores
#' @return list(prop, z, v, usev): prop numeric(n), the others n x K matrices or NULL
reference_draws <- function(lc, params, copula, seed, counts = NULL) {
  hcucost:::with_seed(seed, {
    ks <- names(params$counts)
    K <- length(ks)
    m <- hcucost:::impactncd_to_model(lc, params)
    n <- nrow(m)
    prop <- data.table::fifelse(m$died == 1L, stats::runif(n), 1)
    paths <- function(p) {
      zz <- hcucost:::sim_latent_paths(max(m$pidx), max(m$tidx), p)
      matrix(vapply(seq_len(K), function(j) zz[cbind(m$pidx, m$tidx, j)], numeric(n)), n, K)
    }
    v <- NULL
    if (copula) {
      z <- paths(params$dependence$persistence)
      if (!is.null(params$dependence$severity_persistence)) v <- paths(params$dependence$severity_persistence)
    } else {
      z <- matrix(stats::rnorm(n * K), n, K)
    }
    usev <- NULL
    if (is.null(v)) {
      stopifnot(!is.null(counts))
      y <- counts[m$row, , drop = FALSE]
      usev <- matrix(NA_real_, n, K)
      for (k in seq_len(K)) {
        pos <- which(y[, k] > 0L)
        if (length(pos)) usev[pos, k] <- stats::runif(length(pos))
      }
    }
    back <- function(x) { # reference (pid, year) order -> input order
      if (is.null(x)) return(NULL)
      if (is.matrix(x)) {
        out <- x
        out[m$row, ] <- x
      } else {
        out <- x
        out[m$row] <- x
      }
      out
    }
    list(prop = back(prop), z = back(z), v = back(v), usev = back(usev))
  })
}

#' Count means and severity linear predictors of the R reference (test helper)
#' @param lc validated lifecourse; params parameters; prop share of the year lived (input order)
#' @return list(mu, eta0): n x K matrices in input order
reference_linear_predictors <- function(lc, params, prop) {
  ks <- names(params$counts)
  m <- hcucost:::impactncd_to_model(lc, params)
  m[, prop := prop[m$row]]
  X <- as.matrix(hcucost:::cost_design(m, params$spec))
  nc <- hcucost:::model_ncond(m, params$spec)
  grp <- hcucost:::death_group(m$died, m$dies_next)
  mu <- vapply(ks, function(k) hcucost:::count_mean(X, nc, params$count[[k]], m$prop, grp), numeric(nrow(m)))
  eta <- vapply(ks, function(k) hcucost:::linear_predictor(X, nc, params$severity[[k]]), numeric(nrow(m)))
  mu <- matrix(mu, nrow(m))
  eta <- matrix(eta, nrow(m))
  mu[m$row, ] <- mu
  eta[m$row, ] <- eta
  list(mu = unname(mu), eta0 = unname(eta))
}

#' The reference result as count and cost matrices (test helper)
reference_matrices <- function(out, params) {
  ks <- names(params$counts)
  list(counts = unname(as.matrix(out[, unname(params$counts), with = FALSE])),
       costs = unname(as.matrix(out[, paste0(ks, "_costs"), with = FALSE])))
}

#' A lifecourse that exercises every branch of the model (test helper)
#'
#' The synthetic lifecourse plus rows that reach the edges: ages below 20 and above 100 (spline
#' clamping), every BMI interval and the clamp, long and spell durations of every disease,
#' many conditions with cancers, years of death and the year before.
edge_lifecourse <- function(model, n_persons = 400L, n_years = 6L, seed = 3L) {
  lc <- suppressWarnings(hcu_synthetic_lifecourse(model, n_persons = n_persons, n_years = n_years, seed = seed))
  hcucost:::with_seed(seed + 1L, {
    n <- nrow(lc)
    lc[, age := age + sample(c(-30L, 0L, 0L, 0L, 25L), n, TRUE)]
    lc[age < 0L, age := 0L]
    lc[, bmi_curr_xps := round(stats::runif(n, 14, 70), 2)]
    dz <- model$params$spec$diseases$sim_name
    many <- sample(n, n %/% 10L)
    for (d in dz) {
      v <- paste0(d, "_prvl")
      x <- lc[[v]]
      x[many] <- sample(0:25, length(many), TRUE)
      data.table::set(lc, j = v, value = as.integer(x))
    }
  })
  lc
}

#' Expect the C++ core to reproduce the R reference on a lifecourse (test helper)
#'
#' Linear predictors (count means and severity linear predictors, for random shares of the year
#' lived in years of death), and simulation from the reference's own random draws in the three
#' draw modes (copula with severity scores; copula with independent severity uniforms;
#' independent count scores): counts identical, costs equal up to rounding.
#' @param model hcu_model; lc validated lifecourse; seed seed of the reference runs
expect_core_matches_reference <- function(model, lc, seed) {
  params <- model$params
  ci <- hcucost:::core_inputs(lc, params)
  prop <- hcucost:::with_seed(seed, ifelse(ci$inputs$died == 1L, stats::runif(nrow(lc)), 1))
  lp_c <- hcucost:::cpp_linear_predictors(model$compiled, ci$inputs, prop)
  lp_r <- reference_linear_predictors(lc, params, prop)
  expect_equal(lp_c$mu, lp_r$mu, tolerance = 1e-12, info = "count means")
  expect_equal(lp_c$eta0, lp_r$eta0, tolerance = 1e-12, info = "severity linear predictors")
  modes <- list(list(copula = TRUE, sev = TRUE), list(copula = TRUE, sev = FALSE), list(copula = FALSE, sev = TRUE))
  for (md in modes) {
    pr <- params
    if (!md$sev) pr$dependence$severity_persistence <- NULL
    mm <- hcucost:::new_hcu_model(pr, model$manifest, NA_character_, model$status)
    ref <- hcucost:::with_seed(seed, hcucost:::impactncd_healthcare_use(lc, pr, copula = md$copula))
    rm_ <- reference_matrices(ref, pr)
    dr <- reference_draws(lc, pr, md$copula, seed, rm_$counts)
    res <- hcucost:::cpp_simulate_given(mm$compiled, ci$inputs, dr$prop, dr$z, dr$v, dr$usev)
    lab <- paste0("copula = ", md$copula, ", severity scores = ", md$sev)
    expect_identical(res$counts, rm_$counts, info = paste("counts,", lab))
    expect_equal(res$costs, rm_$costs, tolerance = 1e-12, info = paste("costs,", lab))
    # the same through the threaded loop
    if (hcucost:::cpp_has_openmp()) {
      res4 <- hcucost:::cpp_simulate_given(mm$compiled, ci$inputs, dr$prop, dr$z, dr$v, dr$usev, threads = 4L)
      expect_identical(res4, res, info = paste("4 threads,", lab))
    }
  }
}
