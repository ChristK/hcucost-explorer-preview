# Helpers for the IN-HOUSE tests that compare the package with the CPRD costing pipeline it was
# copied from (and with the real fitted parameters, which are not shipped). Test files source this
# file (source("helpers_pipeline.R", local = TRUE)) and exit early wherever the pipeline is not
# available, e.g. outside the secure environment.
# Location: the environment variable HCUCOST_PIPELINE_DIR (the pipeline's folder, e.g. set in
# ~/.Renviron). There is no default (2026-11-08: no server paths in the shared files), so these tests
# are skipped wherever it is not set.

pipeline_dir <- function() Sys.getenv("HCUCOST_PIPELINE_DIR")

#' Is the CPRD costing pipeline available (in-house)?
pipeline_available <- function() {
  d <- pipeline_dir()
  nzchar(d) && dir.exists(file.path(d, "R"))
}

# the fitted full models' parameter files (calendar-year and financial-year versions)
real_params_file <- function(period = c("CY", "FY")) {
  period <- match.arg(period)
  file.path(pipeline_dir(), if (period == "CY") "outputs_CY" else "outputs", "results", "model_full",
            "impactncd_export", "cost_model_params.rds")
}

# structure of a nested parameter object: classes, lengths/dimensions and (sorted) names, no
# values; data frames by their column names only
param_shape <- function(x) {
  if (is.data.frame(x)) return(list(class = "data.frame", cols = names(x)))
  if (is.list(x)) {
    nm <- names(x)
    return(if (is.null(nm)) lapply(x, param_shape) else lapply(x[sort(nm)], param_shape))
  }
  list(class = class(x)[1L], dim = if (is.null(dim(x))) length(x) else dim(x), names = sort(names(x)),
       dimnames = lapply(dimnames(x), sort))
}
