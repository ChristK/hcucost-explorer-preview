# hcu_predict() (phase 3b): the model chosen per record, exact predictions of the chosen model, the
# averaging over unknown death groups, draws, reproducibility and input errors. Synthetic models.

full <- hcu_synthetic_model()
as_m <- hcu_synthetic_model(predictors = "AS")
an_m <- hcu_synthetic_model(predictors = "AN")
a_m <- hcu_synthetic_model(predictors = "A")
set_all <- list(full, as_m, an_m, a_m)
dz <- full$params$spec$diseases$sim_name

# ---- which model each record uses ----
nd <- data.table::data.table(age = c(50, 60, 70, 80, 85, 75), sex = c("men", "women", "men", "women", "men", "women"),
                             dimd = c("5", NA, NA, NA, "3", "5"), ethnicity = c("white", NA, NA, NA, NA, "indian"),
                             sha = c("London", NA, NA, NA, NA, "London"), ncond = c(NA, NA, 2L, NA, NA, NA),
                             t2dm_prvl = c(NA, NA, NA, 4L, NA, NA))
full_row <- data.table::data.table(age = 75, sex = "women", dimd = "5", ethnicity = "indian", sha = "London", bmi = 31,
                                   smok = "ex")
for (z in dz) data.table::set(full_row, j = paste0(z, "_prvl"), value = if (z == "htn") 6L else 0L)
nd <- rbind(nd[1:5], full_row, fill = TRUE)
p <- hcu_predict(set_all, nd, n_draws = 3L, n_points = 1024L, seed = 1)   # the default method, "expected"
expect_identical(p$model, c("AS", "A", "AN", "ASRDN", "ASRDN", "ASRDN"))
expect_identical(p$filled, c(FALSE, FALSE, FALSE, TRUE, TRUE, FALSE)) # row 5: deprivation only (S partly known)
expect_identical(p$n_completed, c(1L, 1L, 1L, 3L, 3L, 1L))
expect_true(all(p$healthcare_use_costs > 0) && all(p$se_healthcare_use_costs > 0))
expect_identical(attr(p, "hcucost")$models, c("ASRDN", "AS", "AN", "A"))
expect_error(hcu_predict(list(as_m, a_m), nd[4]), "need the full model")

# ---- an exact model: mean counts equal the model's mean (R reference count_mean()) ----
x1 <- data.table::data.table(age = 70, sex = "women", dimd = "5", ethnicity = "white", sha = "London", died = 0L, dies_next = 0L)
pe <- hcu_predict(as_m, x1, method = "simulate", n_sim = 4000L, seed = 2)
spec <- as_m$params$spec
m <- data.table::copy(x1)[, `:=`(year = spec$ref_year, prop = 1, bmi = 25, smok = "never")]
for (z in dz) data.table::set(m, j = paste0(z, "_prvl"), value = 0L)
X <- as.matrix(hcucost:::cost_design(m, spec))
mu <- vapply(names(as_m$params$counts), function(k) hcucost:::count_mean(X, 0L, as_m$params$count[[k]], 1, 0L), 0)
got <- unlist(pe[, unname(as_m$params$counts), with = FALSE])
expect_true(all(abs(got / mu - 1) < 0.08), info = paste(round(got / mu, 3), collapse = " "))

# ---- an unknown death group: the death-model-weighted average of the three known groups ----
xu <- x1[, c("died", "dies_next") := NULL]
pu <- hcu_predict(as_m, data.table::copy(xu)[, age := 85], method = "simulate", n_sim = 3000L, seed = 3)
pg <- hcucost:::death_model_predict(as_m$death_model, data.table::copy(m)[, age := 85])
by_g <- vapply(0:2, function(g) hcu_predict(as_m, data.table::copy(xu)[, `:=`(age = 85, died = as.integer(g == 2L),
                                                                              dies_next = as.integer(g == 1L))],
                                            method = "simulate", n_sim = 3000L, seed = 4 + g)$apc_spells, 0)
expect_equal(pu$apc_spells, sum(unlist(pg[, c("p_group0", "p_group1", "p_group2")]) * by_g), tolerance = 0.1)

# ---- draws: n_draws joint draws per record; reproducible ----
d1 <- hcu_predict(set_all, nd[c(1, 4)], type = "draws", n_draws = 4L, seed = 5)
expect_identical(nrow(d1), 8L)
expect_true(all(c("row", "draw", "model", "pc_contacts", "apc_costs", "healthcare_use_costs") %in% names(d1)))
expect_true(all(d1$healthcare_use_costs >= 0))
d2 <- hcu_predict(set_all, nd[c(1, 4)], type = "draws", n_draws = 4L, seed = 5)
expect_identical(as.list(d1), as.list(d2))

# ---- input errors ----
expect_error(hcu_predict(full, data.table::data.table(age = 50)), "age and sex")
expect_error(hcu_predict(full, data.table::data.table(age = 50, sex = "men", dimd = "11")), "dimd: values not in the model")
expect_error(hcu_predict(full, data.table::data.table(age = 50, sex = "men", died = 1L)), "both died and dies_next")
expect_error(hcu_predict(list(full, full), nd[1]), "same predictor set")

# ---- the default method (2026-11-08): "expected" for means, "simulate" for draws ----
expect_identical(attr(p, "hcucost")$method, "expected")
expect_identical(attr(d1, "hcucost")$method, "simulate")
expect_identical(attr(pe, "hcucost")$method, "simulate")
expect_warning(hcu_predict(as_m, x1, n_sim = 100L, n_points = 256L, seed = 1), "n_sim is not used")
expect_silent(hcu_predict(as_m, x1, method = "simulate", n_sim = 100L, seed = 1))

# ---- key (2026-11-08): records sharing a key share their random numbers ----
twin <- rbind(nd[4], nd[4], fill = TRUE)                     # a filled-in record, twice
k_same <- hcu_predict(set_all, twin, n_draws = 5L, n_points = 512L, seed = 3, key = c(7, 7))
expect_equal(k_same[1, -"row"], k_same[2, -"row"], tolerance = 0)
k_def <- hcu_predict(set_all, twin, n_draws = 5L, n_points = 512L, seed = 3)
expect_false(isTRUE(all.equal(k_def$healthcare_use_costs[1], k_def$healthcare_use_costs[2])))
s_same <- hcu_predict(set_all, twin, method = "simulate", n_draws = 3L, n_sim = 20L, seed = 3, key = c(2, 2))
expect_equal(s_same[1, -"row"], s_same[2, -"row"], tolerance = 0)
# the same profile at two ages: with a shared key the difference is far more precise
ages2 <- data.table::data.table(age = c(70, 71), sex = "women", t2dm_prvl = 5L)
diffs <- function(k) vapply(1:8, function(sd) diff(hcu_predict(full, ages2, n_draws = 10L, n_points = 256L, seed = sd,
                                                                 key = k)$healthcare_use_costs), 0)
expect_true(sd(diffs(c(1, 1))) < sd(diffs(NULL)) / 2)
expect_error(hcu_predict(full, ages2, key = 1), "one whole number per record")
expect_error(hcu_predict(full, ages2, key = c(0, 1)), "one whole number per record")
