# Parameter bundles: writing, reading, integrity, stripping and clearance status.

new_dir <- function() tempfile("hcucost_bundle_")

# ---- a bundle round-trips and is uncleared by default ----
p <- hcu_synthetic_params()
d <- new_dir()
hcu_bundle_write(p, d, model_version = "test-1") # predictors from the parameters (full model)
m <- hcu_model(d)
# exact equality of every value; not identical(): data.tables read back from the .rds file carry a
# null internal self-reference pointer, unlike the in-memory copy
expect_equal(m$params, hcu_strip_params(p), tolerance = 0)
expect_identical(m$status, "uncleared")
expect_identical(m$manifest$model_version, "test-1")
expect_identical(m$manifest$predictors, "ASRDN")
expect_identical(m$manifest$period, "CY")
expect_identical(m$manifest$components, names(p$counts))
expect_stdout(print(m), "IN-HOUSE USE ONLY")
unlink(d, recursive = TRUE)

# ---- a bundle whose md5 is in the registry is cleared ----
d <- new_dir()
hcu_bundle_write(hcu_synthetic_params(), d, model_version = "test-2")
md5 <- unname(tools::md5sum(file.path(d, "params.rds")))
reg <- data.table::data.table(params_md5 = md5, model_version = "test-2", cleared_on = "2026-11-06", reference = "x")
expect_identical(hcu_model(d, registry = reg)$status, "cleared")
# the package's registry: the files of the shipped CPRD bundles, cleared for release 2026-11-08
reg_pkg <- hcu_registry()
expect_identical(names(reg_pkg), c("params_md5", "model_version", "cleared_on", "reference"))
expect_false(anyDuplicated(reg_pkg$params_md5) > 0L)
expect_true(all(grepl("^[0-9a-f]{32}$", reg_pkg$params_md5)))
# read with read.csv (fread cannot memory-map files in webR, 2026-11-08): a data.table of character
# columns, the same table as fread reads
expect_true(data.table::is.data.table(reg_pkg))
expect_true(all(vapply(reg_pkg, is.character, NA)))
expect_equal(reg_pkg, data.table::fread(system.file("registry", "cleared_bundles.csv", package = "hcucost"),
                                        colClasses = "character"), tolerance = 0)
unlink(d, recursive = TRUE)

# ---- an altered parameter file is refused ----
d <- new_dir()
hcu_bundle_write(hcu_synthetic_params(), d, model_version = "test-3")
p3 <- readRDS(file.path(d, "params.rds"))
p3$count$pc$intercept <- p3$count$pc$intercept + 1
saveRDS(p3, file.path(d, "params.rds"))
expect_error(hcu_model(d), "does not match the manifest")
unlink(d, recursive = TRUE)

# ---- bundles are not overwritten by accident, and arguments are checked ----
d <- new_dir()
hcu_bundle_write(p, d, model_version = "test-4")
expect_error(hcu_bundle_write(p, d, model_version = "test-4"), "not empty")
expect_silent(hcu_bundle_write(p, d, model_version = "test-4", overwrite = TRUE))
expect_error(hcu_bundle_write(p, tempfile(), model_version = ""), "model_version")
expect_error(hcu_bundle_write(p, tempfile(), model_version = "x", predictors = "SR"), "predictors")
expect_error(hcu_model(tempfile()), "no manifest.json")
unlink(d, recursive = TRUE)

# ---- stripping keeps the prediction fields and drops the rest ----
p5 <- hcu_synthetic_params()
p5$gamma_selection <- data.frame(a = 1)
p5$count$pc$count_cal$table <- data.frame(n_py = 1)
p5$count$pc$death_recal$`1`$converged <- TRUE
p5$severity$pc$calibration <- data.frame(n_py = 1)
p5$dependence$G_score <- list(1)
p5$dependence$persistence$Sigma <- diag(5)
s <- hcu_strip_params(p5)
expect_null(s$gamma_selection)
expect_null(s$count$pc$count_cal$table)
expect_null(s$count$pc$death_recal$`1`$converged)
expect_null(s$severity$pc$calibration)
expect_null(s$dependence$G_score)
expect_null(s$dependence$persistence$Sigma)
expect_identical(s, hcu_strip_params(hcu_synthetic_params()))
expect_true("mix" %in% names(s$severity$pc)) # NULL placeholder kept, as in the fitted parameters

# ---- validation reports structural problems ----
p6 <- hcu_synthetic_params()
p6$severity$rx <- NULL
expect_error(hcu_validate_params(p6), "severity parts do not match")
p6 <- hcu_synthetic_params()
p6$dependence$persistence$P <- diag(5)
expect_error(hcu_validate_params(p6), "persistence\\$P")
expect_error(hcu_validate_params(1), "not a list")

# ---- death and co-occurrence models in a bundle (phase 3b) ----
ms <- hcu_synthetic_model()
expect_false(is.null(ms$death_model))
expect_false(is.null(ms$cooccurrence))
d <- new_dir()
hcu_bundle_write(ms$params, d, model_version = "test-5", death_model = ms$death_model, cooccurrence = ms$cooccurrence)
mb <- hcu_model(d)
expect_identical(mb$manifest$predictors, "ASRDN") # from the parameters
expect_true(all(file.exists(file.path(d, c("death_model.rds", "cooccurrence.rds")))))
expect_equal(mb$death_model$died$coefficients, ms$death_model$died$coefficients, tolerance = 0)
expect_equal(mb$cooccurrence$diseases$htn$presence$coef, ms$cooccurrence$diseases$htn$presence$coef, tolerance = 0)
expect_null(mb$cooccurrence$diseases$htn$presence$n) # stripped: no sample sizes
# cleared only if every file is in the registry
md5_p <- mb$manifest$params_md5
reg1 <- data.table::data.table(params_md5 = md5_p, model_version = "x", cleared_on = "2026-11-06", reference = "x")
expect_identical(hcu_model(d, registry = reg1)$status, "uncleared")
reg3 <- data.table::data.table(params_md5 = c(md5_p, mb$manifest$death_model_md5, mb$manifest$cooccurrence_md5),
                               model_version = "x", cleared_on = "2026-11-06", reference = "x")
expect_identical(hcu_model(d, registry = reg3)$status, "cleared")
# an altered death model is refused
dmx <- readRDS(file.path(d, "death_model.rds"))
dmx$died$coefficients[1] <- dmx$died$coefficients[1] + 1
saveRDS(dmx, file.path(d, "death_model.rds"))
expect_error(hcu_model(d), "death_model file does not match")
unlink(d, recursive = TRUE)
# a calibrated co-occurrence model: the calibration tables travel in the bundle, its in-house
# history and margins do not; the core reads the tables
cm_cal <- ms$cooccurrence
cm_cal$calibration <- hcucost:::new_fillin_calibration(names(cm_cal$diseases))
cm_cal$calibration$theta[, , , "3"] <- 0.25
cm_cal$calibration$delta["htn", , , ] <- -0.1
cm_cal$calibration$history <- data.frame(round = 0)
cm_cal$calibration$margins <- list(count = data.frame(observed = 3))
d <- new_dir()
hcu_bundle_write(ms$params, d, model_version = "test-5b", death_model = ms$death_model, cooccurrence = cm_cal)
mc <- hcu_model(d)
expect_equal(mc$cooccurrence$calibration$theta, cm_cal$calibration$theta, tolerance = 0)
expect_equal(mc$cooccurrence$calibration$delta, cm_cal$calibration$delta, tolerance = 0)
expect_equal(mc$cooccurrence$calibration$eps, cm_cal$calibration$eps, tolerance = 0)
expect_null(mc$cooccurrence$calibration$history)
expect_null(mc$cooccurrence$calibration$margins)
expect_true(mc$compiled_fill$cal$present)
expect_false(ms$compiled_fill$cal$present) # (uncalibrated: no tables)
# a format-2 calibration (no diagnosis-year table) is still accepted; the core then has no eps
cm2 <- cm_cal
cm2$calibration$eps <- NULL
d2 <- new_dir()
hcu_bundle_write(ms$params, d2, model_version = "test-5c", death_model = ms$death_model, cooccurrence = cm2)
m2 <- hcu_model(d2)
expect_true(m2$compiled_fill$cal$present && is.null(m2$compiled_fill$cal$eps))
unlink(d2, recursive = TRUE)
# a calibration of the wrong shape is refused
cm_bad <- cm_cal
cm_bad$calibration$delta <- cm_bad$calibration$delta[-1, , , ]
expect_error(hcu_bundle_write(ms$params, new_dir(), model_version = "x", cooccurrence = cm_bad), "delta must be an array")
unlink(d, recursive = TRUE)
# a reduced set: predictors from the parameters; no co-occurrence model; a mismatch is an error
mr <- hcu_synthetic_model(predictors = "AS")
d <- new_dir()
hcu_bundle_write(mr$params, d, model_version = "test-6", death_model = mr$death_model)
expect_identical(hcu_model(d)$manifest$predictors, "AS")
expect_error(hcu_bundle_write(mr$params, new_dir(), model_version = "x", predictors = "ASRDN"), "differ from the parameters")
expect_error(hcu_bundle_write(mr$params, new_dir(), model_version = "x", cooccurrence = ms$cooccurrence), "full model")
expect_error(hcu_bundle_write(mr$params, new_dir(), model_version = "x", death_model = ms$death_model), "not for predictor set")
unlink(d, recursive = TRUE)

# ---- disclosure audit (2026-11-08): bundles hold plain values only, no variance-covariance matrices,
# and nothing that can carry individual-level information (fitted model objects, formulas, functions,
# environments, per-record vectors, identifier-like strings)
ms <- hcu_synthetic_model()
p_vc <- ms$params
p_vc$count$pc$vcov <- diag(3) # (the pipeline's parameters carry them: stripping removes them)
p_vc$severity$apc$vcov <- diag(3)
dm_vc <- ms$death_model
dm_vc$died$vcov <- diag(3)
d <- new_dir()
hcu_bundle_write(p_vc, d, model_version = "audit", death_model = dm_vc, cooccurrence = ms$cooccurrence)
a <- hcu_audit_bundle(d)
expect_true(a$ok)
expect_identical(nrow(a$problems), 0L)
expect_false(any(grepl("vcov", a$inventory$path)), info = "no variance-covariance matrices in a bundle")
expect_true(all(a$inventory$type %in% c("NULL", "logical", "integer", "double", "character", "list")))
expect_identical(sort(unique(a$inventory$file)), c("cooccurrence.rds", "death_model.rds", "params.rds"))
m_a <- hcu_model(d) # (reads without a warning)
expect_identical(m_a$status, "uncleared")
unlink(d, recursive = TRUE)
# a fitted R model object: its data, residuals, fitted values, formula and environment are all found
set.seed(1)
fit <- stats::glm(y ~ x, family = stats::poisson(), data = data.frame(x = 1:20, y = stats::rpois(20, 3)))
af <- hcucost:::audit_object(fit, "fit")
expect_true(any(grepl("class glm", af$problem)))
expect_true(all(c("fit$residuals", "fit$fitted.values", "fit$y", "fit$model", "fit$data") %in% af$path))
expect_true(any(grepl("^type (language|closure|environment)", af$problem)), info = "formula, family functions or environment")
# hcu_bundle_write() refuses any of these where stripping keeps them (the specification is kept whole)
refused <- function(modify, pattern) {
  p_bad <- ms$params
  p_bad$spec <- modify(p_bad$spec)
  d_bad <- file.path(tempdir(), paste0("hcucost_audit_refused_", sample.int(1e6, 1L)))
  expect_error(hcu_bundle_write(p_bad, d_bad, model_version = "x"), pattern)
  expect_false(dir.exists(d_bad), info = "nothing written")
}
refused(function(s) { s$fit <- fit; s }, "nothing written")
refused(function(s) { s$f <- y ~ x; s }, "type language")
refused(function(s) { s$fun <- function(x) x; s }, "type closure")
refused(function(s) { s$v <- stats::runif(10000); s }, "vector of 10000 values")
refused(function(s) { s$tab <- data.frame(a = 1:200); s }, "table of 200 rows")
refused(function(s) { s$ids <- c("12345678", "abc"); s }, "identifier-like")
refused(function(s) { s$residuals <- 1:3; s }, "row-level model output")
refused(function(s) { attr(s$age_knots, "na.action") <- 1:3; s }, "attribute not allowed")
# a bundle written without the audit warns when read
p_bad <- ms$params
p_bad$spec$f <- y ~ x
d <- new_dir()
hcu_bundle_write(p_bad, d, model_version = "unaudited", audit = FALSE)
expect_warning(hcu_model(d), "audit problems")
expect_false(hcu_audit_bundle(d)$ok)
unlink(d, recursive = TRUE)
# the synthetic models (all predictor sets) pass
for (s in c("ASRDN", "A", "AS", "ASR", "AR", "AN")) {
  sm <- hcu_synthetic_model(predictors = s)
  pr <- hcucost:::audit_bundle_parts(list(params = sm$params, death_model = hcucost:::strip_death_model(sm$death_model),
                                          cooccurrence = if (!is.null(sm$cooccurrence)) hcucost:::strip_cooccurrence(sm$cooccurrence)))
  expect_identical(nrow(pr), 0L, info = s)
}
