# Calibration of the fill-in (hcu_calibrate_fillin(), 2026-11-07). Synthetic "observed" records get
# their diseases from the sampler under a KNOWN calibration (a tilt making the number of conditions
# more dispersed, and disease offsets); calibrating the uncalibrated sampler on them must reproduce
# their distribution of the number of conditions and their prevalences. Then the result's
# structure, its use by the core, and input errors.

full <- hcu_synthetic_model()
p <- full$params
dz <- p$spec$diseases$sim_name
prvl_cols <- paste0(dz, "_prvl")
set.seed(101)
n <- 4000L
recs <- hcucost:::synthetic_design_row(p)[rep(1L, n)][, c("year", "prop") := NULL]
recs[, `:=`(age = round(stats::runif(n, 20, 95)), sex = sample(c("men", "women"), n, TRUE),
            dimd = sample(p$spec$dimd_levels, n, TRUE), ethnicity = sample(p$spec$ethnicity_levels, n, TRUE),
            sha = sample(p$spec$sha_levels, n, TRUE), bmi = round(stats::runif(n, 18, 40), 1),
            smok = sample(c("never", "ex", "current"), n, TRUE))]
recs[, died := as.integer(stats::runif(n) < 0.2)] # (many decedents: their offsets are calibrated within the group)
recs[, dies_next := as.integer(died == 0L & stats::runif(n) < 0.08)]

# ---- the "truth": a calibration that spreads the number of conditions (more with none and with
# many) and shifts some diseases
cal_star <- hcucost:::new_fillin_calibration(dz)
kk <- 0:cal_star$k_max
for (k in kk) cal_star$theta[, , , k + 1L] <- -0.25 * k + 0.025 * k^2 # convex in k (lowest at 5): over-dispersion
cal_star$delta[c("htn", "chd", "copd"), , , ] <- 0.4
cal_star$delta[c("dementia", "asthma"), , , ] <- -0.4
cal_star$delta["copd", , , "died"] <- 1.2 # (more COPD among decedents only: offsets by death group)
cal_star$eps[c("htn", "chd"), ] <- 0.5 # (more in their year of diagnosis; decedents' strokes much more)
cal_star$eps["stroke", "died"] <- 1.5
cooc_star <- full$cooccurrence
cooc_star$calibration <- cal_star
star <- hcucost:::new_hcu_model(p, full$manifest, NA_character_, "synthetic", full$death_model, cooc_star)
hid <- data.table::copy(recs)
for (v in prvl_cols) data.table::set(hid, j = v, value = NA_integer_)
obs <- hcucost:::fill_in_core(star, hid, n_draws = 1L, burn_in = 40L, thin = 1L, seed = 7L, threads = 2L)$draws
obs <- cbind(recs[, !prvl_cols, with = FALSE], obs[, prvl_cols, with = FALSE])

# ---- calibrate the UNcalibrated sampler on these records
# (20 draws per record: the filled shares' Monte Carlo SE is then about 0.003; converged in ~4 rounds,
# claude_process/97_calibration_convergence.R)
cal <- hcu_calibrate_fillin(full, obs, rounds = 8L, n_draws = 20L, burn_in = 10L, seed = 3L, threads = 2L, verbose = FALSE)
h <- cal$history
expect_identical(h$round, 0:8)
expect_true(h$mean_abs_log_count[9] < 0.5 * h$mean_abs_log_count[1],
            info = paste("count fit", round(h$mean_abs_log_count[1], 3), "->", round(h$mean_abs_log_count[9], 3)))
expect_true(h$mean_abs_log_prevalence[9] < 0.5 * h$mean_abs_log_prevalence[1],
            info = paste("prevalence fit", round(h$mean_abs_log_prevalence[1], 3), "->", round(h$mean_abs_log_prevalence[9], 3)))
# stable: no drift or growing oscillation in the later rounds (uncentred offsets oscillated on the
# synthetic pipeline data, 2026-11-07)
expect_true(max(h$mean_abs_log_count[5:9]) < 2 * min(h$mean_abs_log_count[2:9]),
            info = paste(round(h$mean_abs_log_count, 3), collapse = " "))
# pooled over cells: the filled distribution of the number of conditions and the prevalences match
mk <- cal$margins$count[death_group != "unknown (weighted)", .(observed = sum(observed), filled = sum(filled)), by = k]
expect_true(max(abs(mk$filled / sum(mk$filled) - mk$observed / sum(mk$observed))) < 0.01,
            info = "pooled count distribution (known death group)")
mu <- cal$margins$count[death_group == "unknown (weighted)", .(observed = sum(observed), filled = sum(filled)), by = k]
expect_true(max(abs(mu$filled / sum(mu$filled) - mu$observed / sum(mu$observed))) < 0.01,
            info = "pooled count distribution (unknown death group)")
mp <- cal$margins$prevalence[death_group != "unknown (weighted)", .(observed = sum(observed * n), filled = sum(filled * n)),
                             by = disease][observed >= 100]
expect_true(max(abs(mp$filled / mp$observed - 1)) < 0.1, info = paste(round(mp$filled / mp$observed, 2), collapse = " "))
# the diagnosis-year share among present diseases (format 3): fitted, and decedents' strokes matched
expect_true(h$mean_abs_log_dur1[9] < 0.6 * h$mean_abs_log_dur1[1],
            info = paste("diagnosis-year fit", round(h$mean_abs_log_dur1[1], 3), "->", round(h$mean_abs_log_dur1[9], 3)))
me <- cal$margins$duration[death_group != "unknown (weighted)" & present >= 100]
expect_true(max(abs(log(me$filled_dur1 / me$observed_dur1))) < 0.25,
            info = paste("worst diagnosis-year cell", round(max(abs(log(me$filled_dur1 / me$observed_dur1))), 3)))
st <- cal$margins$duration[disease == "stroke" & death_group == "died"]
expect_true(abs(st$filled_dur1 / st$observed_dur1 - 1) < 0.15,
            info = paste("decedents' stroke diagnosis-year share", round(st$filled_dur1, 3), "vs", round(st$observed_dur1, 3)))
# offsets by death group: decedents' COPD prevalence (raised in the truth for decedents only) matched
mc <- cal$margins$prevalence[disease == "copd" & death_group == "died", .(observed = sum(observed * n), filled = sum(filled * n))]
ms <- cal$margins$prevalence[disease == "copd" & death_group == "survives", .(observed = sum(observed * n), filled = sum(filled * n))]
expect_true(abs(mc$filled / mc$observed - 1) < 0.1 && abs(ms$filled / ms$observed - 1) < 0.1,
            info = paste("COPD filled / observed: decedents", round(mc$filled / mc$observed, 3), "survivors", round(ms$filled / ms$observed, 3)))
expect_true(mean(cal$delta["copd", , , "died"]) > mean(cal$delta["copd", , , "survives"]) + 0.3,
            info = "decedents' COPD offset above survivors'")
# the recovered offsets have the truth's signs (the truth is in the calibration's family, so the
# calibration recovers it up to sampling error in well-populated cells)
# (offsets are centred within each cell, so only their differences are identified; compared where
# both diseases are common: survivors aged 60+, truth difference 0.8)
rel <- mean(cal$delta["htn", 4:7, , "survives"] - cal$delta["dementia", 4:7, , "survives"])
expect_true(rel > 0.3, info = paste("htn - dementia offset", round(rel, 2), "(truth 0.8)"))

# ---- structure; theta 0 at k = 0; the core reads it; structural zeros untouched
expect_true(hcucost:::validate_fillin_calibration(cal, dz))
expect_true(all(cal$theta[, , , 1L] == 0))
expect_true(all(cal$delta["prostate_ca", , "women", ] == 0) && all(cal$delta["breast_ca", , "men", ] == 0))
cooc2 <- full$cooccurrence
cooc2$calibration <- cal
m2 <- hcucost:::new_hcu_model(p, full$manifest, NA_character_, "synthetic", full$death_model, cooc2)
expect_true(m2$compiled_fill$cal$present)
f2 <- hcucost:::fill_in_core(m2, hid[1:50], n_draws = 2L, seed = 1L)$draws
expect_true(all(f2[sex == "women", prostate_ca_prvl] == 0L))
# weights are accepted (unknown-death-group margins and prevalences weighted)
cw <- hcu_calibrate_fillin(full, obs[1:400], weights = ifelse(obs$died[1:400] == 1L, 1, 5), rounds = 1L, n_draws = 2L,
                           threads = 2L, verbose = FALSE)
expect_true(isTRUE(cw$settings$weights) && nrow(cw$history) == 2L)

# ---- input errors
expect_error(hcu_calibrate_fillin(hcu_synthetic_model(predictors = "AS"), obs), "full model")
expect_error(hcu_calibrate_fillin(full, data.table::copy(obs)[1, htn_prvl := NA_integer_]), "every disease must be known")
expect_error(hcu_calibrate_fillin(full, obs[, !"died"]), "data lacks")
expect_error(hcu_calibrate_fillin(full, obs, weights = 1:2), "weights")
bad <- cal
bad$theta <- bad$theta[, , 1:3, ]
expect_error(hcucost:::validate_fillin_calibration(bad, dz), "theta must be an array")
