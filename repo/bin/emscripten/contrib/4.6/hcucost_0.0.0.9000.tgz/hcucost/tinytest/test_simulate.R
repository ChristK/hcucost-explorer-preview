# Simulation on the synthetic model, with each engine (the C++ core and the R reference
# implementation).

m <- hcu_synthetic_model()
lc <- hcu_synthetic_lifecourse(m, n_persons = 400, n_years = 8, seed = 5)
ks <- names(m$params$counts)
count_cols <- unname(m$params$counts)
cost_cols <- paste0(ks, "_costs")
big <- hcu_synthetic_lifecourse(m, n_persons = 3000, n_years = 5, seed = 11)

for (engine in c("cpp", "r")) {
  # ---- one row per input row, with valid counts and costs ----
  sim <- hcu_simulate_impactncd(m, lc, seed = 1, engine = engine)
  expect_identical(nrow(sim), nrow(lc), info = engine)
  expect_identical(names(sim), c(count_cols, cost_cols, "healthcare_use_costs"), info = engine)
  for (v in count_cols) expect_true(is.integer(sim[[v]]) && all(sim[[v]] >= 0L), info = paste(engine, v))
  for (j in seq_along(ks)) {
    expect_true(all(sim[[cost_cols[j]]] >= 0), info = paste(engine, ks[j]))
    expect_identical(sim[[cost_cols[j]]] > 0, sim[[count_cols[j]]] > 0, info = paste(engine, ks[j])) # cost iff use
  }
  expect_equal(sim$healthcare_use_costs, rowSums(sim[, cost_cols, with = FALSE]), info = engine)
  expect_identical(attr(sim, "hcucost")$status, "synthetic", info = engine)
  expect_identical(attr(sim, "hcucost")$engine, engine, info = engine)

  # ---- reproducible, aligned with the input order, and the caller's RNG state is left alone ----
  set.seed(99)
  before <- .Random.seed
  a <- hcu_simulate_impactncd(m, lc, seed = 7, engine = engine)
  expect_identical(.Random.seed, before, info = engine)
  expect_identical(a, hcu_simulate_impactncd(m, lc, seed = 7, engine = engine), info = engine)
  perm <- sample(nrow(lc))
  b <- hcu_simulate_impactncd(m, lc[perm], seed = 7, engine = engine)
  expect_identical(as.list(b[order(perm)]), as.list(a), info = engine) # same draws per person-year, any order
  expect_false(identical(a$pc_contacts, hcu_simulate_impactncd(m, lc, seed = 8, engine = engine)$pc_contacts),
               info = engine)

  # ---- the input is not modified ----
  copy_lc <- data.table::copy(lc)
  invisible(hcu_simulate_impactncd(m, lc, seed = 1, engine = engine))
  expect_identical(lc, copy_lc, info = engine)

  # ---- simulated mean counts agree with the model means (survivors, full-year exposure) ----
  sim <- hcu_simulate_impactncd(m, big, seed = 12, engine = engine)
  mm <- hcucost:::impactncd_to_model(big, m$params)
  surv <- mm$died == 0L & mm$dies_next == 0L
  mm[, prop := 1]
  X <- as.matrix(hcucost:::cost_design(mm, m$params$spec))
  nc <- hcucost:::model_ncond(mm, m$params$spec)
  grp <- hcucost:::death_group(mm$died, mm$dies_next)
  rows <- mm$row[surv]
  for (k in ks) {
    mu <- hcucost:::count_mean(X, nc, m$params$count[[k]], mm$prop, grp)[surv]
    y <- sim[[m$params$counts[[k]]]][rows]
    se <- stats::sd(y) / sqrt(length(y))
    expect_true(abs(mean(y) - mean(mu)) < 5 * se, info = paste(engine, "mean count", k))
  }

  # ---- independent draws (no copula), a single row and a data.frame input ----
  expect_identical(nrow(hcu_simulate_impactncd(m, lc, copula = FALSE, seed = 2, engine = engine)), nrow(lc),
                   info = engine)
  expect_identical(nrow(hcu_simulate_impactncd(m, lc[1], seed = 1, engine = engine)), 1L, info = engine)
  expect_identical(nrow(hcu_simulate_impactncd(m, as.data.frame(lc[1:20]), seed = 1, engine = engine)), 20L,
                   info = engine)
}

# ---- invalid lifecourses give clear errors ----
bad <- data.table::copy(lc)[, bmi_curr_xps := NULL]
expect_error(hcu_simulate_impactncd(m, bad), "lacks columns: bmi_curr_xps")
bad <- data.table::copy(lc)[1L, bmi_curr_xps := NA]
expect_error(hcu_simulate_impactncd(m, bad), "missing values in: bmi_curr_xps")
bad <- data.table::copy(lc)[1L, smok_status_curr_xps := 5L]
expect_error(hcu_simulate_impactncd(m, bad), "smok_status_curr_xps: values not in the model")
bad <- data.table::copy(lc)[, smok_status_curr_xps := factor(smok_status_curr_xps, levels = 4:1)]
expect_error(hcu_simulate_impactncd(m, bad), "must have the levels")
bad <- data.table::copy(lc)[1L, ethnicity := "martian"]
expect_error(hcu_simulate_impactncd(m, bad), "ethnicity: values not in the model: martian")
bad <- data.table::copy(lc)[1L, htn_prvl := -1L]
expect_error(hcu_simulate_impactncd(m, bad), "htn_prvl must hold non-negative whole numbers")
expect_error(hcu_simulate_impactncd(m, rbind(lc, lc[1])), "more than one row")
p1 <- lc[pid == lc$pid[1]]
expect_error(hcu_simulate_impactncd(m, p1[-2]), "consecutive")
p1 <- data.table::copy(lc[pid %in% lc[, .N, by = pid][N >= 3, pid][1]])
p1[1L, all_cause_mrtl := 1L]
expect_error(hcu_simulate_impactncd(m, p1), "after the year of death")
young <- data.table::copy(lc[1:5])[, age := 18L]
expect_warning(hcu_simulate_impactncd(m, young, seed = 1), "outside 20-100")
expect_error(hcu_simulate_impactncd(list(), lc), "hcu_model")
