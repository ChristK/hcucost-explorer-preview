# The C++ core against the R reference implementation, on the synthetic model: the building
# blocks (distribution functions, spline polynomials, mixture grids) and whole simulations from
# the reference's own random draws. The in-house version with the real parameters is in
# test_reference_pipeline.R.

source("helpers_core.R", local = TRUE)

m <- hcu_synthetic_model()

# ---- the distribution functions reproduce R's ----
set.seed(1)
x <- c(stats::rnorm(2e4, 0, 3), -40, -38.5, -10, -5.7, -0.6745, 0, 1e-20, 0.6745, 5.66, 8.29, 9, 40, NA)
expect_identical(hcucost:::cpp_pnorm(x), stats::pnorm(x))
p <- c(stats::runif(2e4), 1e-300, 1e-20, 1e-12, 1 - 1e-12, 0.075, 0.925, 0.5, 0, 1)
expect_identical(hcucost:::cpp_qnorm(p), stats::qnorm(p))
# negative binomial quantiles: small and large means (recurrence and Cornish-Fisher paths)
n <- 5e4
u <- pmin(stats::runif(n), 1 - 1e-12)
size <- exp(stats::runif(n, log(0.05), log(50)))
mu <- exp(stats::runif(n, log(1e-3), log(5000)))
expect_identical(hcucost:::cpp_qnbinom(u, size, mu), stats::qnbinom(u, size = size, mu = mu))
edge <- c(0, 1e-300, 0.5, 1 - 1e-12, 1)
expect_identical(hcucost:::cpp_qnbinom(edge, rep(2, 5), rep(3, 5)), stats::qnbinom(edge, size = 2, mu = 3))
sh <- exp(stats::runif(n, log(0.2), log(50)))
sc <- exp(stats::runif(n, log(0.01), log(1e4)))
expect_equal(hcucost:::cpp_qgamma(u, sh, sc), stats::qgamma(u, shape = sh, scale = sc), tolerance = 1e-12)
# hurdle positive-part mean: the reference's bisection
mu_h <- exp(stats::runif(1000, log(0.05), log(50)))
p_h <- hcucost:::hurdle_p(mu_h, 0.8, 0.7)
th <- exp(stats::runif(1000, log(0.3), log(5)))
expect_equal(hcucost:::cpp_hurdle_mustar(mu_h, p_h, th), hcucost:::hurdle_mustar(mu_h, p_h, th), tolerance = 1e-14)

# ---- mixture quantiles reproduce lnmix_quantile_z() ----
mix <- m$params$severity$apc$mix
z <- c(stats::qnorm(seq(1e-6, 1 - 1e-6, length.out = 5001)), -12, -8, 0, 8, 12)
for (i in seq_len(nrow(mix))) {
  p <- hcucost:::mix_par(mix, i)
  g <- hcucost:::mix_grid(p)
  expect_identical(exp(hcucost:::cpp_approx(z, g$x, g$y)), hcucost:::lnmix_quantile_z(z, p), info = paste("cell", i))
}

# ---- the design catalogue is the reference design, and the spline polynomials are exact ----
expect_identical(hcucost:::design_catalogue(m$params$spec)$name, hcucost:::design_columns(m$params))
expect_true(attr(m$compiled, "max_pp_error") < 1e-11)
# a design the compiler does not know stops with an error
p2 <- m$params
p2$count$pc$beta <- c(p2$count$pc$beta, mystery = 0.1)
expect_error(hcucost:::compile_params(p2), "unknown terms mystery")
p3 <- m$params
p3$severity$pc$count_beta <- c(p3$severity$pc$count_beta, mystery = 0.1)
expect_error(hcucost:::compile_params(p3), "unknown count terms")

# ---- the core reproduces the reference (synthetic model, every branch) ----
lc <- suppressWarnings(hcucost:::validate_lifecourse(edge_lifecourse(m), m$params)) # ages outside 20-100 on purpose
# the lifecourse reaches the branches: deaths (hurdle, recalibration), clamped ages and BMI,
# many conditions with a cancer, positive inpatient counts in the mixture cells
expect_true(sum(!is.na(lc$all_cause_mrtl)) > 20)
expect_true(any(lc$age < 20) && any(lc$age > 100) && any(lc$bmi_curr_xps > 60) && any(lc$bmi_curr_xps < 22))
expect_core_matches_reference(m, lc, seed = 11L)

# ---- a model without persistence parameters needs copula = FALSE ----
p <- m$params
p$dependence$persistence <- NULL
p$dependence$severity_persistence <- NULL
mm <- hcucost:::new_hcu_model(p, m$manifest, NA_character_, "synthetic")
lc <- hcu_synthetic_lifecourse(mm, n_persons = 20, n_years = 3)
expect_error(hcu_simulate_impactncd(mm, lc, seed = 1), "no persistence parameters")
expect_identical(nrow(hcu_simulate_impactncd(mm, lc, seed = 1, copula = FALSE)), nrow(lc))

# ---- reduced predictor sets (package phase 3a): the design follows the set; the core reproduces the reference ----
for (ps in c("A", "AS", "AR", "AN")) {
  mr <- hcu_synthetic_model(predictors = ps)
  expect_identical(mr$params$spec$predictors, ps, info = ps)
  expect_identical(mr$manifest$predictors, ps, info = ps)
  cols <- hcucost:::design_columns(mr$params)
  expect_identical(hcucost:::design_catalogue(mr$params$spec)$name, cols, info = ps)
  expect_identical(any(grepl("^(dimd_|eth_|sha_)", cols)), grepl("S", ps), info = ps)
  expect_identical(any(grepl("^(bmi[0-9]|smok_)", cols)), grepl("R", ps), info = ps)
  expect_identical(any(grepl("^(ncond_|agenc)", cols)), grepl("N", ps), info = ps)
  expect_false(any(grepl("^(htn|chd|t2dm)_|_any_|^ca_other", cols)), info = ps)
  shared <- if (ps == "AN") setdiff(cols, "ncond_1") else cols # AN: a separate band for one condition
  expect_true(all(shared %in% hcucost:::design_columns(m$params)), info = ps) # a subset of the full design
  expect_identical("ncond_1" %in% cols, ps == "AN", info = ps)
  lc_r <- suppressWarnings(hcucost:::validate_lifecourse(edge_lifecourse(mr, n_persons = 200L), mr$params))
  expect_core_matches_reference(mr, lc_r, seed = 21L)
}
expect_error(hcu_synthetic_params(predictors = "SA"), "predictors must be")
