# IN-HOUSE: the package's R reference implementation against the CPRD costing pipeline it was
# copied from, the C++ core against the reference with the real parameters, and the synthetic
# parameters against the real ones' structure. The file exits early where the pipeline is not
# available. Reads the real fitted parameters (aggregate) but prints nothing of them on success.

source("helpers_pipeline.R", local = TRUE)
source("helpers_core.R", local = TRUE)
if (!pipeline_available()) exit_file("CPRD costing pipeline not available (in-house tests)")

# The pipeline's code expects data.table to be attached (library(data.table)): its functions are
# sourced into an environment whose parent holds data.table's exports, and nothing of hcucost,
# so that a function missing from the pipeline cannot be taken silently from the package
pipeline_env <- function() {
  dt_exports <- new.env(parent = globalenv())
  for (nm in getNamespaceExports("data.table")) assign(nm, getExportedValue("data.table", nm), envir = dt_exports)
  env <- new.env(parent = dt_exports)
  for (f in c("cost_model_functions.R", "impactncd_adapter.R", "cooccurrence_functions.R")) {
    sys.source(file.path(pipeline_dir(), "R", f), envir = env, keep.source = FALSE)
  }
  env
}
env <- pipeline_env()

# the 38 functions copied into R/reference.R: the dependency closure of the entry points (the
# simulation, the death model and the co-occurrence predictions; tools/make_reference.R)
entry <- c("impactncd_healthcare_use", "death_model_predict", "cooc_predict", "cooc_design", "cooc_own_cols",
           "cooc_band_labels")
copied <- c("hurdle_mustar", "hurdle_p", "sim_latent_paths", "nb_from_latent", "sev_quantile", "draw_total_cost",
            "lnmix_quantile_z", "mix_par", "mix_index", "count_band", "prvl_band", "spec_predictors", "has_group",
            "ns_basis", "dummies", "cost_design", "phi_for", "severity_eta", "simulate_counts_costs", "model_ncond",
            "mm_scale", "linear_predictor", "death_recal_matrix", "recalibrate_eta", "count_mean", "count_cal_shift",
            "death_group", "theta_for", "margin_for", "death_design", "death_model_predict", "impactncd_to_model",
            "impactncd_healthcare_use", "cooc_band_labels", "cooc_design", "cooc_own_cols", "cooc_eta", "cooc_predict")

# ---- every copied function is identical to the pipeline's ----
ns <- asNamespace("hcucost")
for (f in copied) {
  # removeSource(): source references can also sit inside function bodies (packages loaded with
  # keep.source), which ignore.srcref does not cover
  expect_true(identical(utils::removeSource(get(f, envir = ns)), utils::removeSource(get(f, envir = env)),
                        ignore.environment = TRUE, ignore.srcref = TRUE, ignore.bytecode = TRUE), info = f)
}
# and the copy is complete: nothing else in the pipeline is needed (the closure is unchanged)
if (requireNamespace("codetools", quietly = TRUE)) {
  fns <- ls(env)[vapply(ls(env), function(n) is.function(env[[n]]), logical(1))]
  seen <- character()
  todo <- entry
  while (length(todo)) {
    f <- todo[1L]
    todo <- todo[-1L]
    if (f %in% seen) next
    seen <- c(seen, f)
    todo <- c(todo, setdiff(intersect(codetools::findGlobals(env[[f]], merge = TRUE), fns), seen))
  }
  expect_true(setequal(seen, copied), info = "dependency closure of the entry points")
}

for (period in c("CY", "FY")) {
  f <- real_params_file(period)
  if (!file.exists(f)) next # no parameter file for this period
  full <- readRDS(f)
  model <- hcucost:::new_hcu_model(hcu_strip_params(full), list(model_version = paste0("real-", period),
                                   period = period, predictors = "ASRDN"), NA_character_, "uncleared")

  # ---- simulation is identical to the pipeline's with the real parameters (stripped) ----
  expect_true(hcu_validate_params(model$params), info = period)
  lc <- hcu_synthetic_lifecourse(model, n_persons = 1500, n_years = 6, seed = 21)
  set.seed(31)
  ref <- env$impactncd_healthcare_use(lc, full)
  pkg <- hcu_simulate_impactncd(model, lc, seed = 31, engine = "r")
  data.table::setattr(pkg, "hcucost", NULL)
  expect_identical(pkg, ref, info = paste(period, "with copula"))
  set.seed(32)
  ref_nc <- env$impactncd_healthcare_use(lc, full, copula = FALSE)
  pkg_nc <- hcu_simulate_impactncd(model, lc, copula = FALSE, seed = 32, engine = "r")
  data.table::setattr(pkg_nc, "hcucost", NULL)
  expect_identical(pkg_nc, ref_nc, info = paste(period, "without copula"))

  # ---- the C++ core reproduces the reference with the real parameters ----
  expect_true(attr(model$compiled, "max_pp_error") < 1e-11, info = period)
  lc_edge <- suppressWarnings(hcucost:::validate_lifecourse(edge_lifecourse(model, n_persons = 2000L, seed = 41L),
                                                            model$params)) # ages outside 20-100 on purpose
  expect_core_matches_reference(model, lc_edge, seed = 43L)
}

# ---- the synthetic parameters have the structure of the real CY parameters ----
f <- real_params_file("CY")
if (file.exists(f)) {
  real <- hcu_strip_params(readRDS(f))
  syn <- hcu_synthetic_params(period = "CY")
  # the cost-per-unit dispersion by death group leaves out bands with too few users (they use the
  # pooled value), so which bands are present depends on the data: compare those separately
  bands <- c("1", "2", "3-4", "5-9", "10-19", "20+")
  for (x in list(syn, real)) for (k in names(x$severity)) {
    expect_identical(names(x$severity[[k]]$phi_groups), c("0", "1", "2"), info = k)
    for (g in x$severity[[k]]$phi_groups) expect_true(all(names(g) %in% bands), info = k)
  }
  drop_pg <- function(p) {
    for (k in names(p$severity)) p$severity[[k]]$phi_groups <- NULL
    p
  }
  expect_identical(param_shape(drop_pg(syn)), param_shape(drop_pg(real)))
  # the design specification (modelling choices) is the same, values included
  expect_equal(syn$spec[names(syn$spec) != "diseases"], real$spec[names(real$spec) != "diseases"])
  expect_equal(as.data.frame(syn$spec$diseases), as.data.frame(real$spec$diseases))
  expect_identical(syn$counts, real$counts)
  expect_identical(sapply(syn$severity, `[[`, "family"), sapply(real$severity, `[[`, "family"))
}
