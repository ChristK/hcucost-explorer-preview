# Filling in unknown predictors (R reference, R/fillin.R) on the synthetic co-occurrence and death
# models: known values are kept, a known number of conditions is respected, the draws are
# reproducible, and on a toy model whose full conditionals come from a known joint the draws
# reproduce that joint.

p <- hcu_synthetic_params()
cooc <- hcucost:::synthetic_cooccurrence_model(p)
dm <- hcucost:::synthetic_death_model(p)
dz <- p$spec$diseases$sim_name
base <- hcucost:::synthetic_design_row(p)[, c("year", "prop") := NULL]
prvl_cols <- paste0(dz, "_prvl")

# ---- every value known: the draws are the record ----
x <- base[rep(1, 3)][, age := c(40, 65, 85)][, htn_prvl := c(0L, 3L, 12L)]
f <- hcucost:::fill_in_r(cooc, x, n_draws = 3L, burn_in = 1L, thin = 1L)
expect_identical(nrow(f$draws), 9L)
for (v in c("dimd", "ethnicity", "sha", "smok")) expect_true(all(f$draws[[v]] == rep(x[[v]], 3)), info = v)
expect_true(all(f$draws$bmi == 25) && all(f$draws$htn_prvl == rep(c(0L, 3L, 12L), 3)))

# ---- unknowns are filled; known values never change; a known count is respected ----
set.seed(5)
x <- base[rep(1, 40)][, age := round(runif(40, 30, 95))]
x[, (prvl_cols[1:10]) := NA_integer_] # 10 unknown diseases
x[1:20, ncond := 3L] # known total: 3 of the 26 (the other 16 known absent)
x[21:30, chd_prvl := -1L] # chd present, duration unknown (also unknown presence in rows 1-20, 31-40)
x[31:40, `:=`(dimd = NA, ethnicity = NA, bmi = NA, smok = NA)]
f <- hcucost:::fill_in_r(cooc, x, n_draws = 10L, burn_in = 5L, thin = 1L, seed = 3L)
dr <- f$draws
expect_false(anyNA(dr[, c("dimd", "ethnicity", "sha", "bmi", "smok", prvl_cols), with = FALSE]))
expect_true(all(dr[row <= 20, ncond] == 3L), info = "known count kept")
expect_true(all(dr[row %in% 21:30, chd_prvl] > 0L), info = "known presence kept")
expect_true(all(dr[row %in% 21:30, chd_prvl] %in% c(1L, 2L, 4L, 8L, 15L)), info = "a band's representative duration")
expect_true(all(dr[row <= 30, dimd] == x$dimd[1]), info = "known deprivation kept")
expect_true(all(unlist(dr[, prvl_cols[11:26], with = FALSE]) == 0L), info = "known-absent diseases kept")
expect_true(all(dr[row > 30, dimd] %in% p$spec$dimd_levels) && all(dr[row > 30, bmi] >= 12 & dr[row > 30, bmi] <= 90))
expect_true(f$swap_acceptance > 0 && f$swap_acceptance <= 1)
# reproducible, and the caller's random number state is left alone
set.seed(9)
before <- .Random.seed
f2 <- hcucost:::fill_in_r(cooc, x, n_draws = 10L, burn_in = 5L, thin = 1L, seed = 3L)
expect_identical(.Random.seed, before)
expect_identical(as.list(f2$draws), as.list(dr)) # (as.list: filtering dr above added a data.table index)
expect_error(hcucost:::fill_in_r(cooc, data.table::copy(base)[, ncond := 3L]), "inconsistent")
expect_error(hcucost:::fill_in_r(cooc, data.table::copy(base)[, age := NA]), "age and sex")

# ---- a toy model with a known joint: the draws reproduce it, with and without a known count ----
# full conditionals of htn and chd from p(h, c) ~ exp(a1 h + a2 c + b h c); every other coefficient
# 0 and every other disease known absent
toy <- cooc
zero <- function(m) { m$coef[] <- 0; m }
for (z in dz) toy$diseases[[z]]$presence <- zero(toy$diseases[[z]]$presence)
a1 <- -0.5; a2 <- -1; b <- 1.2
toy$diseases$htn$presence$coef[c("(Intercept)", "has_chd")] <- c(a1, b)
toy$diseases$chd$presence$coef[c("(Intercept)", "has_htn")] <- c(a2, b)
w <- c(`00` = 1, `10` = exp(a1), `01` = exp(a2), `11` = exp(a1 + a2 + b))
truth <- w / sum(w)
xt <- base[rep(1, 300)][, `:=`(htn_prvl = NA_integer_, chd_prvl = NA_integer_)]
ft <- hcucost:::fill_in_r(toy, xt, n_draws = 40L, burn_in = 5L, thin = 2L, seed = 11L)$draws
emp <- prop.table(table(factor(paste0(as.integer(ft$htn_prvl > 0), as.integer(ft$chd_prvl > 0)), levels = names(truth))))
expect_true(max(abs(as.numeric(emp) - truth)) < 0.02, info = "Gibbs reproduces the joint")
# known count 1: P(htn only) = exp(a1) / (exp(a1) + exp(a2)), by swap moves
fk <- hcucost:::fill_in_r(toy, xt[, ncond := 1L], n_draws = 40L, burn_in = 5L, thin = 2L, seed = 12L)$draws
expect_true(all(fk$ncond == 1L))
expect_true(abs(mean(fk$htn_prvl > 0) - exp(a1) / (exp(a1) + exp(a2))) < 0.03, info = "swap moves reproduce the joint")

# ---- a calibration tilts the target exactly: p(h, c) x exp(theta(h + c) + delta_h h + delta_c c) ----
# (every other disease known absent, so the number of conditions is h + c); R reference and core
cal_t <- hcucost:::new_fillin_calibration(dz)
th1 <- 0.7; th2 <- -0.4; dh <- 0.3; dc <- -0.2
cal_t$theta[, , , "1"] <- th1
cal_t$theta[, , , "2"] <- th2
cal_t$delta["htn", , , ] <- dh
cal_t$delta["chd", , , ] <- dc
toy_cal <- toy
toy_cal$calibration <- cal_t
wt <- c(`00` = 1, `10` = exp(a1 + dh + th1), `01` = exp(a2 + dc + th1), `11` = exp(a1 + a2 + b + dh + dc + th2))
truth_t <- wt / sum(wt)
xt_free <- data.table::copy(xt)[, ncond := NA_integer_]
pair_freq <- function(f) as.numeric(prop.table(table(factor(paste0(as.integer(f$htn_prvl > 0), as.integer(f$chd_prvl > 0)),
                                                            levels = names(truth_t)))))
ftc <- hcucost:::fill_in_r(toy_cal, xt_free, n_draws = 40L, burn_in = 5L, thin = 2L, seed = 21L)$draws
expect_true(max(abs(pair_freq(ftc) - truth_t)) < 0.02, info = "tilted Gibbs reproduces the tilted joint (R)")
toy_m <- hcucost:::new_hcu_model(p, list(model_version = "toy", period = "CY", predictors = "ASRDN"), NA_character_,
                                 "synthetic", NULL, toy_cal)
fcc <- hcucost:::fill_in_core(toy_m, xt_free, n_draws = 40L, burn_in = 5L, thin = 2L, seed = 22L)$draws
expect_true(max(abs(pair_freq(fcc) - truth_t)) < 0.02, info = "tilted Gibbs reproduces the tilted joint (core)")
# a known count of 1: theta cancels (same count either way), delta does not
fkc <- hcucost:::fill_in_core(toy_m, data.table::copy(xt)[, ncond := 1L], n_draws = 40L, burn_in = 5L, thin = 2L, seed = 23L)$draws
expect_true(abs(mean(fkc$htn_prvl > 0) - exp(a1 + dh) / (exp(a1 + dh) + exp(a2 + dc))) < 0.03,
            info = "swap moves follow delta")

# ---- the diagnosis-year tilt (format 3) is exact too: with constant band models (intercepts only),
# p(h, c) x exp(theta + delta) x T_h^h x T_c^c, T = sum_b pb_b w_b, and the diagnosis-year share of a
# present disease pb_1 exp(eps) / T; with a known count the swap moves carry T_j / T_i
toy_e <- toy_cal
for (z in c("htn", "chd")) toy_e$diseases[[z]]$band$coef[, -1] <- 0
eh <- 1.1; ec <- -0.6
toy_e$calibration$eps["htn", ] <- eh
toy_e$calibration$eps["chd", ] <- ec
xr <- data.table::copy(base[1])[, year := toy$spec$ref_year] # (every disease known: no NA in the design)
Xr <- hcucost:::cooc_design(xr, toy$spec)
pb1 <- function(z) hcucost:::cooc_predict(toy_e$diseases[[z]]$band, Xr)[1, "1"]
Th <- 1 + pb1("htn") * (exp(eh) - 1)
Tc <- 1 + pb1("chd") * (exp(ec) - 1)
we <- c(`00` = 1, `10` = exp(a1 + dh + th1) * Th, `01` = exp(a2 + dc + th1) * Tc, `11` = exp(a1 + a2 + b + dh + dc + th2) * Th * Tc)
truth_e <- we / sum(we)
toy_em <- hcucost:::new_hcu_model(p, list(model_version = "toy", period = "CY", predictors = "ASRDN"), NA_character_,
                                  "synthetic", NULL, toy_e)
fe_r <- hcucost:::fill_in_r(toy_e, xt_free, n_draws = 40L, burn_in = 5L, thin = 2L, seed = 31L)$draws
fe_c <- hcucost:::fill_in_core(toy_em, xt_free, n_draws = 40L, burn_in = 5L, thin = 2L, seed = 32L)$draws
for (fe in list(fe_r, fe_c)) {
  expect_true(max(abs(pair_freq(fe) - truth_e)) < 0.02, info = "diagnosis-year tilt: presence joint")
  expect_true(abs(mean(fe$htn_prvl[fe$htn_prvl > 0] == 1L) - pb1("htn") * exp(eh) / Th) < 0.02,
              info = "diagnosis-year tilt: htn's diagnosis-year share")
  expect_true(abs(mean(fe$chd_prvl[fe$chd_prvl > 0] == 1L) - pb1("chd") * exp(ec) / Tc) < 0.03,
              info = "diagnosis-year tilt: chd's diagnosis-year share")
}
fek <- hcucost:::fill_in_core(toy_em, data.table::copy(xt)[, ncond := 1L], n_draws = 40L, burn_in = 5L, thin = 2L, seed = 33L)$draws
expect_true(abs(mean(fek$htn_prvl > 0) - exp(a1 + dh) * Th / (exp(a1 + dh) * Th + exp(a2 + dc) * Tc)) < 0.03,
            info = "swap moves carry T_j / T_i")

# ---- a known death group: decedents' unknown diseases are filled with more disease ----
xd <- base[rep(1, 200)][, age := 80][, (prvl_cols) := NA_integer_][, `:=`(died = rep(c(0L, 1L), each = 100), dies_next = 0L)]
fd <- hcucost:::fill_in_r(cooc, xd, death_model = dm, n_draws = 5L, burn_in = 3L, thin = 1L, seed = 13L)$draws
m_alive <- fd[died == 0L, mean(ncond)]
m_dead <- fd[died == 1L, mean(ncond)]
expect_true(m_dead > m_alive, info = paste("decedents", round(m_dead, 2), "vs survivors", round(m_alive, 2)))

# ---- a death group the death model gives probability 0 does not break the fill-in ----
dm0 <- dm
dm0$died$coefficients["(Intercept)"] <- -800 # exp(-800) underflows: the rate and P(died) are exactly 0
x0 <- base[rep(1, 20)][, age := 70][, (prvl_cols[1:5]) := NA_integer_][, `:=`(died = 1L, dies_next = 0L)]
f0 <- hcucost:::fill_in_r(cooc, x0, death_model = dm0, n_draws = 3L, burn_in = 2L, thin = 1L, seed = 14L)$draws
expect_false(anyNA(f0[, c("bmi", prvl_cols), with = FALSE]), info = "no NaN from zero death weights")

# ---- the C++ core gives the R reference's draws given the same uniforms ----
xc <- base[rep(1, 40)][, age := round(seq(30, 95, length.out = 40))][, sex := rep(c("men", "women"), 20)]
xc[, (prvl_cols[1:12]) := NA_integer_]
xc[1:10, ncond := 3L]
xc[11:16, chd_prvl := -1L]
xc[17:28, `:=`(dimd = NA, ethnicity = NA, bmi = NA, smok = NA)]
xc[29:40, `:=`(died = rep(c(0L, 1L, 0L), 4), dies_next = rep(c(0L, 0L, 1L), 4))]
full_m <- hcu_synthetic_model()
per <- hcucost:::fill_in_uniforms_per_sweep(length(dz), max(1L, length(dz) %/% 2L))
set.seed(78)
U <- array(runif(nrow(xc) * per * 9L), c(nrow(xc), per, 9L)) # burn-in 3 + 3 draws x thin 2
a <- hcucost:::fill_in_r(full_m$cooccurrence, xc, death_model = full_m$death_model, n_draws = 3L, burn_in = 3L, thin = 2L,
                         uniforms = U)$draws
b <- hcucost:::fill_in_core(full_m, xc, n_draws = 3L, burn_in = 3L, thin = 2L, uniforms = U)$draws
data.table::setorder(a, draw, row)
data.table::setorder(b, draw, row)
for (v in c("dimd", "ethnicity", "sha", "smok", prvl_cols, "ncond")) expect_identical(b[[v]], a[[v]], info = v)
expect_equal(b$bmi, a$bmi, tolerance = 1e-12)
# its own random numbers: reproducible, known values kept, the count respected
c1 <- hcucost:::fill_in_core(full_m, xc, n_draws = 3L, burn_in = 3L, thin = 2L, seed = 4)$draws
expect_identical(as.list(c1), as.list(hcucost:::fill_in_core(full_m, xc, n_draws = 3L, burn_in = 3L, thin = 2L, seed = 4)$draws))
expect_true(all(c1[row <= 10, ncond] == 3L) && all(c1[row %in% 11:16, chd_prvl] > 0L))

# ---- a very small death rate (P(died) = -expm1(-rate), not rounded to 0): core and R agree ----
# rate about 4e-18 x the age/disease terms: 1 - exp(-rate) would be 0 and drop the death weights,
# -expm1(-rate) keeps them (tiny but informative). Both implementations must use the same formula.
dm_tiny <- full_m$death_model
dm_tiny$died$coefficients["(Intercept)"] <- -40
tiny_m <- hcucost:::new_hcu_model(full_m$params, full_m$manifest, NA_character_, "uncleared", dm_tiny, full_m$cooccurrence)
xt2 <- xc[29:40][, died := 1L][, dies_next := 0L]
a2 <- hcucost:::fill_in_r(tiny_m$cooccurrence, xt2, death_model = dm_tiny, n_draws = 3L, burn_in = 3L, thin = 2L,
                          uniforms = U[29:40, , , drop = FALSE])$draws
b2 <- hcucost:::fill_in_core(tiny_m, xt2, n_draws = 3L, burn_in = 3L, thin = 2L, uniforms = U[29:40, , , drop = FALSE])$draws
data.table::setorder(a2, draw, row)
data.table::setorder(b2, draw, row)
expect_false(anyNA(b2[, c("bmi", prvl_cols), with = FALSE]), info = "tiny death rate: no NaN")
for (v in c("dimd", "ethnicity", "sha", "smok", prvl_cols)) expect_identical(b2[[v]], a2[[v]], info = paste("tiny rate", v))
expect_true(all(hcucost:::death_model_predict(dm_tiny, data.table::copy(base)[, age := 50])$p_died > 0))

# ---- with a calibration the core still gives the R reference's draws given the same uniforms ----
# (random tilts and offsets; the records cover free, constrained, duration-only, S/R-unknown and
# death-known updates)
cal_r <- hcucost:::new_fillin_calibration(dz)
set.seed(79)
cal_r$theta[] <- stats::rnorm(length(cal_r$theta), sd = 0.5)
cal_r$theta[, , , "0"] <- 0
cal_r$delta[] <- stats::rnorm(length(cal_r$delta), sd = 0.5)
cal_r$eps[] <- stats::rnorm(length(cal_r$eps), sd = 0.5)
cooc_cal <- full_m$cooccurrence
cooc_cal$calibration <- cal_r
cal_m <- hcucost:::new_hcu_model(full_m$params, full_m$manifest, NA_character_, "synthetic", full_m$death_model, cooc_cal)
a3 <- hcucost:::fill_in_r(cooc_cal, xc, death_model = full_m$death_model, n_draws = 3L, burn_in = 3L, thin = 2L,
                          uniforms = U)$draws
b3 <- hcucost:::fill_in_core(cal_m, xc, n_draws = 3L, burn_in = 3L, thin = 2L, uniforms = U)$draws
data.table::setorder(a3, draw, row)
data.table::setorder(b3, draw, row)
for (v in c("dimd", "ethnicity", "sha", "smok", prvl_cols, "ncond")) expect_identical(b3[[v]], a3[[v]], info = paste("calibrated", v))
expect_equal(b3$bmi, a3$bmi, tolerance = 1e-12)
expect_false(identical(as.matrix(a3[, prvl_cols, with = FALSE]), as.matrix(a[, prvl_cols, with = FALSE])),
             info = "the calibration changes the draws")

# ---- structural zeros: no prostate cancer drawn for women, no breast cancer for men ----
xz <- base[rep(1, 200)][, `:=`(age = 75, sex = rep(c("men", "women"), 100))][, (prvl_cols) := NA_integer_]
for (fz in list(hcucost:::fill_in_r(cooc, xz, n_draws = 3L, burn_in = 2L, thin = 1L, seed = 15L)$draws,
                hcucost:::fill_in_core(full_m, xz, n_draws = 3L, burn_in = 2L, thin = 1L, seed = 15L)$draws)) {
  expect_true(all(fz[sex == "women", prostate_ca_prvl] == 0L) && all(fz[sex == "men", breast_ca_prvl] == 0L))
  expect_true(any(fz[sex == "men", prostate_ca_prvl] > 0L)) # (but drawn for men)
}
