# The fitted CPRD models shipped in inst/bundles (2026-11-08): present for both periods, cleared for
# release (every file in the registry),
# audited (no individual-level information, no variance-covariance matrices), consistent manifests,
# and usable by hcu_predict() and hcu_simulate_impactncd(). Results are checked for structure only.

root <- system.file("bundles", package = "hcucost")
if (!nzchar(root)) exit_file("no shipped bundles in this installation")
sets <- c("ASRDN", "A", "AS", "ASR", "AR", "AN")
idx <- data.table::fread(file.path(root, "bundles.csv"))
expect_identical(sort(idx$bundle), sort(paste0("bundle_", rep(c("CY", "FY"), each = 6L), "_", sets)))
expect_true(all(idx$audit == "passed"))
reg <- hcu_registry()
shipped <- unlist(lapply(file.path(root, idx$bundle), function(b) {
  mf <- jsonlite::read_json(file.path(b, "manifest.json"), simplifyVector = TRUE)
  unlist(mf[grep("_md5$", names(mf))], use.names = FALSE)
}))
expect_identical(length(shipped), 26L)
expect_true(setequal(shipped, reg$params_md5), info = "the registry lists exactly the shipped bundles' files")
for (per in c("CY", "FY")) {
  m <- hcu_fitted_models(per)
  expect_identical(names(m), sets, info = per)
  for (s in sets) {
    expect_identical(m[[s]]$status, "cleared", info = paste(per, s))
    expect_identical(m[[s]]$manifest$period, per, info = paste(per, s))
    expect_identical(m[[s]]$manifest$predictors, s, info = paste(per, s))
    expect_false(is.null(m[[s]]$death_model), info = paste(per, s))
    expect_identical(m[[s]]$manifest$params_md5, idx[bundle == paste0("bundle_", per, "_", s), params_md5])
    a <- suppressMessages(hcu_audit_bundle(file.path(root, paste0("bundle_", per, "_", s))))
    expect_true(a$ok, info = paste(per, s))
    expect_false(any(grepl("vcov", a$inventory$path)), info = paste(per, s))
  }
  expect_false(is.null(m$ASRDN$cooccurrence), info = per)
  expect_identical(m$ASRDN$cooccurrence$calibration$format, 3L, info = per)
  expect_true(is.null(m$A$cooccurrence), info = per)
}
# usable: an invented record through the full model's fill-in and an exact reduced model; a synthetic
# lifecourse through the full model
m <- hcu_fitted_models("CY")
nd <- data.table::data.table(age = c(60, 75), sex = c("women", "men"), t2dm_prvl = c(4, NA), died = 0L, dies_next = 0L)
p <- hcu_predict(m, nd, n_draws = 3, n_points = 1024L, seed = 1)
expect_identical(p$model, c("ASRDN", "A"))
expect_true(all(is.finite(p$healthcare_use_costs) & p$healthcare_use_costs > 0))
expect_identical(unname(attr(p, "hcucost")$models), sets)
lc <- hcu_synthetic_lifecourse(hcu_synthetic_model(), n_persons = 50, n_years = 3)
sim <- hcu_simulate_impactncd(m$ASRDN, lc, seed = 1)
expect_identical(nrow(sim), nrow(lc))
expect_identical(attr(sim, "hcucost")$status, "cleared")
# expected values of the same lifecourse (2026-11-08): the fitted models' latent processes are
# stationary, so the function accepts them (agreement with the simulation: test_expected.R on the
# synthetic model; on the fitted CY model in the process script ev_12_lifecourse_check.R)
ev <- hcu_expected_impactncd(m$ASRDN, lc, seed = 1)
expect_identical(nrow(ev), nrow(lc))
expect_identical(attr(ev, "hcucost")$status, "cleared")
expect_true(all(is.finite(ev$healthcare_use_costs) & ev$healthcare_use_costs > 0 & is.finite(ev$se_healthcare_use_costs)))
expect_error(hcu_fitted_models("CY", sets = "ASRD"), "no shipped bundle")

# expected values without simulation on the fitted models (2026-11-08): the multipliers of every
# cell (including the inpatient mixtures) have mean 1, and the expected total cost of an invented
# profile (death group unknown, all three groups) agrees with the simulation
for (per in c("CY", "FY")) {
  mm <- hcu_fitted_models(per, sets = "ASRDN")$ASRDN
  expect_true(all(abs(hcucost:::cpp_expect_mult(mm$compiled) - 1) < 1e-5), info = per)
}
x <- data.table::data.table(age = 82, sex = "women", t2dm_prvl = 7L, ckd_prvl = 3L, dimd = m$ASRDN$params$spec$dimd_levels[4],
                            ethnicity = "white", sha = "North West", bmi = 28, smok = "never")
for (z in setdiff(m$ASRDN$params$spec$diseases$sim_name, c("t2dm", "ckd"))) data.table::set(x, j = paste0(z, "_prvl"), value = 0L)
e <- hcu_predict(m, x, method = "expected", seed = 2)
s <- hcu_predict(m, x, method = "simulate", n_sim = 100000L, seed = 2)
expect_identical(e$model, "ASRDN")
expect_true(e$se_healthcare_use_costs / e$healthcare_use_costs < 0.01)
expect_true(abs(e$healthcare_use_costs - s$healthcare_use_costs) <
              4 * sqrt(e$se_healthcare_use_costs^2 + s$se_healthcare_use_costs^2),
            info = paste(round(e$healthcare_use_costs, 1), round(s$healthcare_use_costs, 1)))
