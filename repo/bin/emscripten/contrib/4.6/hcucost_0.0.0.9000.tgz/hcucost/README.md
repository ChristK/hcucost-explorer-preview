# hcucost (prototype)

Joint simulation of annual **healthcare use and cost** in England for each person-year:

- primary care contacts;
- A&E attendances;
- outpatient attendances;
- inpatient spells;
- prescription items;
- the cost of each component and the total.

The model was fitted to linked primary care (CPRD Aurum), hospital (HES) and prescribing records.
- **Counts:** negative binomial margins, or hurdle margins in the years around death.
- **Cost per unit:** gamma, lognormal or lognormal-mixture margins.
- **Dependence:** the five components are linked by a Gaussian copula with a permanent person
  component and VAR(1) persistence over years.

So the package reproduces the correlation between components and the persistence of high or low use
over a person's years, as well as the means. It is built for the IMPACTncd England microsimulation
and for other users.

## Status

- **Prototype, phases 1-3b done. Not for distribution yet.**
- **Documentation:** `vignette("hcucost")` (getting started) and `vignette("methods")` (methods
  and validation on the CPRD data).
- The simulation runs in a **C++ core** (`inst/include/hcucost/`, header-only, no R API inside):
  - no design matrix: every linear predictor is a set of small lookup tables built once per model
    (`R/compile.R`); the age and BMI splines are stored as cubic polynomials between the knots,
    which is exact (each spline basis function is a cubic between knots);
  - one pass per person over their consecutive years;
  - random numbers from a counter-based generator (Philox4x32-10) keyed on
    (seed, person, year), so a person's results depend only on the seed and their own rows: not on
    threads, chunking or the other persons. Scenarios run with the same seed share each person's
    latent paths (common random numbers);
  - optional OpenMP threads (`threads = 1` by default).
- The **R reference implementation** (`R/reference.R`) is kept: a generated, verbatim copy of the
  fitting pipeline's prediction code (`engine = "r"`).
- **Checks** (tinytest, `inst/tinytest/`):
  - in-house (`inst/tinytest/test_reference_pipeline.R`): every copied function is identical to
    the pipeline's, and with the real fitted parameters (CY and FY) the R reference gives identical
    results to the pipeline;
  - the core against the reference, fed the reference's own random draws: counts identical, costs
    equal to about 1e-14 relative, on the synthetic model and in-house on the real CY and FY models;
  - the core's distribution functions reproduce R's (`pnorm`, `qnorm` and `qnbinom` bit for bit),
    and Philox reproduces the Random123 known-answer vectors.
- **The fitted models ship as parameter bundles** (`inst/bundles/`, 12 bundles, 0.7 MB; user
  decision 2026-11-08): CY and FY, the full model and the reduced models A, AS, ASR, AR, AN, read
  with `hcu_fitted_models("CY")`. They hold plain values only (coefficients, cut points, small
  tables): every bundle passes `hcu_audit_bundle()` (no fitted model objects, data, residuals,
  formulas, environments, per-record vectors or identifiers), and they carry no variance-covariance
  matrices. They were **cleared for release** on 2026-11-08 (Christodoulos Kypridemos, PI), with the
  small fill-in calibration cells in view (`vignette("methods")`, "What the package contains").
  - Examples and tests use a synthetic parameter set with the real structure and invented values
    (`hcu_synthetic_model()`).
  - In-house tests check that the synthetic set has exactly the real structure.
- **Clearance:** a bundle counts as *cleared* only if the md5 of every one of its files is in the
  package registry (`inst/registry/cleared_bundles.csv`: the 26 files of the 12 shipped bundles;
  `tools/register_bundles.R` registers newly cleared bundles).
  - Any other bundle is *uncleared*: in-house use only, and neither the bundle nor results computed
    with it may be distributed.
  - Every result carries the model's status in its `"hcucost"` attribute.

- **Predictions with unknown predictors** (`hcu_predict()`, phase 3b):
  - the smallest reduced refit that matches the known predictor groups exactly, otherwise the full
    model with the unknown predictors filled in by Gibbs sampling from its co-occurrence model;
  - the fill-in runs in the C++ core and gives the R reference's draws given the same uniforms;
  - a known number of conditions and a known death group are used in the fill-in; an unknown death
    group is averaged over the death model;
  - the fill-in is calibrated (`hcu_calibrate_fillin()`, in-house) so that, with the diseases hidden,
    the number of conditions, the prevalences and the diagnosis-year shares match the data.

- **Means without simulation** (`hcu_predict()`'s default, `method = "expected"`, since 2026-11-08;
  `method = "simulate"` reproduces earlier results):
  - exact expected counts;
  - expected costs by randomised quasi-Monte Carlo over the counts' copula, with the exact cost given
    the counts;
  - 0.2–0.5% error per death group with the default 16,384 points (0.05–0.15% with 65,536), in
    milliseconds;
  - the simulation needs 40–130 times as many simulated years for the same error;
  - see `vignette("methods")`.

- **Expected values of lifecourses** (`hcu_expected_impactncd()`, 2026-11-08): each person-year's
  expected use and cost for IMPACTncd, without simulation.
  - It applies to every year because the latent processes are stationary.
  - Speed: about 40 µs per person-year on one thread, against 2.5 µs to simulate one.
  - Precision: in the same time, the standard error of a population mean is about 7 times smaller.
  - Common random numbers across scenarios, keyed on person and year, as in the simulation.

## Quick start (synthetic)

```r
library(hcucost)
m <- hcu_synthetic_model()                # invented values: NOT for analysis
lc <- hcu_synthetic_lifecourse(m, n_persons = 1000, n_years = 10)
sim <- hcu_simulate_impactncd(m, lc, seed = 1)               # C++ core, 1 thread
sim8 <- hcu_simulate_impactncd(m, lc, seed = 1, threads = 8)  # identical result
ref <- hcu_simulate_impactncd(m, lc, seed = 1, engine = "r")  # R reference (other random numbers)
colMeans(sim)

# predictions for records with any known predictors (means, or draws with type = "draws")
models <- list(hcu_synthetic_model(), hcu_synthetic_model(predictors = "AS"))
nd <- data.table::data.table(age = c(50, 80), sex = c("men", "women"), dimd = c("5", NA),
                             ethnicity = c("white", NA), sha = c("London", NA), t2dm_prvl = c(NA, 4))
hcu_predict(models, nd, seed = 1)   # row 1: model AS exactly; row 2: full model, the rest filled in
```

## Use with the fitted models

```r
m <- hcu_fitted_models("CY")                        # status "cleared"
sim <- hcu_simulate_impactncd(m$ASRDN, lifecourse, seed = 1)
ev <- hcu_expected_impactncd(m$ASRDN, lifecourse, seed = 1)  # the same means, without simulation
hcu_predict(m, newdata, seed = 1)                    # records with any known predictors (no simulation)
hcu_predict(m, newdata, method = "simulate", seed = 1) # the same means by simulation (Monte Carlo)
```

Bundles are rebuilt from the fitting pipeline's outputs with `hcu_bundle_write()`. This needs the
CPRD data, so only the team that fits the models does it.

**Lifecourse layout (IMPACTncd):**
- one row per person and consecutive year;
- `pid`, `year`, `age`, `sex`, `dimd`, `ethnicity`, `sha`;
- `<disease>_prvl` for the 26 diseases;
- `bmi_curr_xps`, `smok_status_curr_xps`, `all_cause_mrtl`.

Details are in `?hcu_simulate_impactncd`.

**Two things to know about the costs:**
- Costs in a year of death already reflect the part of the year lived, so do not halve them again.
- Prices are those of the bundle's price year (2019/20 for the fitted models).

## Web explorer (proof of concept)

`web/` holds a static web page where people can explore expected use and costs with a form, without
a server. R runs in the visitor's browser with webR, and the page calls
`hcu_predict()` on the shipped models, without simulation. It gives the same results as R. Building, testing and the measured download size and speed are
in `web/README.md`. `web/` is not part of the R package.

## Roadmap

The design document is `Costing_pipeline/package_design/cost_model_package_design.md` in the CPRD2025
project.

| Phase | Work |
|---|---|
| 1 (done) | Skeleton, bundles, R reference implementation, synthetic parameters, tests |
| 2 (done) | C++ core: no design matrix, one pass per person, reproducible random numbers keyed on (seed, person, year), OpenMP |
| 3a (done) | Pipeline: reduced refits (A, AS, ASR, AR, AN; CY and FY), death models, co-occurrence models |
| 3b (done) | Fill-in (Gibbs, C++ core), `hcu_predict()`, bundles with death and co-occurrence models, masking validation, calibrated fill-in, vignettes |
| 4 | IMPACTncd hook |
| 5 | Disclosure checks, clearance, open-source release |

**Speed** (synthetic lifecourses with the real CY parameters):

| 0.9 million person-years | R implementation (phase 0) | C++ core, 1 thread | C++ core, 8 threads |
|---|---|---|---|
| Whole call | 17.8 s | 1.8 s | 0.42 s |
| R memory (heap peak) | 5.7 GiB | 0.47 GiB | |

The core alone runs at about 550,000 person-years per second per thread. The benchmark scripts are
in-house process files, not in the repository: `claude_process/04_benchmark_core.R` (package
folder) and `68_benchmark_r_adapter.R` (CPRD2025 costing work).

## Licence

GPL (>= 3).
